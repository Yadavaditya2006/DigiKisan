# Official Agricultural Data Sources & Integration Specifications
## Maharashtra Agricultural Ecosystem

This document records the official data sources, endpoints, schema mappings, update frequencies, access parameters, and operational limitations for the DigiKisan (आपला शेतकरी साथी) platform.

---

## 1. Maharashtra APMC Market Committees & Agricultural Marketing

### Source A: Maharashtra State Agricultural Marketing Board (MSAMB / पणन मंडळ)
- **Official Portal:** [https://www.msamb.com/](https://www.msamb.com/)
- **APMC List Reference:** [https://mahapanan.maharashtra.gov.in/1055/APMC-List?Type=1007](https://mahapanan.maharashtra.gov.in/1055/APMC-List?Type=1007)
- **Jurisdiction:** 305+ APMC Main Markets and 600+ Sub-Market Yards across Maharashtra.
- **Data Retrieved:**
  - Administrative mapping: Revenue Division (6 divisions) $\to$ District (36 districts) $\to$ APMC Market Committees $\to$ Sub-yards.
  - Standard commodities: Onion (कांदा), Cotton (कापूस), Soybean (सोयाबीन), Gram/Chana (हरभरा), Wheat (गहू), Jowar (ज्वारी), Bajra (बाजरी), Tur/Pigeon Pea (तूर), Sugarcane (ऊस), Grapes (द्राक्षे), Pomegranate (डाळिंब), Tomato (टोमॅटो).
- **Update Frequency:** Daily evening arrivals and modal clearing rates.
- **Architecture Integration:** Embedded authoritative baseline database containing all 36 districts, major APMCs, and standard unit metrics (₹/Quintal).

### Source B: AGMARKNET (Directorate of Marketing & Inspection, Ministry of Agriculture, Govt. of India)
- **Official Portal:** [https://agmarknet.gov.in/](https://agmarknet.gov.in/)
- **Data Schema:**
  - `Commodity`: Standard commodity name and trade grade.
  - `Arrivals`: Quantity traded in Metric Tonnes / Quintals.
  - `Min_Price`, `Max_Price`, `Modal_Price`: Prices in INR per Quintal.
  - `Price_Date`: Date of daily transaction closure.
- **Integration Approach:** Source Adapter architecture (`ApmcDataSourceAdapter`) providing parsed real-world historical records with fallbacks to locally verified cache. Data transparency indicates exact observation date and data provider tag.

---

## 2. Weather Forecasting & Agro-Meteorological Advisories

### Source: India Meteorological Department (IMD / भारतीय हवामानशास्त्र विभाग) & Mausam API
- **Official Documentation:** [https://api.imd.gov.in/public/api_reference.html](https://api.imd.gov.in/public/api_reference.html)
- **Agromet Advisory Service (AAS / मेघदूत - Meghdoot):** [https://mausam.imd.gov.in/](https://mausam.imd.gov.in/)
- **Data Fields Utilized:**
  - Maximum Temperature (°C)
  - Minimum Temperature (°C)
  - Rainfall Forecast (Probability % and mm accumulation)
  - Relative Humidity (%)
  - Wind Speed (km/h) and Direction
  - Weather Warning Level (Green / Yellow / Orange / Red alert)
- **Farmer-Centric Advisory Rules:**
  - *Rainfall > 50%: * Avoid foliar spray of insecticides or top-dressing of urea; ensure drainage trenches are clear in heavy black soils.
  - *Temperature > 40°C: * Increase drip irrigation frequency to avoid flower dropping in horticulture crops; apply straw mulch.
  - *Humidity > 85% with warm nights: * Monitor crops for fungal outbreaks (blast in rice, downy mildew in grapes, anthracnose in pomegranate).

---

## 3. Maharashtra & Central Government Schemes (Kisan Yojna)

### Source A: MahaDBT Farmer Portal (महाराष्ट्र शासन कृषी विभाग)
- **Portal URL:** [https://mahadbt.maharashtra.gov.in/Farmer/Agrilogin/Agrilogin](https://mahadbt.maharashtra.gov.in/Farmer/Agrilogin/Agrilogin)
- **Covered Schemes:**
  - *Micro-Irrigation Scheme (सूक्ष्म सिंचन योजना):* 70% to 80% subsidy for drip and sprinkler irrigation for small/marginal farmers.
  - *Agricultural Mechanization (कृषी यांत्रिकीकरण):* Subsidies for tractors, power tillers, rotavators, and harvesters.
  - *Dr. Babasaheb Ambedkar Krishi Swavalamban Yojana:* Irrigation wells and electricity connection subsidies for SC/ST farmers.
- **Official Required Documents:** 7/12 extract, 8-A holding certificate, Aadhaar linked bank account, caste certificate (if applicable), quotation from authorized dealer.

### Source B: PM-Kisan Samman Nidhi
- **Portal URL:** [https://pmkisan.gov.in/](https://pmkisan.gov.in/)
- **Benefit:** ₹6,000 annually in three equal installments of ₹2,000 directly via DBT.
- **Eligibility:** Landholding farmer families with cultivable land up to state records, subject to standard exclusion criteria (income tax payees, constitutional post holders).

### Source C: Pradhan Mantri Fasal Bima Yojana (PMFBY / एक रुपयात पीक विमा)
- **Portal URL:** [https://pmfby.gov.in/](https://pmfby.gov.in/)
- **Maharashtra Special Provision:** Farmers pay only ₹1 token premium; the remaining premium is borne entirely by the Maharashtra State Government.
- **Coverage:** Sowing failure, mid-season adversity, localized natural calamities, post-harvest losses due to cyclonic rain.

---

## 4. Agricultural Universities & Research Guidance (Advisory Base)
1. **Mahatma Phule Krishi Vidyapeeth (MPKV), Rahuri:** Western Maharashtra soil, sugarcane, onion, and pomegranate agro-practices.
2. **Dr. Panjabrao Deshmukh Krishi Vidyapeeth (PDKV), Akola:** Vidarbha region cotton, soybean, and citrus crop packages.
3. **Vasantrao Naik Marathwada Krishi Vidyapeeth (VNMKV), Parbhani:** Marathwada dryland farming, pulses, and oilseeds.
4. **Dr. Balasaheb Sawant Konkan Krishi Vidyapeeth (DBSKKV), Dapoli:** Konkan region rice, cashew, and Alphonso mango management.
5. **ICAR - Krishi Vigyan Kendra (KVK) Network:** Toll-free Kisan Call Centre (1800-180-1551) verified guidance.
