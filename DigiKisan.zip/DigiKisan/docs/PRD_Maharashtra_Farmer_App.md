# Product Requirements Document (PRD)
## आपला शेतकरी साथी — Aapla Shetkari Saathi (Maharashtra Farmer Companion)

### Document Version: 1.0.0
### Target Audience: Farmers in Maharashtra, Agricultural Extension Workers, Project Evaluators (MAD Course)
### Operating System: Android (minSdk 24 - Android 7.0, targetSdk 34 - Android 14)
### Core Architecture: Java 8, Native Android XML, SQLite OpenHelper, Material Design 3

---

## 1. Product Vision & Emotional Purpose
**Aapla Shetkari Saathi (आपला शेतकरी साथी)** is a native Android application built specifically for farmers across the 36 districts of Maharashtra. Designed with empathy, clarity, and trust, the application serves as a dependable digital companion rather than an intimidating bureaucratic portal. 

A farmer can open the app and find answers to critical daily questions:
- *What is happening in my local APMC market? What are the minimum, maximum, and modal prices for my crop?*
- *Why did the price fluctuate, and what are the arrivals trends?*
- *What weather conditions are forecast for my district, and how should I adjust irrigation or spraying?*
- *How is my crop progressing based on my observations, and what immediate steps should I inspect?*
- *Which Maharashtra and Central government schemes benefit me, what documents do I need, and how do I apply on MahaDBT / PM-Kisan?*
- *How can I track my farm activities, expenses, and key dates in my own digital farm diary?*

The application adheres strictly to honest advisory principles: it **never guarantees yields, prices, or scheme approvals**, but empowers farmers with transparent, explainable, and localized agricultural intelligence.

---

## 2. User Personas
1. **Ramesh Rao Patil (Nashik - Smallholder Onion & Grape Farmer)**
   - *Profile:* 48 years old, 3 acres, smartphone user with Marathi primary language. Needs to monitor Lasalgaon and Pimpalgaon APMC onion arrivals and prices before deciding when to harvest and transport to market.
2. **Sunita Tai Shinde (Satara - Sugarcane & Dairy Farmer)**
   - *Profile:* 42 years old, active in Women's Self-Help Group (Bachat Gat). Needs clear guidance on MahaDBT drip irrigation subsidies, tractor implement schemes, and soil health advice.
3. **Ganesh Gavit (Amravati - Vidarbha Cotton & Soybean Farmer)**
   - *Profile:* 34 years old, dryland agriculture. Relies on IMD localized weather forecasts to plan sowing dates and avoid fertilizer wash-off during unseasonal monsoon surges.
4. **B.Tech Mobile App Development Evaluator / Viva Examiner**
   - *Profile:* Academic examiner evaluating syllabus coverage: SQLite CRUD, Intent navigation, BroadcastReceivers, DatePickers, Adapters, Input Validation, UI Design, and software engineering discipline.

---

## 3. Core Modules & Functional Requirements

### 3.1 User Authentication & Profile Security
- **Local SQLite Authentication:** User accounts stored securely in `users` table. Passwords salted and hashed with SHA-256.
- **Validation:** 10-digit Indian mobile number validation (`^[6-9]\d{9}$`), full name, password strength.
- **Isolation:** All farm profiles, farm diary entries, crop assessments, and saved schemes are keyed by `user_id`.
- **Session Management:** Encrypted/SharedPreferences session persistence with safe logout and data persistence across app restarts.

### 3.2 Farmer Profile & My Farm Management
- **Personal Profile:** Name, mobile number, preferred language (Marathi, Hindi, English), Revenue Division, District, Taluka.
- **Farm Profile:** Cultivated crop, crop variety, sowing date, land area (Acres / Guntha), soil type (Black Cotton, Red, Loamy, Laterite), irrigation method (Drip, Sprinkler, Flood, Rainfed), watering schedule.
- **Onboarding & About App:** Explains data sourcing, how assessments work, and helpline resources.

### 3.3 Maharashtra APMC Market Intelligence Module
- **Geographic Coverage:** Full 36 districts across all 6 administrative divisions (Amravati, Aurangabad/Chhatrapati Sambhajinagar, Konkan, Nagpur, Nashik, Pune).
- **APMC Market Selection:** Major Maharashtra APMC markets (e.g., Lasalgaon, Pune, Vashi/Mumbai, Nagpur, Kolhapur, Akola, Solapur, Latur, Jalgaon, Baramati, Ahmednagar, Sangli).
- **Price Attributes:** Minimum price, Maximum price, Modal price (₹/Quintal), daily arrivals quantity, date of observation, data source.
- **Price Trends:** Algorithmic calculation of price trends: *Rising (>+3%)*, *Falling (<-3%)*, *Relatively Stable (-3% to +3%)*, or *Insufficient Data*.
- **Market Explanations:** Explains price movements in relation to arrivals variations, seasonal shifts, and supply chain factors without speculative guarantees.
- **Multi-Market Comparison:** Side-by-side modal price comparison across neighbouring APMC markets for the same commodity.

### 3.4 Localized Weather Intelligence Module
- **District Forecast:** Local weather reports for all 36 Maharashtra districts.
- **Metrics:** Min/Max temperature, rainfall forecast, humidity percentage, wind speed & direction.
- **Farming Advisories:** Actionable tips linked to weather (e.g., delay pesticide spraying if rainfall >60%, check drainage during heavy rain alerts, maintain mulching in heatwaves).
- **Offline Resilient:** Caches recent weather data with clear "Last Updated" timestamp to prevent farmer confusion.

### 3.5 Personalized Farm & Crop Assessment
- **Crop Health Evaluator:** Form collecting crop stage, irrigation frequency, recent rainfall, waterlogging status, fertilizer application, and visible symptoms (yellowing leaves, wilt, leaf spots, insect boreholes).
- **Rule Engine Classification:**
  - *Good Indications:* Optimum irrigation and no disease markers reported.
  - *Needs Attention:* Overwatering/underwatering signs or early leaf chlorosis.
  - *High Risk:* Waterlogging with root rot symptoms or aggressive pest infestation indicators.
  - *Insufficient Information:* When key parameters are omitted.
- **Transparency:** Explicitly highlights positive factors, risk flags, missing data, and recommended precautions based on ICAR/KVK guidance.

### 3.6 Kisan Yojna (Government Schemes)
- **Verified Maharashtra & Central Scheme Catalogue:**
  1. *PM-Kisan Samman Nidhi* (₹6,000/yr direct income support).
  2. *Namo Shetkari Mahasanman Nidhi Yojana* (Maharashtra ₹6,000/yr supplementary support).
  3. *Pradhan Mantri Fasal Bima Yojana (PMFBY)* (₹1 token crop insurance in Maharashtra).
  4. *MahaDBT Farmer Schemes (कृषी यांत्रिकीकरण & सूक्ष्म सिंचन)* (Drip/sprinkler 70-80% subsidy).
  5. *Dr. Babasaheb Ambedkar Krishi Swavalamban Yojana* (Wells & farm ponds for SC/ST farmers).
  6. *Kisan Credit Card (KCC)* (Subsidized crop loans at 4% effective interest).
  7. *Chhatrapati Shivaji Maharaj Shetkari Sanman Yojana / Karj Mafi updates*.
- **Personalized Eligibility Checker:** Matches farmer's district, landholding size, crop type, and irrigation against scheme rules to state *Potentially Eligible*, *More Info Required*, or *Criteria Not Met*.
- **Application Checklist & Portal Links:** Required documents list (7/12 extract, 8-A, Aadhaar linked bank passbook) and direct links to MahaDBT and central portals via safe browser/WebView intent.

### 3.7 "शेतकरी मित्र" (Shetkari Mitra) Guided Farming Assistant
- **Knowledge Base Chatbot:** Natural rule-based conversational engine supporting Marathi, Hindi, and English.
- **Supported Query Domains:**
  - Finding APMC prices and explaining modal price vs minimum price.
  - Weather interpretation and spraying advisories.
  - Crop diagnosis guidance and irrigation scheduling tips.
  - Government scheme requirements and MahaDBT registration steps.
  - App navigation and farm diary help.
- **Empathetic & Responsible:** Clarifies doubts with follow-up questions, never guesses blindly, and provides KVK helpline numbers for severe field emergencies.

### 3.8 Farm Diary, Reminders & Cost Tracking
- **Activity Logger:** SQLite-backed recording of sowing, tillage, irrigation, fertilizer/manure, pesticide spray, weeding, and harvest.
- **Expense & Return Tracking:** Log costs (seeds, labor, fertilizer, diesel) and revenue from crop sales with auto-calculated net balance.
- **Crop Reminders:** BroadcastReceiver-based alarm reminders for scheduled irrigation checks and fertilizer top-dressing.

---

## 4. Non-Functional Requirements
- **Performance:** App launch < 1.5s; database queries < 50ms; zero UI thread stutter.
- **Offline Capability:** Core database, diary, past market rates, scheme criteria, and chatbot knowledge base function 100% offline.
- **Security & Privacy:** Password hashing using SHA-256 with salt; zero sensitive government credentials (no Aadhaar OTP storage); user data isolated by ID.
- **Aesthetics & UX:** Earthy, agricultural color scheme (Deep Forest Green `#1B5E20`, Warm Leaf `#2E7D32`, Harvest Gold `#F57F17`, Cream `#FAFAFA`). High contrast, 16sp+ readable typography, and tactile CardViews.

---

## 5. Scope & Syllabus Alignment
| Topic | Real Implementation in DigiKisan |
|---|---|
| UI Controls & Layouts | XML ConstraintLayout, LinearLayout, CardView, Spinner, EditText, Switch |
| Navigation & Intents | Explicit Intents between Activities, Implicit Intents (dialer, browser, share) |
| Lists & Adapters | RecyclerView with custom ViewHolders for APMC prices, Schemes, and Diary |
| SQLite Database | SQLiteOpenHelper, normalized tables, CRUD operations, parameterized queries |
| Date & Time Pickers | DatePickerDialog for sowing dates, diary logging, and reminders |
| BroadcastReceiver & Alarms | Custom reminder receiver for farm irrigation & task alerts |
| Localization | `res/values/strings.xml`, `res/values-mr/strings.xml` (Marathi), `res/values-hi/strings.xml` |
