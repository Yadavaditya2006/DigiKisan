# आपला शेतकरी साथी — Aapla Shetkari Saathi (DigiKisan)
### Maharashtra Farmer Companion — Native Android Application

**आपला शेतकरी साथी (Aapla Shetkari Saathi)** is a comprehensive, production-grade native Android mobile application designed exclusively for the agricultural community of Maharashtra, India. Developed using Java, XML layouts, SQLite database, and Material Design, it provides practical, trustworthy, and localized assistance for crop management, APMC market price discovery, agro-meteorological advisories, government scheme eligibility matching, and farm financial record-keeping.

---

## 🌟 Key Application Features

1. **Maharashtra APMC Market Intelligence:**
   - Covers all 36 Maharashtra districts and 6 administrative divisions (Pune, Nashik, Chhatrapati Sambhajinagar/Aurangabad, Amravati, Nagpur, Konkan).
   - Real-time / updated modal, minimum, and maximum prices (₹/Quintal) and daily arrivals.
   - Algorithmic price trend indicators: *Rising*, *Falling*, *Relatively Stable*.
   - Objective explanations for market fluctuations based on arrivals and seasonality.
   - Cross-market price comparison for identical commodities.

2. **Localized Weather Forecasting & Farm Advisories:**
   - 36-district weather information covering maximum/minimum temperature, rainfall probability, humidity, and wind.
   - Clear agro-meteorological advisories (e.g., pesticide spray suitability, drainage checks during monsoon alerts).
   - Offline cached view with verified timestamp.

3. **My Farm & Personalized Crop Assessment:**
   - Farmer profile storing crop varieties, sowing dates, soil type, and irrigation methods.
   - Rule-based crop health evaluator classifying field condition into *Good Indications*, *Needs Attention*, *High Risk*, or *Insufficient Information*.
   - Actionable, crop-specific guidance referencing ICAR, KVK, and Maharashtra agricultural universities (MPKV Rahuri, PDKV Akola, VNMKV Parbhani, DBSKKV Dapoli).

4. **Kisan Yojna (Personalized Government Schemes):**
   - Verified Maharashtra state and Central schemes: PM-Kisan, Namo Shetkari Mahasanman Nidhi, MahaDBT Micro-Irrigation (Drip/Sprinkler 80% subsidy), PM Fasal Bima Yojana (₹1 crop insurance), Agricultural Mechanization, Dr. Ambedkar Krishi Swavalamban Yojana.
   - Automated eligibility matching based on landholding, crop, and irrigation criteria.
   - Document readiness checklists (7/12 extract, 8-A, Aadhaar linked passbook) and official portal links.

5. **"शेतकरी मित्र" (Shetkari Mitra) Conversational Assistant:**
   - Friendly in-app farming advisor supporting Marathi, Hindi, and English.
   - Guides farmers through market rates, weather advisories, symptom checking, and application steps without making false promises.

6. **Farm Diary & Financial Record Book:**
   - Log farming activities: Sowing, irrigation, fertilizer top-dressing, spraying, weeding, and harvesting.
   - Simple cost and revenue tracker calculating net farming income.
   - Local alarm reminders for critical irrigation and spraying schedules.

---

## 🏗️ Technical Architecture & Tech Stack

- **Platform:** Native Android (minSdk 24 - Android 7.0 Nougat, targetSdk 34 - Android 14)
- **Language:** Java 8
- **UI Framework:** Android XML layouts, ConstraintLayout, Material Design 3, CardView, RecyclerView
- **Local Database:** SQLiteOpenHelper with normalized relational tables, parameterized queries, and index optimization
- **Security:** SHA-256 with cryptographic salt for user passwords, zero plaintext credentials, isolated user sessions
- **Localization:** Resource-based multi-language localization with Marathi (`values-mr`) as first-class local citizen, alongside Hindi (`values-hi`) and English (`values`)

---

## 📁 Project Directory Structure

```
d:/DigiKisan/
├── app/
│   ├── build.gradle
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/com/digikisan/app/
│           │   ├── activities/        # Native Android Activities (Login, Home, Market, etc.)
│           │   ├── adapters/          # RecyclerView & ListView Custom Adapters
│           │   ├── database/          # SQLiteOpenHelper, DAOs, Database Migrations
│           │   ├── models/            # Entity models (User, PriceRecord, Scheme, etc.)
│           │   ├── receivers/         # BroadcastReceivers for farm reminders
│           │   ├── services/          # Source adapters for APMC, Weather & Schemes
│           │   └── utils/             # Input validation, hashing, UI helpers
│           └── res/
│               ├── drawable/          # Vector icons, shape drawables, card backgrounds
│               ├── layout/            # Responsive XML screen layouts
│               ├── values/            # Colors, themes, English strings
│               ├── values-hi/         # Hindi translations
│               └── values-mr/         # Marathi translations (प्राथमिक स्थानिक भाषा)
├── docs/
│   ├── PRD_Maharashtra_Farmer_App.md  # Complete Product Requirements Document
│   ├── DATA_SOURCES.md                # Official portals & data integration specifications
│   └── SYLLABUS_COVERAGE.md           # MAD course curriculum mapping
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🚀 How to Build and Run in Android Studio

1. **Open Android Studio:** Select `File -> Open...` and select `d:\DigiKisan`.
2. **Gradle Sync:** Allow Android Studio to sync the Gradle project dependencies.
3. **Run on Device or Emulator:**
   - Connect an Android phone with USB Debugging enabled, OR start an Android Virtual Device (AVD).
   - Click the green **Run** button (`Shift + F10`).
4. **First Launch Experience:**
   - Register a new farmer account using your mobile number and district.
   - Experience the warm Marathi welcome and explore APMC prices, weather, crop assessment, and government schemes.

---

## 🎓 Academic Viva & Presentation Guide

For B.Tech Mobile Application Development viva, this project showcases:
- **Relational Data Persistence:** Structured SQLite database with full CRUD operations.
- **Modern UI/UX:** Clean, uncluttered CardView architecture adhering to agricultural ergonomics.
- **Safe Engineering:** Validated mobile inputs, salted SHA-256 password hashing, and user data isolation.
- **Explainable Advisory:** Transparent rule engines avoiding unsupported claims or "black-box" predictions.
