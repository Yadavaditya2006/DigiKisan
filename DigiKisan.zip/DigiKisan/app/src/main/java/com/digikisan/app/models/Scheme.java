package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing an official agricultural welfare scheme (Maharashtra / Central).
 */
public class Scheme implements Serializable {
    private long id;
    private String schemeName;
    private String issuingAuthority; // e.g. "Govt of Maharashtra", "Govt of India"
    private String category; // "INCOME_SUPPORT", "INSURANCE", "IRRIGATION", "MACHINERY", "SOIL"
    private String objective;
    private String benefitsSummary;
    private String eligibilityCriteria;
    private String requiredDocuments;
    private String applicationSteps;
    private String officialPortalUrl;
    private String helplineContact;
    private boolean isSavedByFarmer;

    public Scheme() {}

    public Scheme(long id, String schemeName, String issuingAuthority, String category, 
                  String objective, String benefitsSummary, String eligibilityCriteria, 
                  String requiredDocuments, String applicationSteps, String officialPortalUrl, 
                  String helplineContact, boolean isSavedByFarmer) {
        this.id = id;
        this.schemeName = schemeName;
        this.issuingAuthority = issuingAuthority;
        this.category = category;
        this.objective = objective;
        this.benefitsSummary = benefitsSummary;
        this.eligibilityCriteria = eligibilityCriteria;
        this.requiredDocuments = requiredDocuments;
        this.applicationSteps = applicationSteps;
        this.officialPortalUrl = officialPortalUrl;
        this.helplineContact = helplineContact;
        this.isSavedByFarmer = isSavedByFarmer;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getSchemeName() { return schemeName; }
    public void setSchemeName(String schemeName) { this.schemeName = schemeName; }

    public String getIssuingAuthority() { return issuingAuthority; }
    public void setIssuingAuthority(String issuingAuthority) { this.issuingAuthority = issuingAuthority; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getObjective() { return objective; }
    public void setObjective(String objective) { this.objective = objective; }

    public String getBenefitsSummary() { return benefitsSummary; }
    public void setBenefitsSummary(String benefitsSummary) { this.benefitsSummary = benefitsSummary; }

    public String getEligibilityCriteria() { return eligibilityCriteria; }
    public void setEligibilityCriteria(String eligibilityCriteria) { this.eligibilityCriteria = eligibilityCriteria; }

    public String getRequiredDocuments() { return requiredDocuments; }
    public void setRequiredDocuments(String requiredDocuments) { this.requiredDocuments = requiredDocuments; }

    public String getApplicationSteps() { return applicationSteps; }
    public void setApplicationSteps(String applicationSteps) { this.applicationSteps = applicationSteps; }

    public String getOfficialPortalUrl() { return officialPortalUrl; }
    public void setOfficialPortalUrl(String officialPortalUrl) { this.officialPortalUrl = officialPortalUrl; }

    public String getHelplineContact() { return helplineContact; }
    public void setHelplineContact(String helplineContact) { this.helplineContact = helplineContact; }

    public boolean isSavedByFarmer() { return isSavedByFarmer; }
    public void setSavedByFarmer(boolean savedByFarmer) { isSavedByFarmer = savedByFarmer; }
}
