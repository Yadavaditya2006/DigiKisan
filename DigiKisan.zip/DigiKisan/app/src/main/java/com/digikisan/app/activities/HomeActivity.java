package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.models.WeatherReport;
import com.digikisan.app.services.WeatherServiceAdapter;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.card.MaterialCardView;

/**
 * Main Dashboard Activity for Aapla Shetkari Saathi (आपला शेतकरी साथी).
 * Serves as the central navigation hub for all farmer assistance features.
 */
public class HomeActivity extends AppCompatActivity {

    private TextView tvFarmerGreeting, tvFarmerDistrict;
    private TextView tvQuickWeatherDistrict, tvQuickWeatherAdvisory, tvQuickWeatherTemp;
    private MaterialCardView cardQuickWeather, cardQuickMarket;
    private MaterialCardView cardNavMarket, cardNavWeather, cardNavAssessment, cardNavSchemes;
    private MaterialCardView cardNavChatbot, cardNavDiary, cardNavLearning;
    private ImageButton btnNavProfile, btnNavLogout;

    private UserSessionManager sessionManager;
    private WeatherServiceAdapter weatherAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        sessionManager = new UserSessionManager(this);
        weatherAdapter = new WeatherServiceAdapter(this);

        initViews();
        loadDashboardData();
        setupNavigationListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    private void initViews() {
        tvFarmerGreeting = findViewById(R.id.tvFarmerGreeting);
        tvFarmerDistrict = findViewById(R.id.tvFarmerDistrict);
        tvQuickWeatherDistrict = findViewById(R.id.tvQuickWeatherDistrict);
        tvQuickWeatherAdvisory = findViewById(R.id.tvQuickWeatherAdvisory);
        tvQuickWeatherTemp = findViewById(R.id.tvQuickWeatherTemp);

        cardQuickWeather = findViewById(R.id.cardQuickWeather);
        cardQuickMarket = findViewById(R.id.cardQuickMarket);
        cardNavMarket = findViewById(R.id.cardNavMarket);
        cardNavWeather = findViewById(R.id.cardNavWeather);
        cardNavAssessment = findViewById(R.id.cardNavAssessment);
        cardNavSchemes = findViewById(R.id.cardNavSchemes);
        cardNavChatbot = findViewById(R.id.cardNavChatbot);
        cardNavDiary = findViewById(R.id.cardNavDiary);
        cardNavLearning = findViewById(R.id.cardNavLearning);

        btnNavProfile = findViewById(R.id.btnNavProfile);
        btnNavLogout = findViewById(R.id.btnNavLogout);
    }

    private void loadDashboardData() {
        String name = sessionManager.getUserName();
        String district = sessionManager.getUserDistrict();

        tvFarmerGreeting.setText(getString(R.string.greeting_farmer, name));
        tvFarmerDistrict.setText("📍 " + district + ", Maharashtra");

        // Load local agro-weather overview
        WeatherReport weather = weatherAdapter.getWeatherForDistrict(district);
        tvQuickWeatherDistrict.setText("आजचे हवामान (" + district + ")");
        tvQuickWeatherAdvisory.setText(weather.getFarmingAdvisory());
        tvQuickWeatherTemp.setText((int) weather.getCurrentTemp() + "°C");
    }

    private void setupNavigationListeners() {
        // Quick glance cards
        cardQuickWeather.setOnClickListener(v -> openActivity(WeatherActivity.class));
        cardQuickMarket.setOnClickListener(v -> openActivity(MarketActivity.class));

        // Core Grid Cards
        cardNavMarket.setOnClickListener(v -> openActivity(MarketActivity.class));
        cardNavWeather.setOnClickListener(v -> openActivity(WeatherActivity.class));
        cardNavAssessment.setOnClickListener(v -> openActivity(CropAssessmentActivity.class));
        cardNavSchemes.setOnClickListener(v -> openActivity(SchemeListActivity.class));
        cardNavChatbot.setOnClickListener(v -> openActivity(ChatbotActivity.class));
        cardNavDiary.setOnClickListener(v -> openActivity(FarmDiaryActivity.class));
        cardNavLearning.setOnClickListener(v -> openActivity(LearningResourcesActivity.class));

        // Top Actions
        btnNavProfile.setOnClickListener(v -> openActivity(FarmerProfileActivity.class));
        btnNavLogout.setOnClickListener(v -> confirmLogout());
    }

    private void openActivity(Class<?> targetActivity) {
        Intent intent = new Intent(HomeActivity.this, targetActivity);
        startActivity(intent);
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.logout)
                .setMessage(R.string.logout_confirm)
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    sessionManager.logoutUser();
                    Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }
}
