package com.digikisan.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.models.ChatMessage;
import java.util.List;

/**
 * RecyclerView Adapter for Shetkari Mitra chatbot dialogues.
 */
public class ChatMessageAdapter extends RecyclerView.Adapter<ChatMessageAdapter.ViewHolder> {

    private final Context context;
    private final List<ChatMessage> messageList;

    public ChatMessageAdapter(Context context, List<ChatMessage> messageList) {
        this.context = context;
        this.messageList = messageList;
    }

    public void addMessage(ChatMessage message) {
        messageList.add(message);
        notifyItemInserted(messageList.size() - 1);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_chat_message, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatMessage msg = messageList.get(position);

        if (msg.getType() == ChatMessage.TYPE_USER) {
            holder.layoutUserMessage.setVisibility(View.VISIBLE);
            holder.layoutBotMessage.setVisibility(View.GONE);
            holder.tvUserMessageText.setText(msg.getMessage());
        } else {
            holder.layoutBotMessage.setVisibility(View.VISIBLE);
            holder.layoutUserMessage.setVisibility(View.GONE);
            holder.tvBotMessageText.setText(msg.getMessage());
        }
    }

    @Override
    public int getItemCount() {
        return messageList != null ? messageList.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutBotMessage, layoutUserMessage;
        TextView tvBotMessageText, tvUserMessageText;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutBotMessage = itemView.findViewById(R.id.layoutBotMessage);
            layoutUserMessage = itemView.findViewById(R.id.layoutUserMessage);
            tvBotMessageText = itemView.findViewById(R.id.tvBotMessageText);
            tvUserMessageText = itemView.findViewById(R.id.tvUserMessageText);
        }
    }
}
