package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing a chat conversation bubble between the farmer and Shetkari Mitra.
 */
public class ChatMessage implements Serializable {
    public static final int TYPE_BOT = 0;
    public static final int TYPE_USER = 1;

    private int type;
    private String message;
    private String timestamp;

    public ChatMessage() {}

    public ChatMessage(int type, String message, String timestamp) {
        this.type = type;
        this.message = message;
        this.timestamp = timestamp;
    }

    public int getType() { return type; }
    public void setType(int type) { this.type = type; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
