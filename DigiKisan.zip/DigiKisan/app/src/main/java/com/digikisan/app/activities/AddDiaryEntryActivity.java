package com.digikisan.app.activities;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.utils.InputValidator;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * AddDiaryEntryActivity allows farmers to log field activities and financial transactions.
 * Incorporates DatePickerDialog fulfilling MAD Syllabus Unit 5.
 */
public class AddDiaryEntryActivity extends AppCompatActivity {

    private ImageButton btnBackAddDiary;
    private Spinner spinnerActivityType;
    private TextInputEditText etDiaryDate, etExpense, etIncome, etNotes;
    private MaterialButton btnSaveDiaryEntry;

    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;
    private final Calendar calendar = Calendar.getInstance();

    private static final String[] ACTIVITIES = {
            "Sowing / Planting (पेरणी / लागवड)",
            "Irrigation (पाणी देणे / सिंचन)",
            "Fertilizer Application (खत देणे)",
            "Pesticide / Fungicide Spray (औषध फवारणी)",
            "Weeding / Inter-culturing (खुरपणी / कोळपणी)",
            "Harvesting / Picking (काढणी / वेचणी)",
            "Crop Sale / Revenue (माल विक्री / उत्पन्न)"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_diary_entry);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupSpinner();
        setupDatePicker();
        setupListeners();
    }

    private void initViews() {
        btnBackAddDiary = findViewById(R.id.btnBackAddDiary);
        spinnerActivityType = findViewById(R.id.spinnerActivityType);
        etDiaryDate = findViewById(R.id.etDiaryDate);
        etExpense = findViewById(R.id.etExpense);
        etIncome = findViewById(R.id.etIncome);
        etNotes = findViewById(R.id.etNotes);
        btnSaveDiaryEntry = findViewById(R.id.btnSaveDiaryEntry);
    }

    private void setupSpinner() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner_selected, ACTIVITIES);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerActivityType.setAdapter(adapter);
    }

    private void setupDatePicker() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
        etDiaryDate.setText(today);

        etDiaryDate.setOnClickListener(v -> {
            DatePickerDialog dialog = new DatePickerDialog(
                    AddDiaryEntryActivity.this,
                    (view, year, month, dayOfMonth) -> {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        String selected = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
                        etDiaryDate.setText(selected);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            dialog.show();
        });
    }

    private void setupListeners() {
        btnBackAddDiary.setOnClickListener(v -> finish());
        btnSaveDiaryEntry.setOnClickListener(v -> saveDiaryEntry());
    }

    private void saveDiaryEntry() {
        String type = spinnerActivityType.getSelectedItem().toString();
        String date = (etDiaryDate.getText() != null) ? etDiaryDate.getText().toString().trim() : "";
        String notes = (etNotes.getText() != null) ? etNotes.getText().toString().trim() : "";
        String expStr = (etExpense.getText() != null) ? etExpense.getText().toString().trim() : "0";
        String incStr = (etIncome.getText() != null) ? etIncome.getText().toString().trim() : "0";

        double expense = 0.0;
        double income = 0.0;

        if (InputValidator.isValidPositiveNumber(expStr)) {
            expense = Double.parseDouble(expStr);
        }
        if (InputValidator.isValidPositiveNumber(incStr)) {
            income = Double.parseDouble(incStr);
        }

        if (notes.isEmpty()) {
            notes = type;
        }

        long userId = sessionManager.getUserId();
        long id = dbHelper.insertDiaryEntry(userId, type, date, notes, expense, income);

        if (id != -1) {
            Toast.makeText(this, "नोंद यशस्वीरित्या जतन केली", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "नोंद जतन करताना त्रुटी आली", Toast.LENGTH_SHORT).show();
        }
    }
}
