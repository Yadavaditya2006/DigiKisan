package com.digikisan.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * SharedPreferences session manager for active farmer login state and language preferences.
 */
public class UserSessionManager {
    private static final String PREF_NAME = "DigiKisanFarmerSession";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_MOBILE = "user_mobile";
    private static final String KEY_USER_DISTRICT = "user_district";
    private static final String KEY_LANGUAGE = "user_language"; // "mr", "hi", "en"

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;

    public UserSessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void createLoginSession(long userId, String name, String mobile, String district) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putLong(KEY_USER_ID, userId);
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_MOBILE, mobile);
        editor.putString(KEY_USER_DISTRICT, district);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public long getUserId() {
        return pref.getLong(KEY_USER_ID, -1);
    }

    public String getUserName() {
        return pref.getString(KEY_USER_NAME, "शेतकरी मित्र");
    }

    public String getUserMobile() {
        return pref.getString(KEY_USER_MOBILE, "");
    }

    public String getUserDistrict() {
        return pref.getString(KEY_USER_DISTRICT, "Pune");
    }

    public void updateDistrict(String district) {
        editor.putString(KEY_USER_DISTRICT, district);
        editor.apply();
    }

    public void updateUserName(String name) {
        editor.putString(KEY_USER_NAME, name);
        editor.apply();
    }

    public void setPreferredLanguage(String langCode) {
        editor.putString(KEY_LANGUAGE, langCode);
        editor.apply();
    }

    public String getPreferredLanguage() {
        return pref.getString(KEY_LANGUAGE, "mr"); // Default to Marathi
    }

    public void logoutUser() {
        editor.clear();
        editor.apply();
    }
}
