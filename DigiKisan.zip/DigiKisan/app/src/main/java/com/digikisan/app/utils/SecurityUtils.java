package com.digikisan.app.utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/**
 * Utility for cryptographic operations: SHA-256 salted password hashing.
 * Prevents plain-text password storage in SQLite.
 */
public class SecurityUtils {

    /**
     * Generates a cryptographically secure random 16-byte salt as hex string.
     */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return bytesToHex(salt);
    }

    /**
     * Hashes password concatenated with salt using SHA-256.
     */
    public static String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String input = salt + password;
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available", e);
        }
    }

    /**
     * Verifies if input password matches stored hash given the salt.
     * Supports salted SHA-256, whitespace tolerance, and legacy fallbacks.
     */
    public static boolean verifyPassword(String inputPassword, String storedSalt, String storedHash) {
        if (inputPassword == null || storedHash == null) {
            return false;
        }

        // 1. Salted SHA-256 (standard)
        if (storedSalt != null && !storedSalt.trim().isEmpty()) {
            String calculatedHash = hashPassword(inputPassword, storedSalt);
            if (calculatedHash.equalsIgnoreCase(storedHash)) {
                return true;
            }
            // Tolerance for keyboard auto-space on password fields
            String calculatedTrimmedHash = hashPassword(inputPassword.trim(), storedSalt);
            if (calculatedTrimmedHash.equalsIgnoreCase(storedHash)) {
                return true;
            }
        }

        // 2. Direct plain-text match fallback (for legacy accounts or initial seeds)
        if (storedHash.equals(inputPassword) || storedHash.equals(inputPassword.trim())) {
            return true;
        }

        // 3. Unsalted SHA-256 fallback (salt was empty)
        String unsaltedHash = hashPassword(inputPassword, "");
        if (unsaltedHash.equalsIgnoreCase(storedHash)) {
            return true;
        }
        String unsaltedTrimmedHash = hashPassword(inputPassword.trim(), "");
        return unsaltedTrimmedHash.equalsIgnoreCase(storedHash);
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
