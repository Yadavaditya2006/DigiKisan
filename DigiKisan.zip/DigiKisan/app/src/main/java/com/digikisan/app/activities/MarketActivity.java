package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.adapters.ApmcPriceAdapter;
import com.digikisan.app.models.ApmcPrice;
import com.digikisan.app.services.ApmcDataSourceAdapter;
import com.digikisan.app.utils.UserSessionManager;

import java.util.ArrayList;
import java.util.List;

/**
 * MarketActivity displaying official Maharashtra APMC prices, trends, and cascading filters:
 * Revenue Division -> District -> APMC Market -> Commodity.
 * 
 * Features:
 * - High-contrast custom dropdown items (R.layout.item_spinner_selected, R.layout.item_spinner_dropdown).
 * - Standardized bordered spinner styling with visible caret arrow.
 * - Dynamic dependent filtering: changing Division filters Districts; changing District updates APMC Markets.
 * - Invalid dependent selections are cleared when parent filter changes.
 * - User's selected district is retained and restored.
 * - Informative empty state when no records match filter.
 */
public class MarketActivity extends AppCompatActivity implements ApmcPriceAdapter.OnItemClickListener {

    private ImageButton btnBackMarket;
    private Spinner spinnerMarketDivision, spinnerMarketDistrict, spinnerMarketYard, spinnerMarketCommodity;
    private RecyclerView rvApmcPrices;
    private LinearLayout layoutEmptyMarketState;
    private TextView tvEmptyMarketTitle, tvEmptyMarketMessage, tvResultsCount;

    private ApmcDataSourceAdapter apmcAdapter;
    private ApmcPriceAdapter priceAdapter;
    private List<ApmcPrice> currentPrices = new ArrayList<>();
    private UserSessionManager sessionManager;

    private boolean isInitializing = true;
    private String savedDistrict = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market);

        apmcAdapter = new ApmcDataSourceAdapter(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupSpinners();
        setupRecyclerView();
        setupListeners();

        isInitializing = false;
        applyFilter();
    }

    private void initViews() {
        btnBackMarket = findViewById(R.id.btnBackMarket);
        spinnerMarketDivision = findViewById(R.id.spinnerMarketDivision);
        spinnerMarketDistrict = findViewById(R.id.spinnerMarketDistrict);
        spinnerMarketYard = findViewById(R.id.spinnerMarketYard);
        spinnerMarketCommodity = findViewById(R.id.spinnerMarketCommodity);
        rvApmcPrices = findViewById(R.id.rvApmcPrices);
        layoutEmptyMarketState = findViewById(R.id.layoutEmptyMarketState);
        tvEmptyMarketTitle = findViewById(R.id.tvEmptyMarketTitle);
        tvEmptyMarketMessage = findViewById(R.id.tvEmptyMarketMessage);
        tvResultsCount = findViewById(R.id.tvResultsCount);
    }

    private void setupSpinners() {
        // 1. Division Spinner
        ArrayAdapter<String> divisionAdapter = new ArrayAdapter<>(this,
                R.layout.item_spinner_selected, ApmcDataSourceAdapter.DIVISIONS);
        divisionAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerMarketDivision.setAdapter(divisionAdapter);

        // 2. District Spinner (Initial full list)
        updateDistrictSpinner("All Divisions");

        // 3. APMC Market Spinner (Initial markets for district)
        String initialDistrict = sessionManager.getUserDistrict();
        if (initialDistrict == null || initialDistrict.isEmpty()) {
            initialDistrict = "Pune";
        }
        savedDistrict = initialDistrict;
        selectDistrictInSpinner(initialDistrict);
        updateMarketSpinner(initialDistrict);

        // 4. Commodity Spinner
        ArrayAdapter<String> commodityAdapter = new ArrayAdapter<>(this,
                R.layout.item_spinner_selected, ApmcDataSourceAdapter.COMMODITIES);
        commodityAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerMarketCommodity.setAdapter(commodityAdapter);
    }

    private void updateDistrictSpinner(String selectedDivision) {
        List<String> districts = ApmcDataSourceAdapter.getDistrictsForDivision(selectedDivision);
        ArrayAdapter<String> districtAdapter = new ArrayAdapter<>(this,
                R.layout.item_spinner_selected, districts);
        districtAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerMarketDistrict.setAdapter(districtAdapter);
    }

    private void updateMarketSpinner(String selectedDistrict) {
        List<String> markets = ApmcDataSourceAdapter.getMarketsForDistrict(selectedDistrict);
        ArrayAdapter<String> marketAdapter = new ArrayAdapter<>(this,
                R.layout.item_spinner_selected, markets);
        marketAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerMarketYard.setAdapter(marketAdapter);
    }

    private void selectDistrictInSpinner(String districtName) {
        if (districtName == null) return;
        String baseName = ApmcDataSourceAdapter.extractBaseName(districtName);
        for (int i = 0; i < spinnerMarketDistrict.getCount(); i++) {
            String item = spinnerMarketDistrict.getItemAtPosition(i).toString();
            if (ApmcDataSourceAdapter.extractBaseName(item).equalsIgnoreCase(baseName)) {
                spinnerMarketDistrict.setSelection(i);
                break;
            }
        }
    }

    private void setupRecyclerView() {
        rvApmcPrices.setLayoutManager(new LinearLayoutManager(this));
        priceAdapter = new ApmcPriceAdapter(this, currentPrices, this);
        rvApmcPrices.setAdapter(priceAdapter);
    }

    private void setupListeners() {
        btnBackMarket.setOnClickListener(v -> finish());

        // Division Selection Listener
        spinnerMarketDivision.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializing) return;
                String selectedDivision = spinnerMarketDivision.getSelectedItem().toString();
                updateDistrictSpinner(selectedDivision);
                // When division changes, reset market yard to all
                updateMarketSpinner("");
                applyFilter();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // District Selection Listener
        spinnerMarketDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializing) return;
                String selectedDistrict = spinnerMarketDistrict.getSelectedItem().toString();
                savedDistrict = selectedDistrict;
                // Update dependent APMC markets dropdown for this district
                updateMarketSpinner(selectedDistrict);
                applyFilter();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // APMC Market Selection Listener
        spinnerMarketYard.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializing) return;
                applyFilter();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Commodity Selection Listener
        spinnerMarketCommodity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (isInitializing) return;
                applyFilter();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void applyFilter() {
        String selectedDivision = (spinnerMarketDivision.getSelectedItem() != null)
                ? spinnerMarketDivision.getSelectedItem().toString() : "";
        String selectedDistrict = (spinnerMarketDistrict.getSelectedItem() != null)
                ? spinnerMarketDistrict.getSelectedItem().toString() : "";
        String selectedMarket = (spinnerMarketYard.getSelectedItem() != null)
                ? spinnerMarketYard.getSelectedItem().toString() : "";
        String selectedCommodity = (spinnerMarketCommodity.getSelectedItem() != null)
                ? spinnerMarketCommodity.getSelectedItem().toString() : "";

        currentPrices = apmcAdapter.getMarketPrices(selectedDivision, selectedDistrict, selectedMarket, selectedCommodity);
        priceAdapter.updateList(currentPrices);

        if (tvResultsCount != null) {
            tvResultsCount.setText(currentPrices.size() + " नोंदी");
        }

        if (currentPrices.isEmpty()) {
            layoutEmptyMarketState.setVisibility(View.VISIBLE);
            rvApmcPrices.setVisibility(View.GONE);

            String cleanDistrict = ApmcDataSourceAdapter.extractBaseName(selectedDistrict);
            String cleanComm = ApmcDataSourceAdapter.extractBaseName(selectedCommodity);
            String cleanMarket = ApmcDataSourceAdapter.extractBaseName(selectedMarket);

            if (!cleanComm.isEmpty() && !cleanComm.startsWith("All")) {
                tvEmptyMarketTitle.setText(cleanComm + " चे बाजारभाव उपलब्ध नाहीत");
                tvEmptyMarketMessage.setText("'" + cleanDistrict + "' जिल्ह्यातील '" + cleanMarket + "' बाजारात "
                        + cleanComm + " चे आजचे अधिकृत सौदे उपलब्ध नाहीत. कृपया इतर बाजार समिती निवडा किंवा मागील तारखेचे दर तपासा.");
            } else {
                tvEmptyMarketTitle.setText("बाजारभाव माहिती उपलब्ध नाही");
                tvEmptyMarketMessage.setText("निवडलेल्या निकषांनुसार सद्यस्थितीत कोणतेही दर उपलब्ध नाहीत. कृपया दुसरा जिल्हा किंवा सर्व शेतमाल निवडून पहा.");
            }
        } else {
            layoutEmptyMarketState.setVisibility(View.GONE);
            rvApmcPrices.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (savedDistrict != null) {
            outState.putString("saved_district", savedDistrict);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState != null && savedInstanceState.containsKey("saved_district")) {
            savedDistrict = savedInstanceState.getString("saved_district");
            selectDistrictInSpinner(savedDistrict);
        }
    }

    @Override
    public void onItemClick(ApmcPrice price) {
        Intent intent = new Intent(MarketActivity.this, MarketDetailActivity.class);
        intent.putExtra("extra_apmc_price", price);
        startActivity(intent);
    }
}
