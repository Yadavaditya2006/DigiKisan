package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing localized agro-meteorological forecast for a Maharashtra district.
 */
public class WeatherReport implements Serializable {
    private String district;
    private String forecastDate;
    private double currentTemp;
    private double minTemp;
    private double maxTemp;
    private int rainfallProbability; // %
    private double rainfallAmountMm; // mm
    private int humidity; // %
    private double windSpeedKmh;
    private String windDirection;
    private String conditionSummary;
    private String weatherWarning; // "GREEN", "YELLOW", "ORANGE", "RED" or warning message
    private String farmingAdvisory;
    private String lastUpdated;

    public WeatherReport() {}

    public WeatherReport(String district, String forecastDate, double currentTemp, 
                         double minTemp, double maxTemp, int rainfallProbability, 
                         double rainfallAmountMm, int humidity, double windSpeedKmh, 
                         String windDirection, String conditionSummary, String weatherWarning, 
                         String farmingAdvisory, String lastUpdated) {
        this.district = district;
        this.forecastDate = forecastDate;
        this.currentTemp = currentTemp;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.rainfallProbability = rainfallProbability;
        this.rainfallAmountMm = rainfallAmountMm;
        this.humidity = humidity;
        this.windSpeedKmh = windSpeedKmh;
        this.windDirection = windDirection;
        this.conditionSummary = conditionSummary;
        this.weatherWarning = weatherWarning;
        this.farmingAdvisory = farmingAdvisory;
        this.lastUpdated = lastUpdated;
    }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getForecastDate() { return forecastDate; }
    public void setForecastDate(String forecastDate) { this.forecastDate = forecastDate; }

    public double getCurrentTemp() { return currentTemp; }
    public void setCurrentTemp(double currentTemp) { this.currentTemp = currentTemp; }

    public double getMinTemp() { return minTemp; }
    public void setMinTemp(double minTemp) { this.minTemp = minTemp; }

    public double getMaxTemp() { return maxTemp; }
    public void setMaxTemp(double maxTemp) { this.maxTemp = maxTemp; }

    public int getRainfallProbability() { return rainfallProbability; }
    public void setRainfallProbability(int rainfallProbability) { this.rainfallProbability = rainfallProbability; }

    public double getRainfallAmountMm() { return rainfallAmountMm; }
    public void setRainfallAmountMm(double rainfallAmountMm) { this.rainfallAmountMm = rainfallAmountMm; }

    public int getHumidity() { return humidity; }
    public void setHumidity(int humidity) { this.humidity = humidity; }

    public double getWindSpeedKmh() { return windSpeedKmh; }
    public void setWindSpeedKmh(double windSpeedKmh) { this.windSpeedKmh = windSpeedKmh; }

    public String getWindDirection() { return windDirection; }
    public void setWindDirection(String windDirection) { this.windDirection = windDirection; }

    public String getConditionSummary() { return conditionSummary; }
    public void setConditionSummary(String conditionSummary) { this.conditionSummary = conditionSummary; }

    public String getWeatherWarning() { return weatherWarning; }
    public void setWeatherWarning(String weatherWarning) { this.weatherWarning = weatherWarning; }

    public String getFarmingAdvisory() { return farmingAdvisory; }
    public void setFarmingAdvisory(String farmingAdvisory) { this.farmingAdvisory = farmingAdvisory; }

    public String getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(String lastUpdated) { this.lastUpdated = lastUpdated; }
}
