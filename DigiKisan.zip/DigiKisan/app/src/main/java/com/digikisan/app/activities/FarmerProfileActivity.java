package com.digikisan.app.activities;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.models.User;
import com.digikisan.app.services.ApmcDataSourceAdapter;
import com.digikisan.app.utils.InputValidator;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * FarmerProfileActivity allows the farmer to maintain personal and farm details.
 */
public class FarmerProfileActivity extends AppCompatActivity {

    private ImageButton btnBackProfile;
    private TextInputEditText etProfileName, etProfileMobile, etProfileTaluka;
    private Spinner spinnerProfileDistrict, spinnerProfileCrop;
    private TextInputEditText etCropVariety, etLandArea, etProfileSowingDate;
    private MaterialButton btnSaveProfile;

    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;
    private final Calendar calendar = Calendar.getInstance();

    private static final String[] CROPS = {
            "Soybean (सोयाबीन)", "Cotton (कापूस)", "Onion (कांदा)", "Sugarcane (ऊस)",
            "Gram / Chana (हरभरा)", "Wheat (गहू)", "Pomegranate (डाळिंब)", "Tomato (टोमॅटो)", "Grapes (द्राक्षे)"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_profile);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupSpinners();
        setupDatePicker();
        loadProfileData();
        setupListeners();
    }

    private void initViews() {
        btnBackProfile = findViewById(R.id.btnBackProfile);
        etProfileName = findViewById(R.id.etProfileName);
        etProfileMobile = findViewById(R.id.etProfileMobile);
        spinnerProfileDistrict = findViewById(R.id.spinnerProfileDistrict);
        etProfileTaluka = findViewById(R.id.etProfileTaluka);
        spinnerProfileCrop = findViewById(R.id.spinnerProfileCrop);
        etCropVariety = findViewById(R.id.etCropVariety);
        etLandArea = findViewById(R.id.etLandArea);
        etProfileSowingDate = findViewById(R.id.etProfileSowingDate);
        btnSaveProfile = findViewById(R.id.btnSaveProfile);
    }

    private void setupSpinners() {
        List<String> districts = new ArrayList<>(Arrays.asList(ApmcDataSourceAdapter.DISTRICTS));
        if (!districts.isEmpty() && districts.get(0).startsWith("All")) {
            districts.remove(0);
        }
        ArrayAdapter<String> distAdapter = new ArrayAdapter<>(this, R.layout.item_spinner_selected, districts);
        distAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerProfileDistrict.setAdapter(distAdapter);

        ArrayAdapter<String> cropAdapter = new ArrayAdapter<>(this, R.layout.item_spinner_selected, CROPS);
        cropAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerProfileCrop.setAdapter(cropAdapter);
    }

    private void setupDatePicker() {
        etProfileSowingDate.setOnClickListener(v -> {
            DatePickerDialog dialog = new DatePickerDialog(
                    FarmerProfileActivity.this,
                    (view, year, month, dayOfMonth) -> {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        String selected = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime());
                        etProfileSowingDate.setText(selected);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            dialog.show();
        });
    }

    private void loadProfileData() {
        long userId = sessionManager.getUserId();
        User user = dbHelper.getUserById(userId);
        if (user != null) {
            etProfileName.setText(user.getFullName());
            etProfileMobile.setText(user.getMobileNumber());
            etProfileTaluka.setText(user.getTaluka());

            // Match district spinner
            String baseUserDist = ApmcDataSourceAdapter.extractBaseName(user.getDistrict());
            for (int i = 0; i < spinnerProfileDistrict.getCount(); i++) {
                String item = spinnerProfileDistrict.getItemAtPosition(i).toString();
                if (ApmcDataSourceAdapter.extractBaseName(item).equalsIgnoreCase(baseUserDist)) {
                    spinnerProfileDistrict.setSelection(i);
                    break;
                }
            }
        }

        FarmProfile fp = dbHelper.getFarmProfile(userId);
        if (fp != null) {
            etCropVariety.setText(fp.getCropVariety());
            etLandArea.setText(String.valueOf(fp.getLandAreaAcres()));
            etProfileSowingDate.setText(fp.getSowingDate());

            for (int i = 0; i < CROPS.length; i++) {
                if (CROPS[i].contains(fp.getPrimaryCrop())) {
                    spinnerProfileCrop.setSelection(i);
                    break;
                }
            }
        }
    }

    private void setupListeners() {
        btnBackProfile.setOnClickListener(v -> finish());
        btnSaveProfile.setOnClickListener(v -> saveProfileChanges());
    }

    private void saveProfileChanges() {
        long userId = sessionManager.getUserId();
        String name = (etProfileName.getText() != null) ? etProfileName.getText().toString().trim() : "";
        String rawDist = (spinnerProfileDistrict.getSelectedItem() != null) ? spinnerProfileDistrict.getSelectedItem().toString() : "Pune";
        String district = ApmcDataSourceAdapter.extractBaseName(rawDist);
        String taluka = (etProfileTaluka.getText() != null) ? etProfileTaluka.getText().toString().trim() : "";

        if (name.isEmpty()) {
            Toast.makeText(this, "नाव आवश्यक आहे", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update User
        dbHelper.updateUserProfile(userId, name, district, taluka);
        sessionManager.updateUserName(name);
        sessionManager.updateDistrict(district);

        // Update Farm Profile
        String crop = (spinnerProfileCrop.getSelectedItem() != null) ? spinnerProfileCrop.getSelectedItem().toString() : "Soybean";
        String variety = (etCropVariety.getText() != null) ? etCropVariety.getText().toString().trim() : "";
        String sowingDate = (etProfileSowingDate.getText() != null) ? etProfileSowingDate.getText().toString().trim() : "2024-06-25";
        String landStr = (etLandArea.getText() != null) ? etLandArea.getText().toString().trim() : "2.0";
        double land = InputValidator.isValidPositiveNumber(landStr) ? Double.parseDouble(landStr) : 2.0;

        FarmProfile fp = new FarmProfile(
                0, userId, crop, variety, sowingDate, land, "Black Cotton", "Drip", "Weekly", ""
        );
        dbHelper.saveOrUpdateFarmProfile(fp);

        Toast.makeText(this, R.string.profile_updated, Toast.LENGTH_SHORT).show();
        finish();
    }
}
