package com.digikisan.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.digikisan.app.R;
import com.digikisan.app.models.WeatherReport;
import com.digikisan.app.services.ApmcDataSourceAdapter;
import com.digikisan.app.services.WeatherServiceAdapter;
import com.digikisan.app.utils.UserSessionManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * WeatherActivity displaying localized agro-meteorological forecasts and advisories.
 */
public class WeatherActivity extends AppCompatActivity {

    private ImageButton btnBackWeather;
    private Spinner spinnerWeatherDistrict;
    private TextView tvWeatherDistrictHeader, tvWeatherDate, tvWeatherWarningBadge;
    private TextView tvCurrentTemp, tvConditionSummary, tvTempMinMax, tvRainfallProb;
    private TextView tvHumidity, tvWindSpeed, tvFarmingAdvisory, tvWeatherDisclaimer;

    private WeatherServiceAdapter weatherAdapter;
    private UserSessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        weatherAdapter = new WeatherServiceAdapter(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupDistrictSpinner();
        setupListeners();
    }

    private void initViews() {
        btnBackWeather = findViewById(R.id.btnBackWeather);
        spinnerWeatherDistrict = findViewById(R.id.spinnerWeatherDistrict);
        tvWeatherDistrictHeader = findViewById(R.id.tvWeatherDistrictHeader);
        tvWeatherDate = findViewById(R.id.tvWeatherDate);
        tvWeatherWarningBadge = findViewById(R.id.tvWeatherWarningBadge);
        tvCurrentTemp = findViewById(R.id.tvCurrentTemp);
        tvConditionSummary = findViewById(R.id.tvConditionSummary);
        tvTempMinMax = findViewById(R.id.tvTempMinMax);
        tvRainfallProb = findViewById(R.id.tvRainfallProb);
        tvHumidity = findViewById(R.id.tvHumidity);
        tvWindSpeed = findViewById(R.id.tvWindSpeed);
        tvFarmingAdvisory = findViewById(R.id.tvFarmingAdvisory);
        tvWeatherDisclaimer = findViewById(R.id.tvWeatherDisclaimer);
    }

    private void setupDistrictSpinner() {
        List<String> districts = new ArrayList<>(Arrays.asList(ApmcDataSourceAdapter.DISTRICTS));
        if (!districts.isEmpty() && districts.get(0).startsWith("All")) {
            districts.remove(0);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner_selected, districts);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerWeatherDistrict.setAdapter(adapter);

        String userDistrict = sessionManager.getUserDistrict();
        if (userDistrict != null) {
            String baseUserDist = ApmcDataSourceAdapter.extractBaseName(userDistrict);
            for (int i = 0; i < districts.size(); i++) {
                if (ApmcDataSourceAdapter.extractBaseName(districts.get(i)).equalsIgnoreCase(baseUserDist)) {
                    spinnerWeatherDistrict.setSelection(i);
                    break;
                }
            }
        }
    }

    private void setupListeners() {
        btnBackWeather.setOnClickListener(v -> finish());

        spinnerWeatherDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String rawDistrict = parent.getItemAtPosition(position).toString();
                String district = ApmcDataSourceAdapter.extractBaseName(rawDistrict);
                displayWeather(district);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void displayWeather(String district) {
        WeatherReport report = weatherAdapter.getWeatherForDistrict(district);

        tvWeatherDistrictHeader.setText(report.getDistrict() + " (महाराष्ट्र)");
        tvWeatherDate.setText("अंदाज तारीख: " + report.getForecastDate());
        tvCurrentTemp.setText(report.getCurrentTemp() + "°C");
        tvConditionSummary.setText(report.getConditionSummary());
        tvTempMinMax.setText(report.getMinTemp() + "°C - " + report.getMaxTemp() + "°C");
        tvRainfallProb.setText(report.getRainfallProbability() + "% (" + report.getRainfallAmountMm() + " mm)");
        tvHumidity.setText(report.getHumidity() + " %");
        tvWindSpeed.setText(report.getWindSpeedKmh() + " km/h (" + report.getWindDirection() + ")");
        tvFarmingAdvisory.setText(report.getFarmingAdvisory());

        // Weather Warning Badge
        String warning = report.getWeatherWarning();
        if ("RED".equalsIgnoreCase(warning)) {
            tvWeatherWarningBadge.setText("RED ALERT (दक्षता)");
            tvWeatherWarningBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_risk));
            tvWeatherWarningBadge.setTextColor(ContextCompat.getColor(this, R.color.status_high_risk));
        } else if ("YELLOW".equalsIgnoreCase(warning) || "ORANGE".equalsIgnoreCase(warning)) {
            tvWeatherWarningBadge.setText("ALERT (लक्ष ठेवा)");
            tvWeatherWarningBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_attention));
            tvWeatherWarningBadge.setTextColor(ContextCompat.getColor(this, R.color.status_attention));
        } else {
            tvWeatherWarningBadge.setText("NORMAL (सामान्य)");
            tvWeatherWarningBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_good));
            tvWeatherWarningBadge.setTextColor(ContextCompat.getColor(this, R.color.status_good));
        }

        tvWeatherDisclaimer.setText("माहिती स्रोत: " + report.getLastUpdated() + " | स्थानिक पातळीवर थोडाफार फरक असू शकतो.");
    }
}
