package com.digikisan.app.services;

import android.content.Context;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.ApmcPrice;
import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.models.User;
import com.digikisan.app.models.WeatherReport;

import java.util.List;
import java.util.Locale;

/**
 * Intelligent Multilingual Natural Conversational Chatbot Engine for "शेतकरी मित्र" (Shetkari Mitra).
 * 
 * Supports:
 * - Marathi written in Devanagari
 * - English
 * - Hinglish (Hindi written in Roman/English script or mixed)
 * - Romanized Marathi (Marathi written in Roman/English script e.g., "Mala onion cha aajcha bhav sang")
 * - Conversational context retention across multi-turn interactions (e.g. "Kal peksha vadhla ka?", "Mag kami ka zala?")
 * - Authentic data queries (APMC market prices, weather advisories, verified government schemes)
 * - Zero hallucination / no fabricated facts.
 */
public class FarmerChatbotEngine {

    public enum LanguageType {
        MARATHI_DEVANAGARI,
        MARATHI_ROMANIZED,
        HINGLISH,
        ENGLISH
    }

    private final Context context;
    private final DatabaseHelper dbHelper;
    private final WeatherServiceAdapter weatherAdapter;

    // Conversational Context Memory
    private String lastReferencedDistrict = null;
    private String lastReferencedCommodity = null;
    private String lastReferencedMarket = null;
    private ApmcPrice lastRetrievedPrice = null;
    private LanguageType lastLanguage = LanguageType.MARATHI_ROMANIZED;

    public FarmerChatbotEngine(Context context) {
        this.context = context;
        this.dbHelper = DatabaseHelper.getInstance(context);
        this.weatherAdapter = new WeatherServiceAdapter(context);
    }

    /**
     * Main conversation handler accepting user query, user ID, and fallback district.
     */
    public synchronized String generateResponse(String userQuery, long userId, String currentDistrict) {
        if (userQuery == null || userQuery.trim().isEmpty()) {
            return "रामराम शेतकरी बांधव! कृपया आपला शेतीविषयक प्रश्न किंवा शंका विचारा.";
        }

        String rawQuery = userQuery.trim();
        LanguageType lang = detectLanguage(rawQuery);
        this.lastLanguage = lang;

        String normalized = rawQuery.toLowerCase(Locale.ROOT);
        User user = (userId > 0) ? dbHelper.getUserById(userId) : null;
        String userDistrict = (user != null && user.getDistrict() != null && !user.getDistrict().isEmpty())
                ? user.getDistrict()
                : ((currentDistrict != null && !currentDistrict.isEmpty()) ? currentDistrict : "Pune");

        // -----------------------------------------------------------------------------------------
        // 1. CONVERSATIONAL FOLLOW-UP: "Why did price fall / rise?" ("Mag kami ka zala?", "Why is it down?")
        // -----------------------------------------------------------------------------------------
        if (isWhyPriceExplanationIntent(normalized)) {
            return handlePriceExplanationFollowUp(lang);
        }

        // -----------------------------------------------------------------------------------------
        // 2. CONVERSATIONAL FOLLOW-UP: "Compare with yesterday" ("Kal peksha vadhla ka?", "Kal se badha kya?")
        // -----------------------------------------------------------------------------------------
        if (isPriceComparisonIntent(normalized)) {
            return handlePriceComparisonFollowUp(lang);
        }

        // -----------------------------------------------------------------------------------------
        // 3. GREETINGS & INTRODUCTIONS
        // -----------------------------------------------------------------------------------------
        if (isGreeting(normalized)) {
            String name = (user != null) ? user.getFullName() : "शेतकरी बांधव";
            switch (lang) {
                case ENGLISH:
                    return "Hello " + name + "! I am Shetkari Mitra, your farming assistant. You can ask me about today's APMC mandi rates, weather forecast, government schemes, or crop advice. How can I help you today?";
                case HINGLISH:
                    return "Namaste " + name + " ji! Main aapka Shetkari Mitra hoon. Aaj kheti ke baare me kya janna chahte hain? Aap Mandi bhav, mausam, sarkari yojana ya fasal salah pooch sakte hain.";
                case MARATHI_ROMANIZED:
                    return "Ramram " + name + " ji! Mi aapla Shetkari Mitra. Aaj shetibaddal kay janun ghyaycha aahe? Aapan APMC bazaar bhav, havaman, sarkaari yojana kivha peek salla vicharu shakta.";
                default:
                    return "रामराम " + name + " जी! मी आपला शेतकरी मित्र. आज शेतीबद्दल काय जाणून घ्यायचे आहे? आपण बाजारभाव, हवामान अंदाज, सरकारी योजना किंवा पीक सल्ला विचारू शकता.";
            }
        }

        // -----------------------------------------------------------------------------------------
        // 4. APP NAVIGATION & HOW-TO (e.g. "District select kasa karaycha?", "How to select district?")
        // -----------------------------------------------------------------------------------------
        if (normalized.contains("district select") || normalized.contains("jilha select") ||
            normalized.contains("select kasa") || normalized.contains("kasa karaycha") ||
            normalized.contains("how to select") || normalized.contains("dropdown")) {
            switch (lang) {
                case ENGLISH:
                    return "To select a District: Open 'APMC Market' or 'My Profile', tap the 'District / Jilha' dropdown box with the downward arrow (▼). A list of all 36 Maharashtra districts will appear. Tap your district name, and it will be selected and displayed inside the box.";
                case HINGLISH:
                    return "District select karne ke liye: 'APMC Market' ya 'Farmer Profile' screen par 'District / Jilha' dropdown par tap karein. Maharashtra ke sabhi 36 zilon ki list khulegi. Apna zila chunein, wo field me save ho jayega.";
                case MARATHI_ROMANIZED:
                    return "District / Jilha select karnyasaathi: 'APMC Market' kivha 'Profile' screen var jaun 'Jilha (District)' dropdown var tap kara. Tethe Maharashtratil 36 jilhyanchi yadi disel. Apla jilha nivda, to screen var disel ani tyache bhav load hotil.";
                default:
                    return "जिल्हा निवडण्यासाठी: 'APMC Market' किंवा 'प्रोफाइल' स्क्रीनवर 'जिल्हा (District)' ड्रॉपडाउनवर टॅप करा. तेथे महाराष्ट्रातील सर्व ३६ जिल्ह्यांची यादी उघडेल. आपला जिल्हा निवडा, तो बॉक्समध्ये दिसेल आणि त्या जिल्ह्यातील बाजार समित्यांचे ताजे दर स्क्रीनवर लोड होतील.";
            }
        }

        // -----------------------------------------------------------------------------------------
        // 5. APMC BAZAAR BHAV / MANDI PRICE LOOKUP
        // -----------------------------------------------------------------------------------------
        if (isPriceLookupIntent(normalized)) {
            String extractedCommodity = extractCommodity(normalized);
            String extractedDistrict = extractDistrict(normalized);

            // Handle "in my district" / "majhya jilhyat" / "mere jile me"
            if (extractedDistrict == null && (normalized.contains("majhya") || normalized.contains("mazya") ||
                normalized.contains("mere") || normalized.contains("my district") || normalized.contains("माझ्या"))) {
                extractedDistrict = userDistrict;
            }

            // Fallback to active/last referenced district if still unspecified
            if (extractedDistrict == null) {
                if (lastReferencedDistrict != null) {
                    extractedDistrict = lastReferencedDistrict;
                } else {
                    extractedDistrict = userDistrict;
                }
            }

            // Fallback commodity to last discussed commodity if unspecified
            if (extractedCommodity == null && lastReferencedCommodity != null) {
                extractedCommodity = lastReferencedCommodity;
            } else if (extractedCommodity == null) {
                extractedCommodity = "Onion"; // Most active default
            }

            return handlePriceLookup(extractedDistrict, extractedCommodity, lang);
        }

        // -----------------------------------------------------------------------------------------
        // 6. WEATHER FORECAST LOOKUP
        // -----------------------------------------------------------------------------------------
        if (isWeatherIntent(normalized)) {
            String extractedDistrict = extractDistrict(normalized);
            if (extractedDistrict == null) {
                extractedDistrict = (lastReferencedDistrict != null) ? lastReferencedDistrict : userDistrict;
            }
            return handleWeatherQuery(extractedDistrict, lang);
        }

        // -----------------------------------------------------------------------------------------
        // 7. GOVERNMENT SCHEMES & SUBSIDIES
        // -----------------------------------------------------------------------------------------
        if (isSchemeIntent(normalized)) {
            return handleSchemeQuery(normalized, lang);
        }

        // -----------------------------------------------------------------------------------------
        // 8. CROP ASSESSMENT & FARMING ADVICE (Watering, Pest, Disease)
        // -----------------------------------------------------------------------------------------
        if (isFarmingAdviceIntent(normalized)) {
            return handleFarmingAdvice(normalized, lang);
        }

        // -----------------------------------------------------------------------------------------
        // 9. HELPLINE & TOLL-FREE NUMBERS
        // -----------------------------------------------------------------------------------------
        if (normalized.contains("helpline") || normalized.contains("call") || normalized.contains("phone") ||
            normalized.contains("number") || normalized.contains("नंबर") || normalized.contains("संपर्क")) {
            switch (lang) {
                case ENGLISH:
                    return "Official Maharashtra & Central Kisan Helplines:\n• Kisan Call Centre (Toll-Free): 1800-180-1551 (6 AM - 10 PM)\n• MahaDBT Farmer Helpline: 022-49150800\n• Crop Insurance Toll-Free: 1800-180-2117";
                case HINGLISH:
                    return "Kisan Helpline Numbers:\n• Kisan Call Centre (Toll-Free): 1800-180-1551\n• MahaDBT Portal Support: 022-49150800\n• Fasal Bima Sahayata: 1800-180-2117";
                case MARATHI_ROMANIZED:
                    return "Shaskiya Kisan Helpline Numbers:\n• Kisan Call Centre (Toll-Free): 1800-180-1551 (Sakali 6 te Ratri 10)\n• MahaDBT Shetkari Helpline: 022-49150800\n• Pik Vima Madat: 1800-180-2117";
                default:
                    return "शासकीय शेतकरी हेल्पलाइन क्रमांक:\n• किसान कॉल सेंटर (टोल-फ्री): १८००-१८०-१५५१ (सकाळी ६ ते रात्री १०)\n• महाडीबीटी शेतकरी हेल्पलाइन: ०२२-४९१५०८००\n• पीक विमा तक्रार निवारण: १८००-१८०-२११७";
            }
        }

        // -----------------------------------------------------------------------------------------
        // 10. DEFAULT GUIDED FALLBACK
        // -----------------------------------------------------------------------------------------
        switch (lang) {
            case ENGLISH:
                return "I understood your question. I can assist you with:\n1. Mandi Rates (e.g. 'What is onion rate in Nashik?')\n2. Weather Forecast (e.g. 'Will it rain today?')\n3. Govt Schemes (e.g. 'Documents for PM Kisan')\n4. Crop Advice (e.g. 'How often to water cotton?')\nPlease ask in simple English or Marathi.";
            case HINGLISH:
                return "Aapka sawaal samjha. Main aapko in vishayon par sahi jaankari de sakta hoon:\n1. Mandi Bhav (e.g. 'Nashik me onion ka aaj ka bhav?')\n2. Mausam Andaaz (e.g. 'Aaj barish hogi kya?')\n3. Sarkari Yojana (e.g. 'Drip subsidy kaise milegi?')\n4. Fasal Dekhbhal salah\nKripya apna sawaal poochein.";
            case MARATHI_ROMANIZED:
                return "Aapla prashna samjla. Mi khaliil babinbaddal khatrishir mahiti deu shakto:\n1. APMC Bazaar Bhav (e.g. 'Mala Nashik madhla onion bhav sang')\n2. Havaman Andaaz (e.g. 'Paus padnar aahe ka?')\n3. Sarkaari Yojana (e.g. 'PM Kisan sathi documents')\n4. Peek Salla (e.g. 'Soybean la pani kiti vela dyaycha?')\nKripya apla prashna vichara.";
            default:
                return "आपला प्रश्न समजला. मी खालील विषयांवर खरी व अधिकृत माहिती देऊ शकतो:\n१. APMC बाजारभाव (उदा: 'नाशिकमधील कांद्याचा भाव सांगा')\n२. हवामान अंदाज (उदा: 'आज पाऊस पडेल का?')\n३. सरकारी योजना (उदा: 'पीएम किसान योजनेची कागदपत्रे')\n४. पीक आरोग्य आणि सिंचन सल्ला\nकृपया आपला प्रश्न या स्वरूपात विचारावा!";
        }
    }

    // =============================================================================================
    // INTENT & CONTEXT HANDLERS
    // =============================================================================================

    private String handlePriceLookup(String district, String commodity, LanguageType lang) {
        // Query database
        List<ApmcPrice> prices = dbHelper.getApmcPricesByFilter(district, commodity);
        
        // If exact district had no records, search without district to see if crop exists elsewhere
        if (prices.isEmpty()) {
            prices = dbHelper.getApmcPricesByFilter("", commodity);
        }

        if (prices.isEmpty()) {
            switch (lang) {
                case ENGLISH:
                    return "No recent APMC Bazaar Bhav data is available for " + commodity + " in " + district + ". Please check another market or verify the observation date.";
                case HINGLISH:
                    return district + " mandi me " + commodity + " ke aaj ke bhav uplabdh nahi hain. Kripya doosri market chunein ya APMC Market tab dekhein.";
                case MARATHI_ROMANIZED:
                    return district + " jilhyat " + commodity + " che aajche APMC bhav uplabdh nahit. Kripya dusri market yard kivha APMC tab check kara.";
                default:
                    return "'" + district + "' बाजार समितीत '" + commodity + "' चे आजचे अधिकृत सौदे नोंदवले गेलेले नाहीत. कृपया नजीकची दुसरी बाजार समिती निवडा किंवा 'APMC Market' टॅब तपासा.";
            }
        }

        ApmcPrice p = prices.get(0);
        // Save to active conversational context!
        this.lastReferencedDistrict = p.getDistrict();
        this.lastReferencedCommodity = p.getCommodity();
        this.lastReferencedMarket = p.getMarketName();
        this.lastRetrievedPrice = p;

        int modal = (int) p.getModalPrice();
        int min = (int) p.getMinPrice();
        int max = (int) p.getMaxPrice();
        int arrivals = p.getArrivalsQuantity();

        switch (lang) {
            case ENGLISH:
                return p.getMarketName() + " (" + p.getDistrict() + ") Mandi Bhav for " + p.getCommodity() + " (" + p.getObservationDate() + "):\n"
                        + "• Modal Price: ₹" + modal + " / Quintal\n"
                        + "• Price Range: ₹" + min + " - ₹" + max + "\n"
                        + "• Arrivals: " + arrivals + " Quintals\n"
                        + "• Trend: " + p.getPriceTrend() + "\n"
                        + "• Source: " + p.getDataProvider();
            case HINGLISH:
                return p.getMarketName() + " (" + p.getDistrict() + ") Mandi me " + p.getCommodity() + " ka aaj ka bhav (" + p.getObservationDate() + "):\n"
                        + "• Sarvasadharan (Modal) Rate: ₹" + modal + " prati quintal\n"
                        + "• Minimum: ₹" + min + " | Maximum: ₹" + max + "\n"
                        + "• Aawak: " + arrivals + " quintal\n"
                        + "• Trend: " + p.getPriceTrend() + " (Source: " + p.getDataProvider() + ")";
            case MARATHI_ROMANIZED:
                return p.getMarketName() + " (" + p.getDistrict() + ") APMC madhe " + p.getCommodity() + " cha aajcha bhav (" + p.getObservationDate() + "):\n"
                        + "• Sarvasadharan (Modal) Bhav: ₹" + modal + " / Quintal\n"
                        + "• Kiman: ₹" + min + " | Kamal: ₹" + max + "\n"
                        + "• Awam: " + arrivals + " quintal\n"
                        + "• Kal: " + p.getPriceTrend() + " (Source: " + p.getDataProvider() + ")\n"
                        + "Aapan 'Kal peksha vadhla ka?' kivha 'Mag kami ka zala?' asha prashnanni pudhil charcha karu shakta.";
            default:
                return p.getMarketName() + " (" + p.getDistrict() + ") बाजार समितीत " + p.getCommodity() + " चे आजचे अधिकृत भाव (" + p.getObservationDate() + "):\n"
                        + "• सर्वसाधारण भाव (Modal Price): ₹" + modal + " प्रति क्विंटल\n"
                        + "• किमान भाव: ₹" + min + " | कमाल भाव: ₹" + max + "\n"
                        + "• दैनिक आवक: " + arrivals + " क्विंटल\n"
                        + "• बाजार कल: " + p.getPriceTrend() + " (माहिती स्रोत: " + p.getDataProvider() + ")\n"
                        + "आपण 'काल पेक्षा वाढला का?' किंवा 'मग कमी का झाला?' असे विचारू शकता.";
        }
    }

    private String handlePriceComparisonFollowUp(LanguageType lang) {
        if (lastRetrievedPrice == null) {
            switch (lang) {
                case ENGLISH:
                    return "Which commodity and market would you like to compare? For example, ask: 'Show onion price in Nashik'.";
                case HINGLISH:
                    return "Aap kis fasal aur mandi ke bhav ki tulna karna chahte hain? Pehle crop aur district batayein.";
                case MARATHI_ROMANIZED:
                    return "Aaplyala konthya shetmalaachi tulna karaychi aahe? Udaharanarth: 'Nashik madhla onion bhav sang' ase vichara.";
                default:
                    return "आपल्याला कोणत्या शेतमालाची तुलना करायची आहे? कृपया अगोदर शेतमाल व जिल्ह्याचे नाव सांगा (उदा. 'लासलगाव कांदा भाव').";
            }
        }

        ApmcPrice p = lastRetrievedPrice;
        double current = p.getModalPrice();
        double prev = p.getPrevModalPrice();

        if (prev <= 0) {
            switch (lang) {
                case ENGLISH:
                    return "No previous comparable record is registered for " + p.getCommodity() + " in " + p.getMarketName() + ".";
                case HINGLISH:
                    return p.getMarketName() + " me " + p.getCommodity() + " ke pichle din ke data uplabdh nahi hain.";
                case MARATHI_ROMANIZED:
                    return p.getMarketName() + " madhe " + p.getCommodity() + " sathi kalche tulnatmak records uplabdh nahit.";
                default:
                    return p.getMarketName() + " बाजारात " + p.getCommodity() + " चे मागील दिवसाचे अधिकृत तुलनात्मक आकडे उपलब्ध नाहीत.";
            }
        }

        int diff = (int) Math.abs(current - prev);
        if (current > prev) {
            switch (lang) {
                case ENGLISH:
                    return "Yes, the price is RISING compared to yesterday. Yesterday's rate was ₹" + (int) prev
                            + "/Quintal and today's modal rate is ₹" + (int) current + "/Quintal (+₹" + diff + " increase in " + p.getMarketName() + ").";
                case HINGLISH:
                    return "Ji haan, kal ke mukable bhav me BADHOTRI (Tezi) hui hai. Kal ka rate ₹" + (int) prev
                            + " tha, aur aaj ka modal rate ₹" + (int) current + " prati quintal hai (+₹" + diff + " badha hai).";
                case MARATHI_ROMANIZED:
                    return "Hoy, kalchya tulnet bhav VADHLA aahe! Kalcha modal rate ₹" + (int) prev
                            + " hota, ani aajcha rate ₹" + (int) current + " prati quintal nondavla gela aahe (+₹" + diff + " teji).";
                default:
                    return "होय, कालच्या तुलनेत भावात वाढ (तेजी) झाली आहे! कालचा सर्वसाधारण भाव ₹" + (int) prev
                            + " होता, तर आजचा भाव ₹" + (int) current + " प्रति क्विंटल नोंदवला गेला आहे (+₹" + diff + " ची वाढ).";
            }
        } else if (current < prev) {
            switch (lang) {
                case ENGLISH:
                    return "No, the price has FALLEN compared to yesterday. Yesterday's rate was ₹" + (int) prev
                            + "/Quintal and today's modal rate is ₹" + (int) current + "/Quintal (-₹" + diff + " decrease).";
                case HINGLISH:
                    return "Nahi, kal ke mukable bhav KAMI (Mandi) hua hai. Kal ka rate ₹" + (int) prev
                            + " tha aur aaj ₹" + (int) current + " prati quintal ho gaya (-₹" + diff + " kam hua).";
                case MARATHI_ROMANIZED:
                    return "Nahi, kalchya tulnet bhav KAMI zala aahe. Kalcha rate ₹" + (int) prev
                            + " hota ani aajcha modal rate ₹" + (int) current + " prati quintal zala aahe (-₹" + diff + " ghasaran).";
                default:
                    return "नाही, कालच्या तुलनेत भावात घट (मंदी) झाली आहे. कालचा भाव ₹" + (int) prev
                            + " होता, तर आजचा भाव ₹" + (int) current + " प्रति क्विंटल नोंदवला गेला आहे (-₹" + diff + " ची घसरण).";
            }
        } else {
            switch (lang) {
                case ENGLISH:
                    return "The price is RELATIVELY STABLE. Both yesterday and today traded at ₹" + (int) current + " per quintal.";
                case HINGLISH:
                    return "Bhav STHIR hai. Kal aur aaj dono din ₹" + (int) current + " prati quintal par trading hui.";
                case MARATHI_ROMANIZED:
                    return "Bhav STHIR aahe. Kal ani aaj doghi divshi ₹" + (int) current + " prati quintal dar rahila.";
                default:
                    return "भाव स्थिर आहेत. काल व आज दोन्ही दिवशी सर्वसाधारण भाव ₹" + (int) current + " प्रति क्विंटल राहिला.";
            }
        }
    }

    private String handlePriceExplanationFollowUp(LanguageType lang) {
        if (lastRetrievedPrice == null) {
            switch (lang) {
                case ENGLISH:
                    return "Please ask for a crop price first (e.g. 'Why is onion price going down in Nashik?').";
                case HINGLISH:
                    return "Pehle batayein kis fasal ke bhav ki wajah janna chahte hain.";
                case MARATHI_ROMANIZED:
                    return "Aapan adhi konthya shetmalaabaddal vichartay te sanga (e.g. 'Nashik madhla onion bhav sang').";
                default:
                    return "कृपया अगोदर कोणत्या शेतमालाच्या भावाबद्दल जाणून घ्यायचे आहे ते सांगा (उदा. 'लासलगाव कांदा भाव').";
            }
        }

        ApmcPrice p = lastRetrievedPrice;
        String explanation = p.getPriceExplanation();
        if (explanation == null || explanation.isEmpty()) {
            explanation = ApmcDataSourceAdapter.generateMarketExplanation(
                    p.getCommodity(), p.getModalPrice(), p.getPrevModalPrice(), p.getArrivalsQuantity(), p.getPriceTrend()
            );
        }

        switch (lang) {
            case ENGLISH:
                return "Market Analysis for " + p.getCommodity() + " in " + p.getMarketName() + ":\n"
                        + "• Observed Facts: Daily arrivals stand at " + p.getArrivalsQuantity() + " Quintals with trend classified as " + p.getPriceTrend() + ".\n"
                        + "• Evidence & Reason: " + explanation;
            case HINGLISH:
                return p.getMarketName() + " me " + p.getCommodity() + " ke bhav badlav ka karan:\n"
                        + "• Mandi Aawak: " + p.getArrivalsQuantity() + " quintal ki aawak rahi hai.\n"
                        + "• Vishleshan: " + explanation;
            case MARATHI_ROMANIZED:
                return p.getMarketName() + " madhe " + p.getCommodity() + " chya bhav badalche vishleshan:\n"
                        + "• Pratyaksh Aawak: Dainik aawak " + p.getArrivalsQuantity() + " quintal aahe.\n"
                        + "• Karan va Salla: " + explanation;
            default:
                return p.getMarketName() + " बाजारात " + p.getCommodity() + " च्या दरातील बदलाचे अधिकृत विश्लेषण:\n"
                        + "• नोंदवलेली आवक: दैनंदिन आवक " + p.getArrivalsQuantity() + " क्विंटल झाली आहे.\n"
                        + "• वस्तुस्थिती व बाजार कल: " + explanation;
        }
    }

    private String handleWeatherQuery(String district, LanguageType lang) {
        WeatherReport w = weatherAdapter.getWeatherForDistrict(district);
        switch (lang) {
            case ENGLISH:
                return "Weather Forecast for " + district + " (" + w.getForecastDate() + "):\n"
                        + "• Current Temp: " + w.getCurrentTemp() + "°C (" + w.getMinTemp() + "°C - " + w.getMaxTemp() + "°C)\n"
                        + "• Condition: " + w.getConditionSummary() + "\n"
                        + "• Rain Probability: " + w.getRainfallProbability() + "% (" + w.getRainfallAmountMm() + " mm expected)\n"
                        + "• Farming Advisory: " + w.getFarmingAdvisory();
            case HINGLISH:
                return district + " ke liye Mausam Andaaz (" + w.getForecastDate() + "):\n"
                        + "• Taapman: " + w.getCurrentTemp() + "°C (" + w.getMinTemp() + "°C se " + w.getMaxTemp() + "°C)\n"
                        + "• Halat: " + w.getConditionSummary() + "\n"
                        + "• Barish ki Sambhavna: " + w.getRainfallProbability() + "%\n"
                        + "• Kheti Salah: " + w.getFarmingAdvisory();
            case MARATHI_ROMANIZED:
                return district + " jilhyasathi Havaman Andaaz (" + w.getForecastDate() + "):\n"
                        + "• Tapman: " + w.getCurrentTemp() + "°C (Kiman: " + w.getMinTemp() + "°C - Kamal: " + w.getMaxTemp() + "°C)\n"
                        + "• Sthiti: " + w.getConditionSummary() + "\n"
                        + "• Paus Shakayta: " + w.getRainfallProbability() + "% (" + w.getRainfallAmountMm() + " mm)\n"
                        + "• Krushi Salla: " + w.getFarmingAdvisory();
            default:
                return district + " जिल्ह्यासाठी हवामान अंदाज (" + w.getForecastDate() + "):\n"
                        + "• सध्याचे तापमान: " + w.getCurrentTemp() + "°C (किमान: " + w.getMinTemp() + "°C, कमाल: " + w.getMaxTemp() + "°C)\n"
                        + "• स्थिती: " + w.getConditionSummary() + "\n"
                        + "• पावसाची शक्यता: " + w.getRainfallProbability() + "% (अपेक्षित पाऊस: " + w.getRainfallAmountMm() + " मिमी)\n"
                        + "• कृषी सल्ला: " + w.getFarmingAdvisory();
        }
    }

    private String handleSchemeQuery(String query, LanguageType lang) {
        if (query.contains("drip") || query.contains("ठिबक") || query.contains("सिंचन") || query.contains("irrigation") || query.contains("sinchan")) {
            switch (lang) {
                case ENGLISH:
                    return "MahaDBT Micro-Irrigation Scheme (Drip & Sprinkler Subsidy):\n"
                            + "• Benefit: Up to 80% subsidy for small/marginal farmers (<2 Ha), 70% for others.\n"
                            + "• Eligibility: Operational landholding with assured water source in Maharashtra.\n"
                            + "• Required Documents: 7/12 extract, 8-A extract, Aadhaar, water source proof, quotation from registered dealer.\n"
                            + "• Portal: https://mahadbt.maharashtra.gov.in";
                case HINGLISH:
                    return "MahaDBT Drip & Sprinkler Sinchan Yojana:\n"
                            + "• Fayda: Chhote aur seemant kisano ko 80% tak anudan milta hai.\n"
                            + "• Zaroori Kagazat: 7/12, 8-A utara, Aadhaar card, water source certificate, dealer quotation.\n"
                            + "• Apply: MahaDBT Farmer portal par online aavedan karein.";
                case MARATHI_ROMANIZED:
                    return "MahaDBT Thibak va Tushar Sinchan Anudan Yojana:\n"
                            + "• Fayda: Alpa va atyalpa bhoodharak shetkarayana 80% paryant anudan milte.\n"
                            + "• Kagadpatre: 7/12 utara, 8-A utara, Aadhaar card, paanyachya strotachi nond, dealer che quotation.\n"
                            + "• Portal: mahadbt.maharashtra.gov.in var 'Kisan Yojana' section madhun apply kara.";
                default:
                    return "महाडीबीटी ठिबक व तुषार सिंचन अनुदान योजना:\n"
                            + "• लाभ: अल्प व अत्यल्प भूधारकांना ८०% पर्यंत, तर इतर शेतकऱ्यांना ७०% पर्यंत अनुदान मिळते.\n"
                            + "• आवश्यक कागदपत्रे: ७/१२ उतारा, ८-अ उतारा, आधार कार्ड, पाण्याचा स्रोत दाखला, अधिकृत विक्रेत्याचे कोटेशन.\n"
                            + "• अर्ज प्रक्रिया: महाडीबीटी शेतकरी पोर्टलवर (mahadbt.maharashtra.gov.in) ऑनलाइन नोंदणी करा.";
            }
        }

        if (query.contains("pm kisan") || query.contains("pmkisan") || query.contains("पीएम किसान") || query.contains("namo") || query.contains("नमो")) {
            switch (lang) {
                case ENGLISH:
                    return "PM Kisan Samman Nidhi & Namo Shetkari Yojana:\n"
                            + "• Financial Benefit: ₹6,000/year from Central Govt + ₹6,000/year from Maharashtra Govt = Total ₹12,000 annually (in 3 equal installments of ₹4,000).\n"
                            + "• Mandatory Requirements: Active Aadhaar-seeded bank account, Landholding in farmer's name, completed e-KYC on pmkisan.gov.in.\n"
                            + "• Documents: 7/12 extract, Aadhaar, Bank Passbook.";
                case HINGLISH:
                    return "PM Kisan & Namo Shetkari Mahasanman Yojana:\n"
                            + "• Kul Labh: ₹12,000 salana (₹6,000 PM-Kisan + ₹6,000 Namo Shetkari).\n"
                            + "• Zaroori Documents: 7/12 land record, Aadhaar card, Bank passbook, aur e-KYC poori honi chahiye.";
                case MARATHI_ROMANIZED:
                    return "PM Kisan va Namo Shetkari Mahasanman Yojana:\n"
                            + "• Ekoon Labh: Varshala ₹12,000 (Kendra che ₹6,000 + Maharashtra che ₹6,000).\n"
                            + "• Aavashyak Baabi: 7/12 utara, Aadhaar linked bank account, va pmkisan.gov.in var e-KYC purna asne garjeche aahe.";
                default:
                    return "पीएम किसान व नमो शेतकरी महासन्मान योजना:\n"
                            + "• एकूण आर्थिक लाभ: वर्षाला ₹१२,००० (केंद्राचे ₹६,००० + राज्य शासनाचे ₹६,००० = एकूण ₹४,००० चे तीन हप्ते).\n"
                            + "• आवश्यक बाबी: ७/१२ उतारा, आधार संलग्न बँक खाते, आणि pmkisan.gov.in पोर्टलवर ई-केवायसी पूर्ण असणे बंधनकारक आहे.";
            }
        }

        // Generic Scheme overview
        switch (lang) {
            case ENGLISH:
                return "Active Maharashtra Farmer Schemes:\n1. 1 Rupee Crop Insurance (Pradhan Mantri Fasal Bima)\n2. PM-Kisan + Namo Shetkari (₹12,000/year)\n3. MahaDBT Drip/Sprinkler Subsidy (80%)\n4. Farm Mechanization (Tractor & Tools subsidy up to 50%)\nCheck the 'Kisan Yojna' tab in this app for direct application steps.";
            case HINGLISH:
                return "Maharashtra ki mukhya kheti yojanaayein:\n1. 1 Rupaye me Pik Vima\n2. PM-Kisan + Namo Shetkari (₹12,000 saalana)\n3. MahaDBT Drip Sinchan Subsidy\n4. Krushi Yantrikikaran Anudan\nApp ke 'Kisan Yojna' section me jaakar eligibility aur documents dekhein.";
            case MARATHI_ROMANIZED:
                return "Maharashtratil sakriya shaskiya yojana:\n1. Ek Rupayat Pik Vima Yojana\n2. PM-Kisan + Namo Shetkari (Varshik ₹12,000)\n3. MahaDBT Thibak Sinchan Anudan (80% paryant)\n4. Krushi Yantrikikaran Tractor va Aujare Anudan\nSampurna mahiti sathi 'Kisan Yojna' tab ughada.";
            default:
                return "महाराष्ट्रातील सक्रिय शेतकरी योजना:\n१. एक रुपयात पीक विमा योजना\n२. पीएम किसान + नमो शेतकरी महासन्मान (वार्षिक ₹१२,०००)\n३. महाडीबीटी ठिबक व तुषार सिंचन अनुदान (८०% पर्यंत)\n४. कृषी यांत्रिकीकरण ट्रॅक्टर व अवजारे अनुदान\nसविस्तर माहिती व कागदपत्रांच्या यादीसाठी होम स्क्रीनवरील 'Kisan Yojna' पर्याय पहा.";
        }
    }

    private String handleFarmingAdvice(String query, LanguageType lang) {
        if (query.contains("pani") || query.contains("water") || query.contains("सिंचन") || query.contains("पाणी")) {
            switch (lang) {
                case ENGLISH:
                    return "Watering Guidance:\n• Black cotton soil retains moisture for 6-8 days. Overwatering causes root rot (wilt).\n• Use drip irrigation during morning hours (6 AM to 9 AM) to reduce evaporation by 40%.\n• Do not allow standing water around stem collar.";
                case HINGLISH:
                    return "Sinchai Salah:\n• Kali mitti me 6-8 din tak nami rehti hai. Zyaada paani se jar galan (wilt) ki bimari ho sakti hai.\n• Subah 6 se 9 baje drip chalayein jisse paani ki bachat hogi aur paudha swasth rahega.";
                case MARATHI_ROMANIZED:
                    return "Pani Vyavasthapan Salla:\n• Kalya jameenet 6 te 8 divas ol tikun rahte. Atirikt paanya mule muulaan javal sadyan (wilt) rog hoto.\n• Drip sinchan sakali 6 te 9 chya darmiyan chalva. Khodajaval paani saachu deu naka.";
                default:
                    return "सिंचन व पाणी व्यवस्थापन सल्ला:\n• काळ्या जमिनीत ओलावा ६ ते ८ दिवस टिकतो. अवाजवी पाण्यामुळे मुळे कुजण्याचा (मर रोग) धोका निर्माण होतो.\n• ठिबक सिंचन सकाळी ६ ते ९ दरम्यान सुरू ठेवावे. पिकाच्या खोडाजवळ पाणी साचू देऊ नये.";
            }
        }

        switch (lang) {
            case ENGLISH:
                return "Crop Health Guidance:\n• Leaf Yellowing: Check for iron/zinc deficiency or waterlogged roots.\n• Leaf Spots (Blight): Spray Carbendazim + Mancozeb (2g/L water) or Trichoderma viride bio-fungicide.\n• Submit details in 'My Farm Assessment' tab for a customized risk assessment.";
            case HINGLISH:
                return "Fasal Dekhbhal:\n• Peeli Patti: Micronutrient kami ya jado me paani rukne se hota hai.\n• Karpa / Dhabbey: Fafundinashak (Fungicide) ka spray karein aur KVK krushi kendra se sampark karein.\n• 'My Farm Assessment' form bharein.";
            case MARATHI_ROMANIZED:
                return "Peek Arogya Salla:\n• Pane pivli padat aslyas: Sukshma annadravya kamtarta kivha muulanshi pani sachne he mukhya karan aahe.\n• Karpa kivha thipke: Niyantranasaathi 'My Farm Assessment' tab madhe lakshane nondva.";
            default:
                return "पीक आरोग्य सल्ला:\n• पाने पिवळी पडत असल्यास: जमिनीत पाणी साचले आहे का ते तपासा किंवा सूक्ष्म अन्नद्रव्य (Micronutrients) कमतरता असू शकते.\n• करपा किंवा ठिपके असल्यास: योग्य बुरशीनाशकाची फवारणी करा.\n• अधिक अचूक सल्ल्यासाठी होम स्क्रीनवरील 'My Farm Assessment' पर्याय वापरा.";
        }
    }

    // =============================================================================================
    // NATURAL LANGUAGE & INTENT UTILITIES
    // =============================================================================================

    private static final java.util.regex.Pattern MARATHI_ROMAN_PATTERN = java.util.regex.Pattern.compile(
            "\\b(mala|majhya|mazya|majha|sang|sanga|aahe|ahe|vadhla|kami|zala|jilhyat|jilha|shetat|sheta|dyaycha|paus|padnar|bhav|bhaav|dakhav|dakhva|kasa|sathi|konti|lagtat|shakte|madhle|madhe|kiti|vela|peksha)\\b",
            java.util.regex.Pattern.CASE_INSENSITIVE
    );

    private static final java.util.regex.Pattern HINGLISH_PATTERN = java.util.regex.Pattern.compile(
            "\\b(mere|mera|meri|mujhe|batao|kyu|kyun|kyo|chahiye|badha|barish|kaun|kaunse|kaunsi|hai|hain|rahe|raha|rahi|hoga|hogi|kisan|fasal|kheti)\\b",
            java.util.regex.Pattern.CASE_INSENSITIVE
    );

    public static LanguageType detectLanguage(String text) {
        if (text == null || text.trim().isEmpty()) {
            return LanguageType.MARATHI_ROMANIZED;
        }

        int devanagariCount = 0;
        int latinCount = 0;
        for (char c : text.toCharArray()) {
            if (c >= '\u0900' && c <= '\u097F') {
                devanagariCount++;
            } else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
                latinCount++;
            }
        }

        // If predominantly Roman/Latin letters, check for Romanized Marathi & Hinglish first
        if (latinCount > devanagariCount) {
            if (MARATHI_ROMAN_PATTERN.matcher(text).find()) {
                return LanguageType.MARATHI_ROMANIZED;
            }
            if (HINGLISH_PATTERN.matcher(text).find()) {
                return LanguageType.HINGLISH;
            }
            if (devanagariCount == 0) {
                return LanguageType.ENGLISH;
            }
        }

        if (devanagariCount > 0) {
            return LanguageType.MARATHI_DEVANAGARI;
        }

        if (MARATHI_ROMAN_PATTERN.matcher(text).find()) {
            return LanguageType.MARATHI_ROMANIZED;
        }

        if (HINGLISH_PATTERN.matcher(text).find()) {
            return LanguageType.HINGLISH;
        }

        return LanguageType.ENGLISH;
    }

    private boolean isGreeting(String q) {
        return q.contains("namaskar") || q.contains("रामराम") || q.contains("नमस्कार") ||
               q.contains("hello") || q.contains("hi") || q.contains("नमस्ते") ||
               q.contains("ramram") || q.contains("pranam");
    }

    private boolean isPriceLookupIntent(String q) {
        return q.contains("bhav") || q.contains("भाव") || q.contains("दर") || q.contains("rate") ||
               q.contains("price") || q.contains("mandi") || q.contains("apmc") || q.contains("kimat") ||
               q.contains("bhaav") || q.contains("रेट") || q.contains("मार्केट") || q.contains("बाजारभाव");
    }

    private boolean isPriceComparisonIntent(String q) {
        return q.contains("kal peksha") || q.contains("kal pekshya") || q.contains("vadhla ka") ||
               q.contains("kami zala ka") || q.contains("kal se") || q.contains("yesterday") ||
               q.contains("compared to") || q.contains("higher") || q.contains("increase") ||
               q.contains("काल पेक्षा") || q.contains("वाढला का") || q.contains("कमी झाला का") ||
               q.contains("badha kya") || q.contains("ghasarla ka");
    }

    private boolean isWhyPriceExplanationIntent(String q) {
        return q.contains("mag kami ka zala") || q.contains("kami ka zala") || q.contains("ka zala") ||
               q.contains("why is") || q.contains("why onion") || q.contains("why price") ||
               q.contains("kam kyu") || q.contains("kyu gir") || q.contains("karan kay") ||
               q.contains("reason") || q.contains("कमी का झाला") || q.contains("कारण काय") ||
               q.contains("का घसरले") || q.contains("kyun");
    }

    private boolean isWeatherIntent(String q) {
        return q.contains("weather") || q.contains("हवामान") || q.contains("paus") ||
               q.contains("पाऊस") || q.contains("rain") || q.contains("barish") ||
               q.contains("तापमान") || q.contains("temp") || q.contains("forecast") ||
               q.contains("dhag") || q.contains("ढगाळ");
    }

    private boolean isSchemeIntent(String q) {
        return q.contains("yojana") || q.contains("योजना") || q.contains("subsidy") ||
               q.contains("अनुदान") || q.contains("scheme") || q.contains("vima") ||
               q.contains("विमा") || q.contains("insurance") || q.contains("bima") ||
               q.contains("pm kisan") || q.contains("namo") || q.contains("drip");
    }

    private boolean isFarmingAdviceIntent(String q) {
        return q.contains("pani") || q.contains("water") || q.contains("पाणी") ||
               q.contains("रोग") || q.contains("कीड") || q.contains("pest") ||
               q.contains("disease") || q.contains("yellow") || q.contains("पिवळी") ||
               q.contains("karpa") || q.contains("करपा") || q.contains("shetat");
    }

    private String extractCommodity(String q) {
        if (q.contains("onion") || q.contains("कांदा") || q.contains("kanda") || q.contains("kande") || q.contains("pyaz")) return "Onion";
        if (q.contains("soybean") || q.contains("सोयाबीन") || q.contains("soyabean")) return "Soybean";
        if (q.contains("cotton") || q.contains("कापूस") || q.contains("kapas") || q.contains("kapus")) return "Cotton";
        if (q.contains("tur") || q.contains("तूर") || q.contains("arhar") || q.contains("toor")) return "Tur / Arhar";
        if (q.contains("chana") || q.contains("हरभरा") || q.contains("gram")) return "Gram / Chana";
        if (q.contains("wheat") || q.contains("गहू") || q.contains("gehu") || q.contains("gahu")) return "Wheat";
        if (q.contains("tomato") || q.contains("टोमॅटो") || q.contains("tamatar")) return "Tomato";
        if (q.contains("pomegranate") || q.contains("डाळिंब") || q.contains("dalimb") || q.contains("anar")) return "Pomegranate";
        if (q.contains("grapes") || q.contains("द्राक्षे") || q.contains("draksh") || q.contains("angoor")) return "Grapes";
        if (q.contains("orange") || q.contains("संत्रा") || q.contains("santra")) return "Orange";
        if (q.contains("sugarcane") || q.contains("ऊस") || q.contains("us")) return "Sugarcane";
        if (q.contains("mango") || q.contains("आंबा") || q.contains("aam") || q.contains("alphonso")) return "Mango";
        if (q.contains("bajra") || q.contains("बाजरी") || q.contains("bajri")) return "Bajra";
        if (q.contains("jowar") || q.contains("ज्वारी") || q.contains("jwari")) return "Jowar";
        return null;
    }

    private String extractDistrict(String q) {
        for (String districtName : ApmcDataSourceAdapter.DISTRICTS) {
            String base = ApmcDataSourceAdapter.extractBaseName(districtName).toLowerCase(Locale.ROOT);
            if (base.isEmpty() || base.startsWith("all")) continue;

            if (q.contains(base) || q.contains(base + "at") || q.contains(base + "la") || q.contains(base + "madhe")) {
                return ApmcDataSourceAdapter.extractBaseName(districtName);
            }
        }

        // Common spelling variations
        if (q.contains("pune") || q.contains("पुणे") || q.contains("punyat") || q.contains("poona")) return "Pune";
        if (q.contains("nashik") || q.contains("नाशिक") || q.contains("nasik")) return "Nashik";
        if (q.contains("ahmednagar") || q.contains("अहमदनगर") || q.contains("nagar") || q.contains("nagarat")) return "Ahmednagar";
        if (q.contains("latur") || q.contains("लातूर") || q.contains("laturat")) return "Latur";
        if (q.contains("solapur") || q.contains("सोलापूर") || q.contains("sholapur")) return "Solapur";
        if (q.contains("kolhapur") || q.contains("कोल्हापूर")) return "Kolhapur";
        if (q.contains("nagpur") || q.contains("नागपूर") || q.contains("nagpurat")) return "Nagpur";
        if (q.contains("jalna") || q.contains("जालना") || q.contains("jalnyat")) return "Jalna";
        if (q.contains("amravati") || q.contains("अमरावती")) return "Amravati";
        if (q.contains("akola") || q.contains("अकोला")) return "Akola";
        if (q.contains("satara") || q.contains("सातारा")) return "Satara";
        if (q.contains("sangli") || q.contains("सांगली")) return "Sangli";
        if (q.contains("jalgaon") || q.contains("जळगाव")) return "Jalgaon";
        if (q.contains("dhule") || q.contains("धुळे")) return "Dhule";
        if (q.contains("beed") || q.contains("बीड")) return "Beed";
        if (q.contains("nanded") || q.contains("नांदेड")) return "Nanded";
        if (q.contains("buldhana") || q.contains("बुलढाणा")) return "Buldhana";
        if (q.contains("yavatmal") || q.contains("यवतमाळ")) return "Yavatmal";
        if (q.contains("washim") || q.contains("वाशीम")) return "Washim";
        if (q.contains("wardha") || q.contains("वर्धा")) return "Wardha";
        if (q.contains("chandrapur") || q.contains("चंद्रपूर")) return "Chandrapur";
        if (q.contains("parbhani") || q.contains("परभणी")) return "Parbhani";
        if (q.contains("hingoli") || q.contains("हिंगोली")) return "Hingoli";
        if (q.contains("dharashiv") || q.contains("धाराशीव") || q.contains("osmanabad")) return "Dharashiv";
        if (q.contains("sambhajinagar") || q.contains("संभाजीनगर") || q.contains("aurangabad")) return "Chhatrapati Sambhajinagar";
        if (q.contains("ratnagiri") || q.contains("रत्नागिरी")) return "Ratnagiri";
        if (q.contains("sindhudurg") || q.contains("सिंधुदुर्ग")) return "Sindhudurg";
        if (q.contains("raigad") || q.contains("रायगड")) return "Raigad";
        if (q.contains("thane") || q.contains("ठाणे")) return "Thane";
        if (q.contains("palghar") || q.contains("पालघर")) return "Palghar";
        if (q.contains("bhandara") || q.contains("भंडारा")) return "Bhandara";
        if (q.contains("gondia") || q.contains("गोंदिया")) return "Gondia";
        if (q.contains("gadchiroli") || q.contains("गडचिरोली")) return "Gadchiroli";
        if (q.contains("nandurbar") || q.contains("नंदुरबार")) return "Nandurbar";
        if (q.contains("mumbai") || q.contains("मुंबई")) return "Mumbai City";

        return null;
    }

    // Exposed for testing context
    public String getLastReferencedDistrict() {
        return lastReferencedDistrict;
    }

    public String getLastReferencedCommodity() {
        return lastReferencedCommodity;
    }

    public ApmcPrice getLastRetrievedPrice() {
        return lastRetrievedPrice;
    }
}
