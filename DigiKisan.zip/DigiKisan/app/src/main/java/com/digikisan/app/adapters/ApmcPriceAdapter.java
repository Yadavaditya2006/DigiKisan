package com.digikisan.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.models.ApmcPrice;
import java.util.List;

/**
 * RecyclerView Adapter for displaying Maharashtra APMC market price cards.
 */
public class ApmcPriceAdapter extends RecyclerView.Adapter<ApmcPriceAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(ApmcPrice price);
    }

    private final Context context;
    private List<ApmcPrice> priceList;
    private final OnItemClickListener listener;

    public ApmcPriceAdapter(Context context, List<ApmcPrice> priceList, OnItemClickListener listener) {
        this.context = context;
        this.priceList = priceList;
        this.listener = listener;
    }

    public void updateList(List<ApmcPrice> newList) {
        this.priceList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_apmc_price, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApmcPrice price = priceList.get(position);

        holder.tvCommodityName.setText(price.getCommodity());
        holder.tvMarketLocation.setText(price.getMarketName() + ", " + price.getDistrict());
        holder.tvModalPrice.setText("₹ " + (int) price.getModalPrice());
        holder.tvMinMaxPrice.setText("Min: ₹" + (int) price.getMinPrice() + " | Max: ₹" + (int) price.getMaxPrice());
        holder.tvArrivals.setText("Arrivals: " + price.getArrivalsQuantity() + " Qtl");
        holder.tvObservationDate.setText("Observed: " + price.getObservationDate());

        // Trend Badge Styling
        String trend = price.getPriceTrend();
        if ("RISING".equalsIgnoreCase(trend)) {
            holder.tvTrendBadge.setText("RISING ▲");
            holder.tvTrendBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_good));
            holder.tvTrendBadge.setTextColor(ContextCompat.getColor(context, R.color.status_good));
        } else if ("FALLING".equalsIgnoreCase(trend)) {
            holder.tvTrendBadge.setText("FALLING ▼");
            holder.tvTrendBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_risk));
            holder.tvTrendBadge.setTextColor(ContextCompat.getColor(context, R.color.status_high_risk));
        } else {
            holder.tvTrendBadge.setText("STABLE ━");
            holder.tvTrendBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_attention));
            holder.tvTrendBadge.setTextColor(ContextCompat.getColor(context, R.color.status_attention));
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(price);
            }
        });
    }

    @Override
    public int getItemCount() {
        return priceList != null ? priceList.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCommodityName, tvMarketLocation, tvModalPrice, tvMinMaxPrice, tvArrivals, tvObservationDate, tvTrendBadge;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCommodityName = itemView.findViewById(R.id.tvCommodityName);
            tvMarketLocation = itemView.findViewById(R.id.tvMarketLocation);
            tvModalPrice = itemView.findViewById(R.id.tvModalPrice);
            tvMinMaxPrice = itemView.findViewById(R.id.tvMinMaxPrice);
            tvArrivals = itemView.findViewById(R.id.tvArrivals);
            tvObservationDate = itemView.findViewById(R.id.tvObservationDate);
            tvTrendBadge = itemView.findViewById(R.id.tvTrendBadge);
        }
    }
}
