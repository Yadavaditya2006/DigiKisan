package com.digikisan.app.utils;

import java.util.regex.Pattern;

/**
 * Input validation utilities for farmer registration, profile, and forms.
 */
public class InputValidator {

    // Standard 10-digit Indian mobile number starting with 6, 7, 8, or 9
    private static final Pattern INDIAN_MOBILE_PATTERN = Pattern.compile("^[6-9]\\d{9}$");

    /**
     * Validates 10-digit Indian mobile number.
     */
    public static boolean isValidMobile(String mobile) {
        if (mobile == null) return false;
        String trimmed = mobile.trim().replaceAll("[\\s\\-+]", "");
        if (trimmed.startsWith("91") && trimmed.length() == 12) {
            trimmed = trimmed.substring(2);
        } else if (trimmed.startsWith("0") && trimmed.length() == 11) {
            trimmed = trimmed.substring(1);
        }
        return INDIAN_MOBILE_PATTERN.matcher(trimmed).matches();
    }

    /**
     * Normalizes mobile number to clean 10-digit string.
     */
    public static String cleanMobileNumber(String mobile) {
        if (mobile == null) return "";
        String trimmed = mobile.trim().replaceAll("[\\s\\-+]", "");
        if (trimmed.startsWith("91") && trimmed.length() == 12) {
            return trimmed.substring(2);
        } else if (trimmed.startsWith("0") && trimmed.length() == 11) {
            return trimmed.substring(1);
        }
        return trimmed;
    }

    /**
     * Validates password length (at least 6 characters).
     */
    public static boolean isValidPassword(String password) {
        return password != null && password.trim().length() >= 6;
    }

    /**
     * Checks if a text string is non-empty.
     */
    public static boolean isNotEmpty(String text) {
        return text != null && !text.trim().isEmpty();
    }

    /**
     * Validates positive numeric values for land or expenses.
     */
    public static boolean isValidPositiveNumber(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            double d = Double.parseDouble(value.trim());
            return d >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
