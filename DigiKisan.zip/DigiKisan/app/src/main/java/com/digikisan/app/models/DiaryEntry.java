package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing a farm activity or cost/income transaction in the farm diary.
 */
public class DiaryEntry implements Serializable {
    private long id;
    private long userId;
    private String activityType; // "SOWING", "IRRIGATION", "FERTILIZER", "PESTICIDE", "WEEDING", "HARVEST", "SALE"
    private String entryDate;
    private String notes;
    private double expenseAmount;
    private double incomeAmount;
    private String createdAt;

    public DiaryEntry() {}

    public DiaryEntry(long id, long userId, String activityType, String entryDate, 
                      String notes, double expenseAmount, double incomeAmount, String createdAt) {
        this.id = id;
        this.userId = userId;
        this.activityType = activityType;
        this.entryDate = entryDate;
        this.notes = notes;
        this.expenseAmount = expenseAmount;
        this.incomeAmount = incomeAmount;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public String getActivityType() { return activityType; }
    public void setActivityType(String activityType) { this.activityType = activityType; }

    public String getEntryDate() { return entryDate; }
    public void setEntryDate(String entryDate) { this.entryDate = entryDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public double getExpenseAmount() { return expenseAmount; }
    public void setExpenseAmount(double expenseAmount) { this.expenseAmount = expenseAmount; }

    public double getIncomeAmount() { return incomeAmount; }
    public void setIncomeAmount(double incomeAmount) { this.incomeAmount = incomeAmount; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
