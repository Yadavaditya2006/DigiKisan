package com.digikisan.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.Scheme;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;

/**
 * SchemeDetailActivity displays comprehensive verified guidelines, eligibility,
 * document preparation checklists, and official portal links for a welfare scheme.
 */
public class SchemeDetailActivity extends AppCompatActivity {

    private ImageButton btnBackSchemeDetail;
    private TextView tvDetailSchemeName, tvDetailAuthority, tvDetailObjective;
    private TextView tvDetailBenefits, tvDetailCriteria, tvDetailDocuments, tvDetailSteps;
    private MaterialButton btnOpenPortal, btnSaveSchemeDetail, btnCallSchemeHelpline;

    private Scheme scheme;
    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_detail);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        loadDataFromIntent();
        setupListeners();
    }

    private void initViews() {
        btnBackSchemeDetail = findViewById(R.id.btnBackSchemeDetail);
        tvDetailSchemeName = findViewById(R.id.tvDetailSchemeName);
        tvDetailAuthority = findViewById(R.id.tvDetailAuthority);
        tvDetailObjective = findViewById(R.id.tvDetailObjective);
        tvDetailBenefits = findViewById(R.id.tvDetailBenefits);
        tvDetailCriteria = findViewById(R.id.tvDetailCriteria);
        tvDetailDocuments = findViewById(R.id.tvDetailDocuments);
        tvDetailSteps = findViewById(R.id.tvDetailSteps);
        btnOpenPortal = findViewById(R.id.btnOpenPortal);
        btnSaveSchemeDetail = findViewById(R.id.btnSaveSchemeDetail);
        btnCallSchemeHelpline = findViewById(R.id.btnCallSchemeHelpline);
    }

    private void loadDataFromIntent() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("extra_scheme")) {
            scheme = (Scheme) intent.getSerializableExtra("extra_scheme");
        }

        if (scheme != null) {
            bindData();
        }
    }

    private void bindData() {
        tvDetailSchemeName.setText(scheme.getSchemeName());
        tvDetailAuthority.setText("विभाग / शासन: " + scheme.getIssuingAuthority());
        tvDetailObjective.setText(scheme.getObjective());
        tvDetailBenefits.setText(scheme.getBenefitsSummary());
        tvDetailCriteria.setText(scheme.getEligibilityCriteria());
        tvDetailDocuments.setText(scheme.getRequiredDocuments());
        tvDetailSteps.setText(scheme.getApplicationSteps());

        boolean isSaved = dbHelper.isSchemeSaved(sessionManager.getUserId(), scheme.getId());
        updateSaveButtonText(isSaved);

        if (scheme.getHelplineContact() != null && !scheme.getHelplineContact().isEmpty()) {
            btnCallSchemeHelpline.setText("📞 हेल्पलाईन: " + scheme.getHelplineContact());
        }
    }

    private void updateSaveButtonText(boolean isSaved) {
        if (isSaved) {
            btnSaveSchemeDetail.setText("✓ योजना सेव्ह केली आहे (Saved)");
        } else {
            btnSaveSchemeDetail.setText(R.string.btn_save_scheme);
        }
    }

    private void setupListeners() {
        btnBackSchemeDetail.setOnClickListener(v -> finish());

        btnOpenPortal.setOnClickListener(v -> {
            if (scheme != null && scheme.getOfficialPortalUrl() != null) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme.getOfficialPortalUrl()));
                startActivity(browserIntent);
            }
        });

        btnCallSchemeHelpline.setOnClickListener(v -> {
            if (scheme != null && scheme.getHelplineContact() != null) {
                String cleanNum = scheme.getHelplineContact().replaceAll("[^0-9]", "");
                if (!cleanNum.isEmpty()) {
                    Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + cleanNum));
                    startActivity(dialIntent);
                }
            }
        });

        btnSaveSchemeDetail.setOnClickListener(v -> {
            if (scheme != null) {
                boolean saved = dbHelper.toggleSaveScheme(sessionManager.getUserId(), scheme.getId());
                updateSaveButtonText(saved);
                Toast.makeText(this, saved ? getString(R.string.saved_scheme_success) : "योजना यादीतून हटवली आहे", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
