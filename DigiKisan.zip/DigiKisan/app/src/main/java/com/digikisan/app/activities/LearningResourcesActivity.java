package com.digikisan.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.google.android.material.button.MaterialButton;

/**
 * LearningResourcesActivity displays agricultural university guidance,
 * direct official helplines (via implicit dial intent), and official portal links.
 */
public class LearningResourcesActivity extends AppCompatActivity {

    private ImageButton btnBackLearning;
    private MaterialButton btnCallKisanCenter, btnCallMahaDbt;
    private MaterialButton btnWebMahaDbt, btnWebMsamb, btnWebPmKisan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning_resources);

        initViews();
        setupListeners();
    }

    private void initViews() {
        btnBackLearning = findViewById(R.id.btnBackLearning);
        btnCallKisanCenter = findViewById(R.id.btnCallKisanCenter);
        btnCallMahaDbt = findViewById(R.id.btnCallMahaDbt);
        btnWebMahaDbt = findViewById(R.id.btnWebMahaDbt);
        btnWebMsamb = findViewById(R.id.btnWebMsamb);
        btnWebPmKisan = findViewById(R.id.btnWebPmKisan);
    }

    private void setupListeners() {
        btnBackLearning.setOnClickListener(v -> finish());

        // Call Kisan Call Centre Toll-Free
        btnCallKisanCenter.setOnClickListener(v -> {
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:18001801551"));
            startActivity(dialIntent);
        });

        // Call MahaDBT Helpline
        btnCallMahaDbt.setOnClickListener(v -> {
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:02249150800"));
            startActivity(dialIntent);
        });

        // Open MahaDBT Portal
        btnWebMahaDbt.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://mahadbt.maharashtra.gov.in/Farmer/Agrilogin/Agrilogin"));
            startActivity(browserIntent);
        });

        // Open MSAMB Market Portal
        btnWebMsamb.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.msamb.com/"));
            startActivity(browserIntent);
        });

        // Open PM-Kisan Portal
        btnWebPmKisan.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://pmkisan.gov.in/"));
            startActivity(browserIntent);
        });
    }
}
