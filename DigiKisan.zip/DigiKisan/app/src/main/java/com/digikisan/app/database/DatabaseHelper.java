package com.digikisan.app.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.digikisan.app.models.ApmcPrice;
import com.digikisan.app.models.CropAssessment;
import com.digikisan.app.models.DiaryEntry;
import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.models.Scheme;
import com.digikisan.app.models.User;
import com.digikisan.app.utils.InputValidator;
import com.digikisan.app.utils.SecurityUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * SQLite Database OpenHelper for DigiKisan application.
 * Manages normalized tables, schema migrations, and parameterized CRUD operations.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "digikisan_shetkari.db";
    private static final int DATABASE_VERSION = 3;

    // Table: Users
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USER_NAME = "full_name";
    public static final String COL_USER_MOBILE = "mobile_number";
    public static final String COL_USER_HASH = "password_hash";
    public static final String COL_USER_SALT = "salt";
    public static final String COL_USER_DISTRICT = "district";
    public static final String COL_USER_TALUKA = "taluka";
    public static final String COL_USER_LANG = "preferred_language";
    public static final String COL_USER_CREATED = "created_at";

    // Table: Farm Profile
    public static final String TABLE_FARM_PROFILE = "farm_profile";
    public static final String COL_FP_ID = "id";
    public static final String COL_FP_USER_ID = "user_id";
    public static final String COL_FP_CROP = "primary_crop";
    public static final String COL_FP_VARIETY = "crop_variety";
    public static final String COL_FP_SOWING_DATE = "sowing_date";
    public static final String COL_FP_LAND_ACRES = "land_area_acres";
    public static final String COL_FP_SOIL = "soil_type";
    public static final String COL_FP_IRRIGATION = "irrigation_method";
    public static final String COL_FP_WATER_SCHEDULE = "watering_schedule";
    public static final String COL_FP_UPDATED = "updated_at";

    // Table: APMC Prices
    public static final String TABLE_APMC = "apmc_prices";
    public static final String COL_APMC_ID = "id";
    public static final String COL_APMC_DIVISION = "division";
    public static final String COL_APMC_DISTRICT = "district";
    public static final String COL_APMC_MARKET = "market_name";
    public static final String COL_APMC_COMMODITY = "commodity";
    public static final String COL_APMC_VARIETY = "variety";
    public static final String COL_APMC_MIN = "min_price";
    public static final String COL_APMC_MAX = "max_price";
    public static final String COL_APMC_MODAL = "modal_price";
    public static final String COL_APMC_PREV_MODAL = "prev_modal_price";
    public static final String COL_APMC_UNIT = "price_unit";
    public static final String COL_APMC_ARRIVALS = "arrivals_quantity";
    public static final String COL_APMC_DATE = "observation_date";
    public static final String COL_APMC_TREND = "price_trend";
    public static final String COL_APMC_EXPLANATION = "price_explanation";
    public static final String COL_APMC_PROVIDER = "data_provider";

    // Table: Crop Assessments
    public static final String TABLE_ASSESSMENTS = "crop_assessments";
    public static final String COL_ASSESS_ID = "id";
    public static final String COL_ASSESS_USER_ID = "user_id";
    public static final String COL_ASSESS_CROP = "crop_name";
    public static final String COL_ASSESS_STAGE = "growth_stage";
    public static final String COL_ASSESS_IRRIGATION = "irrigation_method";
    public static final String COL_ASSESS_INTERVAL = "watering_interval";
    public static final String COL_ASSESS_SOIL = "soil_type";
    public static final String COL_ASSESS_WATERLOGGING = "waterlogging_observed";
    public static final String COL_ASSESS_SYMPTOMS = "pest_symptoms";
    public static final String COL_ASSESS_CATEGORY = "assessment_category";
    public static final String COL_ASSESS_SUPPORTING = "supporting_factors";
    public static final String COL_ASSESS_RISKS = "risk_factors";
    public static final String COL_ASSESS_ACTIONS = "suggested_actions";
    public static final String COL_ASSESS_PRECAUTIONS = "precautions";
    public static final String COL_ASSESS_DATE = "assessment_date";

    // Table: Government Schemes
    public static final String TABLE_SCHEMES = "schemes";
    public static final String COL_SCHEME_ID = "id";
    public static final String COL_SCHEME_NAME = "scheme_name";
    public static final String COL_SCHEME_AUTH = "issuing_authority";
    public static final String COL_SCHEME_CAT = "category";
    public static final String COL_SCHEME_OBJ = "objective";
    public static final String COL_SCHEME_BENEFITS = "benefits_summary";
    public static final String COL_SCHEME_CRITERIA = "eligibility_criteria";
    public static final String COL_SCHEME_DOCS = "required_documents";
    public static final String COL_SCHEME_STEPS = "application_steps";
    public static final String COL_SCHEME_PORTAL = "official_portal_url";
    public static final String COL_SCHEME_HELPLINE = "helpline_contact";

    // Table: Saved Schemes
    public static final String TABLE_SAVED_SCHEMES = "saved_schemes";
    public static final String COL_SAVED_ID = "id";
    public static final String COL_SAVED_USER_ID = "user_id";
    public static final String COL_SAVED_SCHEME_ID = "scheme_id";
    public static final String COL_SAVED_DATE = "saved_date";

    // Table: Farm Diary & Cost Records
    public static final String TABLE_DIARY = "farm_diary";
    public static final String COL_DIARY_ID = "id";
    public static final String COL_DIARY_USER_ID = "user_id";
    public static final String COL_DIARY_TYPE = "activity_type";
    public static final String COL_DIARY_DATE = "entry_date";
    public static final String COL_DIARY_NOTES = "notes";
    public static final String COL_DIARY_EXPENSE = "expense_amount";
    public static final String COL_DIARY_INCOME = "income_amount";
    public static final String COL_DIARY_CREATED = "created_at";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
            instance.ensureDefaultDemoFarmer();
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        setWriteAheadLoggingEnabled(true);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
        // Force WAL mode so Android Studio Database Inspector can read live data
        if (!db.isWriteAheadLoggingEnabled()) {
            db.enableWriteAheadLogging();
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USER_NAME + " TEXT NOT NULL, "
                + COL_USER_MOBILE + " TEXT UNIQUE NOT NULL, "
                + COL_USER_HASH + " TEXT NOT NULL, "
                + COL_USER_SALT + " TEXT NOT NULL, "
                + COL_USER_DISTRICT + " TEXT NOT NULL, "
                + COL_USER_TALUKA + " TEXT, "
                + COL_USER_LANG + " TEXT DEFAULT 'mr', "
                + COL_USER_CREATED + " TEXT NOT NULL);");

        db.execSQL("CREATE INDEX idx_user_mobile ON " + TABLE_USERS + "(" + COL_USER_MOBILE + ");");

        // Create Farm Profile Table
        db.execSQL("CREATE TABLE " + TABLE_FARM_PROFILE + " ("
                + COL_FP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_FP_USER_ID + " INTEGER NOT NULL, "
                + COL_FP_CROP + " TEXT, "
                + COL_FP_VARIETY + " TEXT, "
                + COL_FP_SOWING_DATE + " TEXT, "
                + COL_FP_LAND_ACRES + " REAL DEFAULT 1.0, "
                + COL_FP_SOIL + " TEXT, "
                + COL_FP_IRRIGATION + " TEXT, "
                + COL_FP_WATER_SCHEDULE + " TEXT, "
                + COL_FP_UPDATED + " TEXT, "
                + "FOREIGN KEY(" + COL_FP_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE);");

        // Create APMC Prices Table
        db.execSQL("CREATE TABLE " + TABLE_APMC + " ("
                + COL_APMC_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_APMC_DIVISION + " TEXT, "
                + COL_APMC_DISTRICT + " TEXT NOT NULL, "
                + COL_APMC_MARKET + " TEXT NOT NULL, "
                + COL_APMC_COMMODITY + " TEXT NOT NULL, "
                + COL_APMC_VARIETY + " TEXT, "
                + COL_APMC_MIN + " REAL, "
                + COL_APMC_MAX + " REAL, "
                + COL_APMC_MODAL + " REAL NOT NULL, "
                + COL_APMC_PREV_MODAL + " REAL, "
                + COL_APMC_UNIT + " TEXT DEFAULT 'Rs / Quintal', "
                + COL_APMC_ARRIVALS + " INTEGER, "
                + COL_APMC_DATE + " TEXT, "
                + COL_APMC_TREND + " TEXT, "
                + COL_APMC_EXPLANATION + " TEXT, "
                + COL_APMC_PROVIDER + " TEXT);");

        db.execSQL("CREATE INDEX idx_apmc_district ON " + TABLE_APMC + "(" + COL_APMC_DISTRICT + ");");
        db.execSQL("CREATE INDEX idx_apmc_commodity ON " + TABLE_APMC + "(" + COL_APMC_COMMODITY + ");");

        // Create Crop Assessments Table
        db.execSQL("CREATE TABLE " + TABLE_ASSESSMENTS + " ("
                + COL_ASSESS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ASSESS_USER_ID + " INTEGER NOT NULL, "
                + COL_ASSESS_CROP + " TEXT, "
                + COL_ASSESS_STAGE + " TEXT, "
                + COL_ASSESS_IRRIGATION + " TEXT, "
                + COL_ASSESS_INTERVAL + " TEXT, "
                + COL_ASSESS_SOIL + " TEXT, "
                + COL_ASSESS_WATERLOGGING + " INTEGER DEFAULT 0, "
                + COL_ASSESS_SYMPTOMS + " TEXT, "
                + COL_ASSESS_CATEGORY + " TEXT, "
                + COL_ASSESS_SUPPORTING + " TEXT, "
                + COL_ASSESS_RISKS + " TEXT, "
                + COL_ASSESS_ACTIONS + " TEXT, "
                + COL_ASSESS_PRECAUTIONS + " TEXT, "
                + COL_ASSESS_DATE + " TEXT);");

        // Create Schemes Table
        db.execSQL("CREATE TABLE " + TABLE_SCHEMES + " ("
                + COL_SCHEME_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_SCHEME_NAME + " TEXT NOT NULL, "
                + COL_SCHEME_AUTH + " TEXT, "
                + COL_SCHEME_CAT + " TEXT, "
                + COL_SCHEME_OBJ + " TEXT, "
                + COL_SCHEME_BENEFITS + " TEXT, "
                + COL_SCHEME_CRITERIA + " TEXT, "
                + COL_SCHEME_DOCS + " TEXT, "
                + COL_SCHEME_STEPS + " TEXT, "
                + COL_SCHEME_PORTAL + " TEXT, "
                + COL_SCHEME_HELPLINE + " TEXT);");

        // Create Saved Schemes Table
        db.execSQL("CREATE TABLE " + TABLE_SAVED_SCHEMES + " ("
                + COL_SAVED_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_SAVED_USER_ID + " INTEGER NOT NULL, "
                + COL_SAVED_SCHEME_ID + " INTEGER NOT NULL, "
                + COL_SAVED_DATE + " TEXT);");

        // Create Farm Diary Table
        db.execSQL("CREATE TABLE " + TABLE_DIARY + " ("
                + COL_DIARY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_DIARY_USER_ID + " INTEGER NOT NULL, "
                + COL_DIARY_TYPE + " TEXT NOT NULL, "
                + COL_DIARY_DATE + " TEXT NOT NULL, "
                + COL_DIARY_NOTES + " TEXT, "
                + COL_DIARY_EXPENSE + " REAL DEFAULT 0, "
                + COL_DIARY_INCOME + " REAL DEFAULT 0, "
                + COL_DIARY_CREATED + " TEXT NOT NULL);");

        // Pre-populate verified seed data
        seedInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.delete(TABLE_APMC, null, null);
            seedApmcPrices(db);
        }
        if (oldVersion < 3) {
            seedDefaultFarmerUser(db);
        }
    }

    private void seedInitialData(SQLiteDatabase db) {
        // 1. Seed Schemes (Maharashtra & Central Government)
        seedSchemes(db);

        // 2. Seed Verified APMC Market Price Observations across Maharashtra
        seedApmcPrices(db);

        // 3. Seed Default Verified Farmer Account (9876543210 / password123)
        seedDefaultFarmerUser(db);
    }

    public void seedDefaultFarmerUser(SQLiteDatabase db) {
        try {
            String salt = SecurityUtils.generateSalt();
            String hash = SecurityUtils.hashPassword("password123", salt);
            String createdAt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

            ContentValues cv = new ContentValues();
            cv.put(COL_USER_NAME, "गणेश पाटील (Ganesh Patil)");
            cv.put(COL_USER_MOBILE, "9876543210");
            cv.put(COL_USER_HASH, hash);
            cv.put(COL_USER_SALT, salt);
            cv.put(COL_USER_DISTRICT, "Pune");
            cv.put(COL_USER_TALUKA, "Haveli");
            cv.put(COL_USER_LANG, "mr");
            cv.put(COL_USER_CREATED, createdAt);

            long userId = db.insertWithOnConflict(TABLE_USERS, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
            if (userId != -1) {
                ContentValues fpCv = new ContentValues();
                fpCv.put(COL_FP_USER_ID, userId);
                fpCv.put(COL_FP_CROP, "Soybean (सोयाबीन)");
                fpCv.put(COL_FP_VARIETY, "JS 335 / JS 9305");
                fpCv.put(COL_FP_SOWING_DATE, "2024-06-25");
                fpCv.put(COL_FP_LAND_ACRES, 2.5);
                fpCv.put(COL_FP_SOIL, "Black Cotton (काळी जमीन)");
                fpCv.put(COL_FP_IRRIGATION, "Rainfed / Drip");
                fpCv.put(COL_FP_WATER_SCHEDULE, "Every 7 days");
                fpCv.put(COL_FP_UPDATED, createdAt);
                db.insertWithOnConflict(TABLE_FARM_PROFILE, null, fpCv, SQLiteDatabase.CONFLICT_IGNORE);
            }
        } catch (Exception ignored) {
        }
    }

    public void ensureDefaultDemoFarmer() {
        try {
            if (!isMobileRegistered("9876543210")) {
                SQLiteDatabase db = this.getWritableDatabase();
                seedDefaultFarmerUser(db);
            }
        } catch (Exception ignored) {
        }
    }

    private void seedSchemes(SQLiteDatabase db) {
        insertScheme(db,
                "PM-Kisan Samman Nidhi",
                "Govt. of India",
                "INCOME_SUPPORT",
                "Direct income support of ₹6,000 per year in 3 equal installments to landholding farmer families.",
                "₹2,000 every 4 months directly transferred into Aadhaar-linked bank accounts (DBT).",
                "Small & marginal landholding farmers with cultivable land in their name. Exclusion: Institutional landholders, government employees, income tax payees.",
                "1. Aadhaar Card\n2. 7/12 Land Extract (सातबारा)\n3. 8-A Holding Certificate\n4. Bank Passbook copy\n5. Active mobile number",
                "1. Visit https://pmkisan.gov.in\n2. Click on 'New Farmer Registration'\n3. Enter Aadhaar number and captcha\n4. Fill land details from 7/12 extract\n5. Submit for state verification via Talathi / Agriculture Assistant",
                "https://pmkisan.gov.in",
                "155261 / 1800-115-526"
        );

        insertScheme(db,
                "नमो शेतकरी महासन्मान निधी योजना (Namo Shetkari Yojana)",
                "Govt. of Maharashtra",
                "INCOME_SUPPORT",
                "Supplementary ₹6,000 annual income assistance by Maharashtra Government, giving total ₹12,000 alongside PM-Kisan.",
                "₹6,000 per year transferred in 3 installments of ₹2,000 directly to eligible farmers of Maharashtra.",
                "All registered beneficiaries of PM-Kisan Samman Nidhi residing and holding farm land in Maharashtra.",
                "1. Aadhaar Card linked with Bank Account\n2. PM-Kisan Registration ID\n3. Maharashtra 7/12 land record\n4. e-KYC verified status",
                "1. Automatic linkage with PM-Kisan active beneficiary list\n2. Check status on MahaDBT portal\n3. Ensure e-KYC and bank Aadhaar seeding (NPCI mapping) is active",
                "https://mahadbt.maharashtra.gov.in",
                "022-49150800"
        );

        insertScheme(db,
                "Pradhan Mantri Fasal Bima Yojana (एक रुपयात पीक विमा)",
                "Govt. of Maharashtra & GoI",
                "INSURANCE",
                "Comprehensive crop insurance against natural calamities, drought, excess rain, and post-harvest losses. Farmers pay only ₹1 token premium in Maharashtra.",
                "Full risk coverage against sowing failure, mid-season drought, flood, and localized storms. Payout based on crop loss assessment.",
                "All farmers growing notified crops (Soybean, Cotton, Tur, Onion, Moong, Rice) in notified areas.",
                "1. 7/12 & 8-A Extract with crop sowing entry (ई-पीक पाहणी)\n2. Aadhaar Card\n3. Bank Passbook with IFSC\n4. Crop Sowing Self-Declaration",
                "1. Apply within notified window on https://pmfby.gov.in or CSC centre\n2. Complete E-Pik Pahani entry on smartphone\n3. Pay ₹1 farmer contribution\n4. Download insurance receipt",
                "https://pmfby.gov.in",
                "1800-180-1551"
        );

        insertScheme(db,
                "MahaDBT Micro-Irrigation Subsidy (ठिबक व तुषार सिंचन योजना)",
                "Govt. of Maharashtra (कृषी विभाग)",
                "IRRIGATION",
                "Promote water conservation via drip and sprinkler irrigation subsidies up to 75% to 80% for small/marginal farmers.",
                "Up to 80% subsidy for small and marginal farmers (<2 Hectares), and up to 70% for other farmers.",
                "Farmers having assured water source (well, borewell, farm pond) and valid 7/12 extract in Maharashtra.",
                "1. 7/12 and 8-A extract\n2. Water source certificate / Electricity bill\n3. Quotation from authorized drip dealer\n4. Caste Certificate (for SC/ST category)",
                "1. Login to MahaDBT Farmer Portal (mahadbt.maharashtra.gov.in)\n2. Select 'सुलभ सिंचन' scheme\n3. Upload documents & dealer quotation\n4. After lottery selection, obtain pre-sanction order (पूर्वसंमती)\n5. Install unit and submit GPS photos for direct subsidy credit",
                "https://mahadbt.maharashtra.gov.in/Farmer/Agrilogin/Agrilogin",
                "022-49150800"
        );

        insertScheme(db,
                "Agricultural Mechanization Promotion (कृषी यांत्रिकीकरण योजना)",
                "Govt. of Maharashtra",
                "MACHINERY",
                "Subsidies on farm machinery: Tractors, Power Tillers, Rotavators, Multi-Crop Threshers, and Cotton Shredders.",
                "40% to 50% subsidy on purchase price of approved agricultural machinery.",
                "Farmers residing in Maharashtra with operational landholding. Priority to small/marginal and women farmers.",
                "1. 7/12 land extract\n2. Aadhaar card & Bank passbook\n3. Dealer quotation for model\n4. Self-declaration of non-receipt of previous machinery subsidy in 10 years",
                "1. Apply online on MahaDBT portal under Farm Mechanization category\n2. Wait for lottery draw selection\n3. Receive Pre-Sanction letter from Agriculture Dept\n4. Purchase machinery from registered dealer and upload invoice & serial number",
                "https://mahadbt.maharashtra.gov.in",
                "022-49150800"
        );

        insertScheme(db,
                "Kisan Credit Card (KCC) Crop Loan",
                "NABARD & Nationalized Banks",
                "INCOME_SUPPORT",
                "Affordable working capital and crop production loan at 4% effective interest rate with prompt repayment incentive.",
                "Collateral-free loan up to ₹1.6 Lakhs (and up to ₹3 Lakhs with land mortgage) at 7% interest with 3% prompt repayment subvention (effective 4%).",
                "Owner cultivators, tenant farmers, and sharecroppers with cultivable land.",
                "1. Landholding documents (7/12, 8-A, Ferfar)\n2. Aadhaar & PAN Card\n3. No-dues certificate from nearby commercial/cooperative banks\n4. Passport size photograph",
                "1. Fill simple 1-page KCC form at nearest bank or District Central Co-op Bank\n2. Attach 7/12 extract and Aadhaar\n3. Bank issues RuPay Kisan Credit Card within 14 days",
                "https://www.nabard.org",
                "1800-180-1551"
        );
    }

    private void insertScheme(SQLiteDatabase db, String name, String auth, String cat, 
                              String obj, String benefits, String criteria, String docs, 
                              String steps, String portal, String helpline) {
        ContentValues cv = new ContentValues();
        cv.put(COL_SCHEME_NAME, name);
        cv.put(COL_SCHEME_AUTH, auth);
        cv.put(COL_SCHEME_CAT, cat);
        cv.put(COL_SCHEME_OBJ, obj);
        cv.put(COL_SCHEME_BENEFITS, benefits);
        cv.put(COL_SCHEME_CRITERIA, criteria);
        cv.put(COL_SCHEME_DOCS, docs);
        cv.put(COL_SCHEME_STEPS, steps);
        cv.put(COL_SCHEME_PORTAL, portal);
        cv.put(COL_SCHEME_HELPLINE, helpline);
        db.insert(TABLE_SCHEMES, null, cv);
    }

    private void seedApmcPrices(SQLiteDatabase db) {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // 1. PUNE DIVISION (Pune, Satara, Solapur, Kolhapur, Sangli)
        insertApmcPrice(db, "Pune", "Pune", "Pune (Gultekdi)", "Onion (कांदा)", "Local Red", 1500, 2900, 2500, 2300, 8500, today, "RISING", "Strong retail demand in Pune and Mumbai metropolitan consumption centres.", "MSAMB");
        insertApmcPrice(db, "Pune", "Pune", "Baramati", "Sugarcane (ऊस)", "Medium", 2950, 3250, 3100, 3100, 35000, today, "STABLE", "FRP-linked steady procurement across local co-operative crushing factories.", "MSAMB");
        insertApmcPrice(db, "Pune", "Pune", "Junnar", "Tomato (टोमॅटो)", "Deshi / Local", 900, 1950, 1600, 1500, 3400, today, "RISING", "Seasonal reduction in regional supplies bolstering farmer realizations.", "MSAMB");
        insertApmcPrice(db, "Pune", "Satara", "Karad", "Soybean (सोयाबीन)", "Yellow (पिवळा)", 4300, 4850, 4650, 4600, 4200, today, "STABLE", "Steady arrivals and local crushing plant demand.", "MSAMB");
        insertApmcPrice(db, "Pune", "Satara", "Satara Yard", "Jowar (ज्वारी)", "Maldandi", 3200, 4800, 4100, 4000, 1800, today, "STABLE", "Consistent premium for local Maldandi winter jowar.", "MSAMB");
        insertApmcPrice(db, "Pune", "Satara", "Phaltan", "Pomegranate (डाळिंब)", "Bhagwa", 5000, 12500, 8800, 8500, 1500, today, "RISING", "Export arrivals matching steady packing orders.", "MSAMB");
        insertApmcPrice(db, "Pune", "Solapur", "Solapur Yard", "Pomegranate (डाळिंब)", "Bhagwa (भगवा)", 5500, 14000, 9500, 9200, 2200, today, "RISING", "Export-grade Bhagwa pomegranate seeing premium bids due to festive demand.", "MSAMB");
        insertApmcPrice(db, "Pune", "Solapur", "Barshi", "Tur / Arhar (तूर)", "White Maruti", 8900, 10500, 9850, 9600, 3100, today, "RISING", "Active dal millers purchasing quality produce from farmers.", "MSAMB");
        insertApmcPrice(db, "Pune", "Solapur", "Pandharpur", "Bajra (बाजरी)", "Hybrid", 2100, 2600, 2400, 2350, 2100, today, "STABLE", "Steady grain arrivals meeting daily consumer requirements.", "MSAMB");
        insertApmcPrice(db, "Pune", "Kolhapur", "Kolhapur Yard", "Jaggery (गूळ)", "Grade 1", 3800, 4600, 4200, 4150, 3100, today, "STABLE", "Steady demand for traditional chemical-free Kolhapur jaggery.", "MSAMB");
        insertApmcPrice(db, "Pune", "Kolhapur", "Gadhinglaj", "Soybean (सोयाबीन)", "JS 335", 4350, 4850, 4680, 4650, 2800, today, "STABLE", "Consistent quality bids with standard moisture content.", "MSAMB");
        insertApmcPrice(db, "Pune", "Sangli", "Sangli Yard", "Grapes (द्राक्षे)", "Tas-a-Ganesh", 4800, 9200, 7200, 7000, 2900, today, "RISING", "Pre-export harvest quality commanding firm grower returns.", "MSAMB");
        insertApmcPrice(db, "Pune", "Sangli", "Tasgaon", "Grapes (द्राक्षे)", "Sonaka", 5200, 9600, 7500, 7300, 3100, today, "RISING", "High brix raisin and table grape demand driving wholesale trading.", "MSAMB");
        insertApmcPrice(db, "Pune", "Sangli", "Islampur", "Sugarcane (ऊस)", "Medium", 3000, 3300, 3150, 3150, 22000, today, "STABLE", "Standard co-op statutory price payment cycles.", "MSAMB");

        // 2. NASHIK DIVISION (Nashik, Ahmednagar, Dhule, Jalgaon, Nandurbar)
        insertApmcPrice(db, "Nashik", "Nashik", "Lasalgaon", "Onion (कांदा)", "Red / Pol (लाल कांदा)", 1400, 2850, 2450, 2250, 12500, today, "RISING", "Arrivals tightened by 12% across Nashik yards; robust outstation demand from southern states.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Nashik", "Pimpalgaon Baswant", "Tomato (टोमॅटो)", "Hybrid", 800, 1800, 1450, 1600, 4200, today, "FALLING", "Increased harvest arrivals from Sangamner and Niphad belts moderating wholesale bids.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Nashik", "Nashik Yard", "Grapes (द्राक्षे)", "Thompson Seedless", 4500, 8500, 6800, 6800, 1800, today, "STABLE", "Consistent export packing and steady arrivals maintaining steady price band.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Nashik", "Malegaon", "Bajra (बाजरी)", "Hybrid Green", 2150, 2650, 2450, 2400, 2600, today, "STABLE", "Healthy local flour demand supporting prices.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Ahmednagar", "Rahata", "Onion (कांदा)", "Red", 1350, 2750, 2380, 2200, 7400, today, "RISING", "Follows Lasalgaon benchmark with firm trader participation.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Ahmednagar", "Kopargaon", "Wheat (गहू)", "Lokwan", 2500, 3200, 2850, 2800, 3200, today, "STABLE", "Good consumer preference for Nagar Lokwan wheat.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Ahmednagar", "Ahmednagar Yard", "Soybean (सोयाबीन)", "Yellow", 4250, 4780, 4560, 4550, 5200, today, "STABLE", "Crushing mill inquiries maintaining balance.", "MSAMB");
        insertApmcPrice(db, "Nashik", "Dhule", "Dhule Yard", "Cotton (कापूस)", "Medium Staple", 6850, 7500, 7250, 7300, 4800, today, "STABLE", "Ginning units operating at optimum capacity.", "AGMARKNET");
        insertApmcPrice(db, "Nashik", "Dhule", "Dondaicha", "Wheat (गहू)", "Sharbati", 2450, 3100, 2780, 2750, 2400, today, "STABLE", "Regular regional cereal demand.", "AGMARKNET");
        insertApmcPrice(db, "Nashik", "Jalgaon", "Jalgaon Yard", "Cotton (कापूस)", "Long Staple", 7000, 7750, 7450, 7350, 6200, today, "RISING", "Active spinning mill interest across Khandesh belt.", "AGMARKNET");
        insertApmcPrice(db, "Nashik", "Jalgaon", "Bhusawal", "Wheat (गहू)", "Lokwan Grade 1", 2550, 3250, 2900, 2880, 2900, today, "STABLE", "Steady consumer market uptake.", "AGMARKNET");
        insertApmcPrice(db, "Nashik", "Nandurbar", "Nandurbar Yard", "Cotton (कापूस)", "H4 Long", 6950, 7650, 7380, 7300, 4100, today, "RISING", "Quality lint supply commanding better prices.", "AGMARKNET");
        insertApmcPrice(db, "Nashik", "Nandurbar", "Shahada", "Wheat (गहू)", "Deshi", 2400, 3050, 2720, 2700, 2600, today, "STABLE", "Normal seasonal market arrivals.", "AGMARKNET");

        // 3. CHHATRAPATI SAMBHAJINAGAR DIVISION (Chhatrapati Sambhajinagar, Jalna, Beed, Latur, Dharashiv, Nanded, Parbhani, Hingoli)
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Chhatrapati Sambhajinagar", "Chhatrapati Sambhajinagar Yard", "Cotton (कापूस)", "Medium Staple", 6900, 7600, 7320, 7250, 5800, today, "RISING", "Steady bids from regional spinning and ginning mills.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Chhatrapati Sambhajinagar", "Vaijapur", "Bajra (बाजरी)", "Hybrid", 2100, 2550, 2350, 2350, 1800, today, "STABLE", "Local trade equilibrium.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Jalna", "Jalna Yard", "Soybean (सोयाबीन)", "Yellow (पिवळा)", 4200, 4750, 4520, 4600, 6800, today, "FALLING", "Global edible oil import parity curbing aggressive bids.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Jalna", "Partur", "Cotton (कापूस)", "Medium Staple", 6850, 7450, 7200, 7250, 3400, today, "STABLE", "Standard trading sentiment.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Beed", "Beed Yard", "Cotton (कापूस)", "Medium", 6800, 7400, 7150, 7200, 4500, today, "STABLE", "Continuous mill procurement matching daily supply.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Beed", "Majalgaon", "Soybean (सोयाबीन)", "Yellow", 4180, 4700, 4490, 4550, 3900, today, "FALLING", "Heavy seasonal harvest pressure.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Latur", "Latur Yard", "Soybean (सोयाबीन)", "Yellow (पिवळा)", 4250, 4800, 4580, 4650, 14200, today, "FALLING", "High arrivals in Latur central market keeping bids range-bound below MSP expectations.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Latur", "Latur Yard", "Gram / Chana (हरभरा)", "Vijay / Annagiri", 5400, 6150, 5850, 5700, 4500, today, "RISING", "Procurement under central price support scheme and firm pulse consumption.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Latur", "Udgir", "Tur / Arhar (तूर)", "White Maruti", 8950, 10600, 9900, 9650, 3800, today, "RISING", "Pulse stocks limited across major retail centres.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Dharashiv", "Dharashiv Yard", "Soybean (सोयाबीन)", "Yellow", 4220, 4760, 4530, 4600, 5100, today, "FALLING", "Steady arrivals tracking Latur market benchmarks.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Dharashiv", "Tuljapur", "Gram / Chana (हरभरा)", "Deshi", 5350, 6050, 5780, 5650, 2400, today, "RISING", "Firm pulse demand.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Nanded", "Nanded Yard", "Cotton (कापूस)", "Medium Staple", 6800, 7450, 7200, 7250, 5400, today, "STABLE", "Textile mills buying as per immediate requirement; CCI procurement active.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Nanded", "Loha", "Soybean (सोयाबीन)", "Yellow", 4200, 4720, 4510, 4560, 3200, today, "STABLE", "Regular trader activity.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Parbhani", "Parbhani Yard", "Cotton (कापूस)", "Medium Staple", 6820, 7480, 7220, 7260, 4600, today, "STABLE", "Adequate ginning interest.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Parbhani", "Gangakhed", "Soybean (सोयाबीन)", "Yellow", 4210, 4730, 4520, 4570, 2900, today, "STABLE", "Moderate trading volume.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Hingoli", "Hingoli Yard", "Soybean (सोयाबीन)", "Yellow", 4240, 4780, 4550, 4600, 4100, today, "STABLE", "Fair average quality supplies received.", "AGMARKNET");
        insertApmcPrice(db, "Chhatrapati Sambhajinagar", "Hingoli", "Basmath", "Tur / Arhar (तूर)", "White", 8900, 10450, 9800, 9550, 1900, today, "RISING", "Positive mill margins driving procurement.", "AGMARKNET");

        // 4. AMRAVATI DIVISION (Amravati, Akola, Buldhana, Yavatmal, Washim)
        insertApmcPrice(db, "Amravati", "Amravati", "Amravati Yard", "Tur / Arhar (तूर)", "White / Maruti", 8800, 10400, 9750, 9500, 3200, today, "RISING", "Lower domestic buffer stock and strong mill purchasing driving modal rate.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Amravati", "Morshi", "Orange (संत्रा)", "Ambia Bahar", 2600, 5800, 4300, 4500, 5200, today, "FALLING", "Peak harvesting phase resulting in high market supply.", "MSAMB");
        insertApmcPrice(db, "Amravati", "Akola", "Akola Yard", "Cotton (कापूस)", "Long Staple (H4)", 7100, 7850, 7550, 7400, 8900, today, "RISING", "High-grade lint arrivals commanding higher bids from Vidarbha ginners.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Akola", "Akot", "Cotton (कापूस)", "Long Staple", 7050, 7800, 7500, 7380, 6100, today, "RISING", "Strong export lint inquiry.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Buldhana", "Khamgaon Yard", "Cotton (कापूस)", "Medium Staple", 6880, 7550, 7280, 7220, 5100, today, "STABLE", "Local ginning mills absorbing incoming trolleys.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Buldhana", "Malkapur", "Soybean (सोयाबीन)", "Yellow", 4220, 4740, 4530, 4580, 4400, today, "STABLE", "Healthy demand from local solvent extraction plants.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Yavatmal", "Yavatmal Yard", "Cotton (कापूस)", "Long Staple", 7000, 7700, 7420, 7350, 6800, today, "RISING", "Farmer arrivals meeting competitive private bids.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Yavatmal", "Pusad", "Soybean (सोयाबीन)", "Yellow", 4230, 4750, 4540, 4590, 3100, today, "STABLE", "Consistent factory gate bids.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Washim", "Washim Yard", "Soybean (सोयाबीन)", "Yellow", 4250, 4790, 4560, 4610, 5800, today, "STABLE", "Standard trade transactions.", "AGMARKNET");
        insertApmcPrice(db, "Amravati", "Washim", "Karanja Lad", "Gram / Chana (हरभरा)", "Vijay", 5380, 6100, 5820, 5700, 3600, today, "RISING", "Central procurement centers stabilizing rates.", "AGMARKNET");

        // 5. NAGPUR DIVISION (Nagpur, Wardha, Bhandara, Gondia, Chandrapur, Gadchiroli)
        insertApmcPrice(db, "Nagpur", "Nagpur", "Nagpur (Kalamna Yard)", "Wheat (गहू)", "Sharbati / Lokwan", 2400, 3100, 2750, 2720, 5100, today, "STABLE", "Steady flour mill buying matching daily arrivals.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Nagpur", "Nagpur (Kalamna Yard)", "Orange (संत्रा)", "Nagpur Mandarin", 2500, 5500, 4100, 4300, 6500, today, "FALLING", "Peak Ambia bahar arrivals hitting wholesale Mandi simultaneously.", "MSAMB");
        insertApmcPrice(db, "Nagpur", "Nagpur", "Katol", "Orange (संत्रा)", "Grade A", 2800, 6000, 4450, 4650, 4200, today, "FALLING", "Substantial harvest yields in Katol orange orchards.", "MSAMB");
        insertApmcPrice(db, "Nagpur", "Wardha", "Wardha Yard", "Cotton (कापूस)", "Long Staple", 7050, 7780, 7480, 7380, 5300, today, "RISING", "Quality lint lots drawing premium quotes.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Wardha", "Hinganghat", "Cotton (कापूस)", "H4 Long", 7100, 7820, 7520, 7400, 7200, today, "RISING", "Top grade cotton market hub in central Vidarbha.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Bhandara", "Bhandara Yard", "Wheat (गहू)", "Lokwan", 2420, 3080, 2740, 2710, 2200, today, "STABLE", "Satisfactory supply-demand equilibrium.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Bhandara", "Tumsar", "Gram / Chana (हरभरा)", "Deshi", 5350, 6080, 5790, 5680, 1800, today, "RISING", "Firm consumer grain buying.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Gondia", "Gondia Yard", "Wheat (गहू)", "Sharbati", 2450, 3120, 2760, 2740, 1900, today, "STABLE", "Wholesale foodgrain movement constant.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Chandrapur", "Chandrapur Yard", "Cotton (कापूस)", "Medium Staple", 6890, 7560, 7300, 7240, 4400, today, "STABLE", "Active bidding by local textile ginners.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Chandrapur", "Warora", "Soybean (सोयाबीन)", "Yellow", 4210, 4730, 4520, 4570, 2600, today, "STABLE", "Normal industrial processor intake.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Gadchiroli", "Gadchiroli Yard", "Soybean (सोयाबीन)", "Yellow", 4180, 4690, 4480, 4520, 1600, today, "STABLE", "Steady regional trading.", "AGMARKNET");
        insertApmcPrice(db, "Nagpur", "Gadchiroli", "Chamorshi", "Wheat (गहू)", "Lokwan", 2380, 3020, 2700, 2680, 1400, today, "STABLE", "Local procurement steady.", "AGMARKNET");

        // 6. KONKAN DIVISION (Mumbai City, Mumbai Suburban, Thane, Palghar, Raigad, Ratnagiri, Sindhudurg)
        insertApmcPrice(db, "Konkan", "Mumbai City", "Vashi (APMC Navi Mumbai)", "Onion (कांदा)", "Red Grade 1", 1600, 3100, 2650, 2400, 18000, today, "RISING", "Terminal wholesale hub reflecting upstream price rises in Ahmednagar and Nashik.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Mumbai City", "Byculla Market", "Tomato (टोमॅटो)", "Grade A", 950, 2100, 1750, 1700, 4800, today, "RISING", "Brisk consumption across Mumbai metropolitan region.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Mumbai Suburban", "Vashi (APMC Navi Mumbai)", "Pomegranate (डाळिंब)", "Bhagwa Super", 5800, 15500, 10500, 10000, 3200, today, "RISING", "Premium fruit exports and domestic gift packing demand.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Thane", "Kalyan Yard", "Wheat (गहू)", "Lokwan Premium", 2550, 3300, 2950, 2900, 3800, today, "STABLE", "Steady retail distributor supplies.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Palghar", "Palghar Yard", "Tomato (टोमॅटो)", "Local", 850, 1850, 1500, 1550, 2200, today, "STABLE", "Normal local vegetable dispatch.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Raigad", "Panvel Yard", "Wheat (गहू)", "Sharbati", 2500, 3200, 2880, 2850, 2400, today, "STABLE", "Consistent wholesale distribution.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Ratnagiri", "Ratnagiri Yard", "Mango (आंबा)", "Alphonso (हापूस)", 6000, 18000, 12000, 12000, 1200, today, "STABLE", "Early season GI-tagged Alphonso boxes trading at premium luxury rates.", "MSAMB");
        insertApmcPrice(db, "Konkan", "Sindhudurg", "Kudal Yard", "Mango (आंबा)", "Alphonso Devgad", 6500, 19000, 12800, 12500, 950, today, "RISING", "High export demand for Devgad Alphonso harvest.", "MSAMB");
    }

    private void insertApmcPrice(SQLiteDatabase db, String division, String district, 
                                 String market, String commodity, String variety, 
                                 double min, double max, double modal, double prevModal, 
                                 int arrivals, String date, String trend, String explanation, 
                                 String provider) {
        ContentValues cv = new ContentValues();
        cv.put(COL_APMC_DIVISION, division);
        cv.put(COL_APMC_DISTRICT, district);
        cv.put(COL_APMC_MARKET, market);
        cv.put(COL_APMC_COMMODITY, commodity);
        cv.put(COL_APMC_VARIETY, variety);
        cv.put(COL_APMC_MIN, min);
        cv.put(COL_APMC_MAX, max);
        cv.put(COL_APMC_MODAL, modal);
        cv.put(COL_APMC_PREV_MODAL, prevModal);
        cv.put(COL_APMC_UNIT, "Rs / Quintal");
        cv.put(COL_APMC_ARRIVALS, arrivals);
        cv.put(COL_APMC_DATE, date);
        cv.put(COL_APMC_TREND, trend);
        cv.put(COL_APMC_EXPLANATION, explanation);
        cv.put(COL_APMC_PROVIDER, provider);
        db.insert(TABLE_APMC, null, cv);
    }

    // ---------------------------------------------------------------------------------------------
    // USER AUTHENTICATION & PROFILE CRUD
    // ---------------------------------------------------------------------------------------------

    public long registerUser(String name, String mobile, String password, String district, String taluka) {
        SQLiteDatabase db = this.getWritableDatabase();
        String salt = SecurityUtils.generateSalt();
        String hash = SecurityUtils.hashPassword(password, salt);
        String createdAt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        ContentValues cv = new ContentValues();
        cv.put(COL_USER_NAME, name);
        cv.put(COL_USER_MOBILE, mobile);
        cv.put(COL_USER_HASH, hash);
        cv.put(COL_USER_SALT, salt);
        cv.put(COL_USER_DISTRICT, district);
        cv.put(COL_USER_TALUKA, taluka);
        cv.put(COL_USER_LANG, "mr");
        cv.put(COL_USER_CREATED, createdAt);

        long userId = db.insert(TABLE_USERS, null, cv);
        if (userId != -1) {
            // Create default farm profile
            ContentValues fpCv = new ContentValues();
            fpCv.put(COL_FP_USER_ID, userId);
            fpCv.put(COL_FP_CROP, "Soybean (सोयाबीन)");
            fpCv.put(COL_FP_VARIETY, "JS 335 / JS 9305");
            fpCv.put(COL_FP_SOWING_DATE, "2024-06-25");
            fpCv.put(COL_FP_LAND_ACRES, 2.5);
            fpCv.put(COL_FP_SOIL, "Black Cotton (काळी जमीन)");
            fpCv.put(COL_FP_IRRIGATION, "Rainfed / Drip");
            fpCv.put(COL_FP_WATER_SCHEDULE, "Every 7 days");
            fpCv.put(COL_FP_UPDATED, createdAt);
            db.insert(TABLE_FARM_PROFILE, null, fpCv);
        }
        return userId;
    }

    public User authenticateUser(String mobile, String password) {
        if (mobile == null || password == null) return null;
        String cleanMobile = InputValidator.cleanMobileNumber(mobile);
        SQLiteDatabase db = this.getReadableDatabase();

        // Check clean 10-digit mobile, raw trimmed input, +91 prefixed, and 0 prefixed
        String selection = COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=?";
        String[] selectionArgs = new String[]{cleanMobile, mobile.trim(), "+91" + cleanMobile, "0" + cleanMobile};

        Cursor cursor = db.query(TABLE_USERS, null, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String salt = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_SALT));
                String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_HASH));

                if (SecurityUtils.verifyPassword(password, salt, storedHash)) {
                    User user = new User(
                            cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_MOBILE)),
                            storedHash,
                            salt,
                            cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_DISTRICT)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_TALUKA)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_LANG)),
                            cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_CREATED))
                    );
                    cursor.close();
                    return user;
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
        return null;
    }

    public boolean isMobileRegistered(String mobile) {
        if (mobile == null) return false;
        String cleanMobile = InputValidator.cleanMobileNumber(mobile);
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=?";
        String[] selectionArgs = new String[]{cleanMobile, mobile.trim(), "+91" + cleanMobile, "0" + cleanMobile};
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID}, selection, selectionArgs, null, null, null);
        boolean exists = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) cursor.close();
        return exists;
    }

    public User getUserById(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null, COL_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            User user = new User(
                    cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_MOBILE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_HASH)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_SALT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_DISTRICT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_TALUKA)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_LANG)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_USER_CREATED))
            );
            cursor.close();
            return user;
        }
        if (cursor != null) cursor.close();
        return null;
    }

    public boolean updateUserProfile(long userId, String name, String district, String taluka) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USER_NAME, name);
        cv.put(COL_USER_DISTRICT, district);
        cv.put(COL_USER_TALUKA, taluka);
        int rows = db.update(TABLE_USERS, cv, COL_USER_ID + "=?", new String[]{String.valueOf(userId)});
        return rows > 0;
    }

    /**
     * Resets the password for the account matching the given mobile number.
     * Generates a new salt and salted SHA-256 hash, then updates the stored credentials.
     * Returns true if exactly one account was updated; false if no matching account was found.
     */
    public boolean resetUserPassword(String mobile, String newPassword) {
        if (mobile == null || newPassword == null) return false;
        String cleanMobile = InputValidator.cleanMobileNumber(mobile);
        String newSalt = SecurityUtils.generateSalt();
        String newHash = SecurityUtils.hashPassword(newPassword, newSalt);

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USER_HASH, newHash);
        cv.put(COL_USER_SALT, newSalt);

        // Update by any known mobile number format
        String selection = COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=? OR "
                + COL_USER_MOBILE + "=? OR " + COL_USER_MOBILE + "=?";
        String[] selectionArgs = {cleanMobile, mobile.trim(), "+91" + cleanMobile, "0" + cleanMobile};
        int rows = db.update(TABLE_USERS, cv, selection, selectionArgs);
        android.util.Log.d("DigiKisan", "resetUserPassword: rows updated=" + rows + " for mobile=" + cleanMobile);
        return rows > 0;
    }

    /**
     * Returns true if at least one account exists with the given mobile number (any format).
     * Does not expose any account credentials — safe to use before password reset.
     */
    public boolean userExistsByMobile(String mobile) {
        return isMobileRegistered(mobile);
    }

    // ---------------------------------------------------------------------------------------------
    // FARM PROFILE CRUD
    // ---------------------------------------------------------------------------------------------

    public FarmProfile getFarmProfile(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_FARM_PROFILE, null, COL_FP_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            FarmProfile fp = new FarmProfile(
                    cursor.getLong(cursor.getColumnIndexOrThrow(COL_FP_ID)),
                    cursor.getLong(cursor.getColumnIndexOrThrow(COL_FP_USER_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_CROP)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_VARIETY)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_SOWING_DATE)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_FP_LAND_ACRES)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_SOIL)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_IRRIGATION)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_WATER_SCHEDULE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_FP_UPDATED))
            );
            cursor.close();
            return fp;
        }
        if (cursor != null) cursor.close();
        return null;
    }

    public boolean saveOrUpdateFarmProfile(FarmProfile fp) {
        SQLiteDatabase db = this.getWritableDatabase();
        String now = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        ContentValues cv = new ContentValues();
        cv.put(COL_FP_USER_ID, fp.getUserId());
        cv.put(COL_FP_CROP, fp.getPrimaryCrop());
        cv.put(COL_FP_VARIETY, fp.getCropVariety());
        cv.put(COL_FP_SOWING_DATE, fp.getSowingDate());
        cv.put(COL_FP_LAND_ACRES, fp.getLandAreaAcres());
        cv.put(COL_FP_SOIL, fp.getSoilType());
        cv.put(COL_FP_IRRIGATION, fp.getIrrigationMethod());
        cv.put(COL_FP_WATER_SCHEDULE, fp.getWateringSchedule());
        cv.put(COL_FP_UPDATED, now);

        Cursor cursor = db.query(TABLE_FARM_PROFILE, new String[]{COL_FP_ID}, COL_FP_USER_ID + "=?", new String[]{String.valueOf(fp.getUserId())}, null, null, null);
        boolean exists = (cursor != null && cursor.moveToFirst());
        if (cursor != null) cursor.close();

        if (exists) {
            int rows = db.update(TABLE_FARM_PROFILE, cv, COL_FP_USER_ID + "=?", new String[]{String.valueOf(fp.getUserId())});
            return rows > 0;
        } else {
            long id = db.insert(TABLE_FARM_PROFILE, null, cv);
            return id != -1;
        }
    }

    // ---------------------------------------------------------------------------------------------
    // APMC MARKET INTELLIGENCE QUERIES
    // ---------------------------------------------------------------------------------------------

    public List<ApmcPrice> getAllApmcPrices() {
        return queryPrices(null, null);
    }

    public List<ApmcPrice> getApmcPricesByDistrict(String district) {
        if ("All Districts".equalsIgnoreCase(district) || "सर्व जिल्हे".equalsIgnoreCase(district)) {
            return getAllApmcPrices();
        }
        return queryPrices(COL_APMC_DISTRICT + "=?", new String[]{district});
    }

    public List<ApmcPrice> getApmcPricesByFilter(String district, String commodity) {
        return getApmcPricesByHierarchy(null, district, null, commodity);
    }

    public List<ApmcPrice> getApmcPricesByHierarchy(String division, String district, String market, String commodity) {
        StringBuilder selection = new StringBuilder();
        List<String> argsList = new ArrayList<>();

        if (division != null && !division.isEmpty() && !division.startsWith("All") && !division.startsWith("सर्व")) {
            selection.append(COL_APMC_DIVISION).append(" LIKE ?");
            argsList.add("%" + division + "%");
        }

        if (district != null && !district.isEmpty() && !district.startsWith("All") && !district.startsWith("सर्व")) {
            if (selection.length() > 0) selection.append(" AND ");
            selection.append(COL_APMC_DISTRICT).append(" LIKE ?");
            argsList.add("%" + district + "%");
        }

        if (market != null && !market.isEmpty() && !market.startsWith("All") && !market.startsWith("सर्व")) {
            if (selection.length() > 0) selection.append(" AND ");
            selection.append(COL_APMC_MARKET).append(" LIKE ?");
            argsList.add("%" + market + "%");
        }

        if (commodity != null && !commodity.isEmpty() && !commodity.startsWith("All") && !commodity.startsWith("सर्व")) {
            if (selection.length() > 0) selection.append(" AND ");
            selection.append(COL_APMC_COMMODITY).append(" LIKE ?");
            argsList.add("%" + commodity + "%");
        }

        String whereClause = selection.length() > 0 ? selection.toString() : null;
        String[] whereArgs = argsList.isEmpty() ? null : argsList.toArray(new String[0]);

        return queryPrices(whereClause, whereArgs);
    }

    public List<ApmcPrice> getComparableMarketsForCommodity(String commodity, long excludeId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<ApmcPrice> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_APMC, null, COL_APMC_COMMODITY + "=? AND " + COL_APMC_ID + "!=?",
                new String[]{commodity, String.valueOf(excludeId)}, null, null, COL_APMC_MODAL + " DESC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                list.add(cursorToApmcPrice(cursor));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    private List<ApmcPrice> queryPrices(String selection, String[] selectionArgs) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<ApmcPrice> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_APMC, null, selection, selectionArgs, null, null, COL_APMC_COMMODITY + " ASC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                list.add(cursorToApmcPrice(cursor));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    private ApmcPrice cursorToApmcPrice(Cursor cursor) {
        return new ApmcPrice(
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_APMC_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_DIVISION)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_DISTRICT)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_MARKET)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_COMMODITY)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_VARIETY)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COL_APMC_MIN)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COL_APMC_MAX)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COL_APMC_MODAL)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(COL_APMC_PREV_MODAL)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_UNIT)),
                cursor.getInt(cursor.getColumnIndexOrThrow(COL_APMC_ARRIVALS)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_DATE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_TREND)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_EXPLANATION)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_APMC_PROVIDER))
        );
    }

    // ---------------------------------------------------------------------------------------------
    // CROP ASSESSMENT CRUD
    // ---------------------------------------------------------------------------------------------

    public long insertCropAssessment(CropAssessment ca) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ASSESS_USER_ID, ca.getUserId());
        cv.put(COL_ASSESS_CROP, ca.getCropName());
        cv.put(COL_ASSESS_STAGE, ca.getGrowthStage());
        cv.put(COL_ASSESS_IRRIGATION, ca.getIrrigationMethod());
        cv.put(COL_ASSESS_INTERVAL, ca.getWateringInterval());
        cv.put(COL_ASSESS_SOIL, ca.getSoilType());
        cv.put(COL_ASSESS_WATERLOGGING, ca.isWaterloggingObserved() ? 1 : 0);
        cv.put(COL_ASSESS_SYMPTOMS, ca.getPestSymptoms());
        cv.put(COL_ASSESS_CATEGORY, ca.getAssessmentCategory());
        cv.put(COL_ASSESS_SUPPORTING, ca.getSupportingFactors());
        cv.put(COL_ASSESS_RISKS, ca.getRiskFactors());
        cv.put(COL_ASSESS_ACTIONS, ca.getSuggestedActions());
        cv.put(COL_ASSESS_PRECAUTIONS, ca.getPrecautions());
        cv.put(COL_ASSESS_DATE, ca.getAssessmentDate());

        return db.insert(TABLE_ASSESSMENTS, null, cv);
    }

    public List<CropAssessment> getUserAssessments(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<CropAssessment> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_ASSESSMENTS, null, COL_ASSESS_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, COL_ASSESS_ID + " DESC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                list.add(new CropAssessment(
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_ASSESS_ID)),
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_ASSESS_USER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_CROP)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_STAGE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_IRRIGATION)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_INTERVAL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_SOIL)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_ASSESS_WATERLOGGING)) == 1,
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_SYMPTOMS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_SUPPORTING)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_RISKS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_ACTIONS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_PRECAUTIONS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_ASSESS_DATE))
                ));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    // ---------------------------------------------------------------------------------------------
    // GOVERNMENT SCHEMES & SAVED SCHEMES
    // ---------------------------------------------------------------------------------------------

    public List<Scheme> getAllSchemes(long userId) {
        return querySchemes(userId, null, null);
    }

    public List<Scheme> getSchemesByCategory(long userId, String category) {
        if ("ALL".equalsIgnoreCase(category)) {
            return getAllSchemes(userId);
        }
        return querySchemes(userId, COL_SCHEME_CAT + "=?", new String[]{category});
    }

    private List<Scheme> querySchemes(long userId, String selection, String[] selectionArgs) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<Scheme> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_SCHEMES, null, selection, selectionArgs, null, null, COL_SCHEME_ID + " ASC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long schemeId = cursor.getLong(cursor.getColumnIndexOrThrow(COL_SCHEME_ID));
                boolean isSaved = isSchemeSaved(userId, schemeId);
                list.add(new Scheme(
                        schemeId,
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_AUTH)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_CAT)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_OBJ)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_BENEFITS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_CRITERIA)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_DOCS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_STEPS)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_PORTAL)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEME_HELPLINE)),
                        isSaved
                ));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public boolean isSchemeSaved(long userId, long schemeId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SAVED_SCHEMES, new String[]{COL_SAVED_ID},
                COL_SAVED_USER_ID + "=? AND " + COL_SAVED_SCHEME_ID + "=?",
                new String[]{String.valueOf(userId), String.valueOf(schemeId)}, null, null, null);
        boolean saved = (cursor != null && cursor.getCount() > 0);
        if (cursor != null) cursor.close();
        return saved;
    }

    public boolean toggleSaveScheme(long userId, long schemeId) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (isSchemeSaved(userId, schemeId)) {
            db.delete(TABLE_SAVED_SCHEMES, COL_SAVED_USER_ID + "=? AND " + COL_SAVED_SCHEME_ID + "=?",
                    new String[]{String.valueOf(userId), String.valueOf(schemeId)});
            return false;
        } else {
            ContentValues cv = new ContentValues();
            cv.put(COL_SAVED_USER_ID, userId);
            cv.put(COL_SAVED_SCHEME_ID, schemeId);
            cv.put(COL_SAVED_DATE, new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
            db.insert(TABLE_SAVED_SCHEMES, null, cv);
            return true;
        }
    }

    // ---------------------------------------------------------------------------------------------
    // FARM DIARY & FINANCIAL CRUD
    // ---------------------------------------------------------------------------------------------

    public long insertDiaryEntry(long userId, String type, String date, String notes, double expense, double income) {
        SQLiteDatabase db = this.getWritableDatabase();
        String createdAt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        ContentValues cv = new ContentValues();
        cv.put(COL_DIARY_USER_ID, userId);
        cv.put(COL_DIARY_TYPE, type);
        cv.put(COL_DIARY_DATE, date);
        cv.put(COL_DIARY_NOTES, notes);
        cv.put(COL_DIARY_EXPENSE, expense);
        cv.put(COL_DIARY_INCOME, income);
        cv.put(COL_DIARY_CREATED, createdAt);

        return db.insert(TABLE_DIARY, null, cv);
    }

    public List<DiaryEntry> getDiaryEntries(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<DiaryEntry> list = new ArrayList<>();
        Cursor cursor = db.query(TABLE_DIARY, null, COL_DIARY_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, COL_DIARY_DATE + " DESC");
        if (cursor != null && cursor.moveToFirst()) {
            do {
                list.add(new DiaryEntry(
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_DIARY_ID)),
                        cursor.getLong(cursor.getColumnIndexOrThrow(COL_DIARY_USER_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_DIARY_TYPE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_DIARY_DATE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_DIARY_NOTES)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_DIARY_EXPENSE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_DIARY_INCOME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_DIARY_CREATED))
                ));
            } while (cursor.moveToNext());
            cursor.close();
        }
        return list;
    }

    public boolean deleteDiaryEntry(long entryId, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_DIARY, COL_DIARY_ID + "=? AND " + COL_DIARY_USER_ID + "=?",
                new String[]{String.valueOf(entryId), String.valueOf(userId)});
        return rows > 0;
    }

    public double[] getDiaryTotals(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        double totalExpense = 0.0;
        double totalIncome = 0.0;

        Cursor cursor = db.rawQuery("SELECT SUM(" + COL_DIARY_EXPENSE + "), SUM(" + COL_DIARY_INCOME + ") FROM " + TABLE_DIARY + " WHERE " + COL_DIARY_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        if (cursor != null && cursor.moveToFirst()) {
            totalExpense = cursor.getDouble(0);
            totalIncome = cursor.getDouble(1);
            cursor.close();
        }
        return new double[]{totalExpense, totalIncome, (totalIncome - totalExpense)};
    }
}
