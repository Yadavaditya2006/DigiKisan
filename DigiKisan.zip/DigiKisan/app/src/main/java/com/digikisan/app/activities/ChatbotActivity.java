package com.digikisan.app.activities;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.adapters.ChatMessageAdapter;
import com.digikisan.app.models.ChatMessage;
import com.digikisan.app.services.FarmerChatbotEngine;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * ChatbotActivity providing guided farming advice through "शेतकरी मित्र" (Shetkari Mitra).
 */
public class ChatbotActivity extends AppCompatActivity {

    private ImageButton btnBackChatbot;
    private RecyclerView rvChatMessages;
    private EditText etChatInput;
    private FloatingActionButton btnSendChat;
    private MaterialButton chipQueryOnion, chipQueryWeather, chipQueryDrip, chipQueryPest;

    private ChatMessageAdapter chatAdapter;
    private List<ChatMessage> messageList = new ArrayList<>();
    private FarmerChatbotEngine chatbotEngine;
    private UserSessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        sessionManager = new UserSessionManager(this);
        chatbotEngine = new FarmerChatbotEngine(this);

        initViews();
        setupRecyclerView();
        setupInitialGreeting();
        setupListeners();
    }

    private void initViews() {
        btnBackChatbot = findViewById(R.id.btnBackChatbot);
        rvChatMessages = findViewById(R.id.rvChatMessages);
        etChatInput = findViewById(R.id.etChatInput);
        btnSendChat = findViewById(R.id.btnSendChat);
        chipQueryOnion = findViewById(R.id.chipQueryOnion);
        chipQueryWeather = findViewById(R.id.chipQueryWeather);
        chipQueryDrip = findViewById(R.id.chipQueryDrip);
        chipQueryPest = findViewById(R.id.chipQueryPest);
    }

    private void setupRecyclerView() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        rvChatMessages.setLayoutManager(layoutManager);
        chatAdapter = new ChatMessageAdapter(this, messageList);
        rvChatMessages.setAdapter(chatAdapter);
    }

    private void setupInitialGreeting() {
        String welcome = getString(R.string.chat_welcome);
        String time = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());
        chatAdapter.addMessage(new ChatMessage(ChatMessage.TYPE_BOT, welcome, time));
    }

    private void setupListeners() {
        btnBackChatbot.setOnClickListener(v -> finish());

        btnSendChat.setOnClickListener(v -> {
            String text = etChatInput.getText().toString().trim();
            if (!text.isEmpty()) {
                sendMessage(text);
                etChatInput.setText("");
            }
        });

        chipQueryOnion.setOnClickListener(v -> sendMessage("कांदा बाजारभाव काय आहे?"));
        chipQueryWeather.setOnClickListener(v -> sendMessage("आजचे हवामान कसे राहील?"));
        chipQueryDrip.setOnClickListener(v -> sendMessage("ठिबक सिंचन अनुदान योजना माहिती सांगा"));
        chipQueryPest.setOnClickListener(v -> sendMessage("पिकाची पाने पिवळी पडत आहेत, काय उपाय करावा?"));
    }

    private void sendMessage(String userMessage) {
        String time = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date());

        // 1. Add User Message
        chatAdapter.addMessage(new ChatMessage(ChatMessage.TYPE_USER, userMessage, time));
        rvChatMessages.smoothScrollToPosition(chatAdapter.getItemCount() - 1);

        // 2. Generate Engine Response
        String botReply = chatbotEngine.generateResponse(
                userMessage,
                sessionManager.getUserId(),
                sessionManager.getUserDistrict()
        );

        // 3. Add Bot Reply with slight natural pacing
        rvChatMessages.postDelayed(() -> {
            chatAdapter.addMessage(new ChatMessage(ChatMessage.TYPE_BOT, botReply, time));
            rvChatMessages.smoothScrollToPosition(chatAdapter.getItemCount() - 1);
        }, 300);
    }
}
