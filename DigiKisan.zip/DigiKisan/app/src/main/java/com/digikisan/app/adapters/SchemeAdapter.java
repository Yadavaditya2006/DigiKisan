package com.digikisan.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.models.Scheme;
import com.digikisan.app.models.User;
import com.digikisan.app.services.SchemeEligibilityEngine;
import java.util.List;

/**
 * RecyclerView Adapter for displaying Government Scheme cards with personalized eligibility badges.
 */
public class SchemeAdapter extends RecyclerView.Adapter<SchemeAdapter.ViewHolder> {

    public interface OnSchemeClickListener {
        void onSchemeClick(Scheme scheme);
        void onSaveToggle(Scheme scheme, int position);
    }

    private final Context context;
    private List<Scheme> schemeList;
    private final User user;
    private final FarmProfile profile;
    private final OnSchemeClickListener listener;

    public SchemeAdapter(Context context, List<Scheme> schemeList, User user, FarmProfile profile, OnSchemeClickListener listener) {
        this.context = context;
        this.schemeList = schemeList;
        this.user = user;
        this.profile = profile;
        this.listener = listener;
    }

    public void updateList(List<Scheme> newList) {
        this.schemeList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_scheme, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Scheme scheme = schemeList.get(position);

        holder.tvSchemeName.setText(scheme.getSchemeName());
        holder.tvSchemeAuthority.setText(scheme.getIssuingAuthority());
        holder.tvSchemeBenefits.setText(scheme.getBenefitsSummary());
        holder.tvSchemeCategoryBadge.setText(scheme.getCategory().replace("_", " "));

        // Personalized Eligibility Matching
        String eligibility = SchemeEligibilityEngine.evaluateEligibility(scheme, user, profile);
        if ("POTENTIALLY_ELIGIBLE".equalsIgnoreCase(eligibility)) {
            holder.tvEligibilityBadge.setText("Potentially Eligible");
            holder.tvEligibilityBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_good));
            holder.tvEligibilityBadge.setTextColor(ContextCompat.getColor(context, R.color.status_good));
        } else if ("CRITERIA_NOT_MET".equalsIgnoreCase(eligibility)) {
            holder.tvEligibilityBadge.setText("Criteria Not Met");
            holder.tvEligibilityBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_risk));
            holder.tvEligibilityBadge.setTextColor(ContextCompat.getColor(context, R.color.status_high_risk));
        } else {
            holder.tvEligibilityBadge.setText("More Info Needed");
            holder.tvEligibilityBadge.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_badge_attention));
            holder.tvEligibilityBadge.setTextColor(ContextCompat.getColor(context, R.color.status_attention));
        }

        // Saved icon state
        if (scheme.isSavedByFarmer()) {
            holder.ivSaveScheme.setColorFilter(ContextCompat.getColor(context, R.color.accent_gold));
        } else {
            holder.ivSaveScheme.setColorFilter(ContextCompat.getColor(context, R.color.text_hint));
        }

        holder.ivSaveScheme.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSaveToggle(scheme, holder.getAdapterPosition());
            }
        });

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSchemeClick(scheme);
            }
        });
    }

    @Override
    public int getItemCount() {
        return schemeList != null ? schemeList.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSchemeName, tvSchemeAuthority, tvSchemeBenefits, tvSchemeCategoryBadge, tvEligibilityBadge;
        ImageView ivSaveScheme;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSchemeName = itemView.findViewById(R.id.tvSchemeName);
            tvSchemeAuthority = itemView.findViewById(R.id.tvSchemeAuthority);
            tvSchemeBenefits = itemView.findViewById(R.id.tvSchemeBenefits);
            tvSchemeCategoryBadge = itemView.findViewById(R.id.tvSchemeCategoryBadge);
            tvEligibilityBadge = itemView.findViewById(R.id.tvEligibilityBadge);
            ivSaveScheme = itemView.findViewById(R.id.ivSaveScheme);
        }
    }
}
