package com.digikisan.app.services;

import com.digikisan.app.models.CropAssessment;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Rule-based crop condition evaluation engine.
 * Applies agricultural university (MPKV/PDKV/ICAR) logic to generate transparent preliminary assessments.
 * Explicitly states that it does not guarantee yields or financial outcomes.
 */
public class CropAssessmentEngine {

    public static CropAssessment evaluate(long userId, String crop, String stage, 
                                          String irrigation, String interval, String soil, 
                                          boolean waterlogging, String symptoms) {

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        StringBuilder supporting = new StringBuilder();
        StringBuilder risks = new StringBuilder();
        StringBuilder actions = new StringBuilder();
        StringBuilder precautions = new StringBuilder();

        int riskScore = 0; // 0 = Good, 1-2 = Attention, 3+ = High Risk

        // 1. Evaluate Waterlogging & Soil
        if (waterlogging) {
            riskScore += 2;
            risks.append("• शेतात पाणी साचले आहे: पिकाच्या मुळांना प्राणवायू (Oxygen) न मिळाल्याने मुळे कुजण्याची (Root Rot) दाट शक्यता असते.\n");
            actions.append("• त्वरित शेतातील पाण्याचा निचरा करण्यासाठी चर (Drainage Trench) काढा.\n");
            precautions.append("• पाणी साचलेल्या स्थितीत कोणतेही रासायनिक खत किंवा युरिया देणे टाळा, अन्यथा पिकाचे नुकसान वाढेल.\n");
        } else {
            supporting.append("• शेतात पाण्याचा निचरा चांगला आहे, मुळांची कार्यक्षमता उत्तम राहील.\n");
        }

        // 2. Evaluate Irrigation Method & Soil Matching
        if ("Flood / Furrow".equalsIgnoreCase(irrigation) || "पाट पाणी (मोकळे पाणी)".equalsIgnoreCase(irrigation)) {
            if ("Heavy Black Cotton Soil (काळी जमीन)".equalsIgnoreCase(soil)) {
                riskScore += 1;
                risks.append("• काळ्या जमिनीत पाट पाण्याने अति-ओल राहून बुरशीजन्य रोगांचा प्रादुर्भाव वाढू शकतो.\n");
                actions.append("• वाफसा (Aeration) आल्याशिवाय पुढील पाणी देऊ नका.\n");
            } else {
                supporting.append("• पाट पाण्याने सिंचन करताना जमीन हलकी असल्याने निचरा समाधानकारक राहील.\n");
            }
        } else if ("Drip Irrigation".equalsIgnoreCase(irrigation) || "ठिबक सिंचन".equalsIgnoreCase(irrigation)) {
            supporting.append("• ठिबक सिंचनामुळे पिकास संतुलित पाणी व अन्नद्रव्ये मिळतात; पाण्याचा अपव्यय टळतो.\n");
        }

        // 3. Evaluate Pest & Disease Symptoms
        if (symptoms != null && !symptoms.isEmpty() && !symptoms.contains("Normal") && !symptoms.contains("निरोगी")) {
            if (symptoms.contains("Yellowing") || symptoms.contains("पिवळी")) {
                riskScore += 1;
                risks.append("• पाने पिवळी पडत आहेत: नत्र किंवा सूक्ष्म अन्नद्रव्यांची (लोह/झिंक) कमतरता किंवा मुळांवर पाणी साचल्यामुळे क्लोरोसिस होऊ शकतो.\n");
                actions.append("• १९:१९:१९ विद्राव्य खत (५ ग्रॅम/लिटर) किंवा सूक्ष्म अन्नद्रव्यांची फवारणी करावी.\n");
            } else if (symptoms.contains("Spots") || symptoms.contains("ठिपके") || symptoms.contains("करपा")) {
                riskScore += 2;
                risks.append("• पानांवर ठिपके / करपा: बुरशीजन्य रोगाचा प्रादुर्भाव वेगाने पसरू शकतो.\n");
                actions.append("• शिफारशीत बुरशीनाशक (उदा. मॅन्कोझेब २.५ ग्रॅम किंवा कार्बेन्डाझिम १ ग्रॅम प्रति लिटर पाण्यात) फवारणी करावी.\n");
                precautions.append("• फवारणी स्वच्छ सूर्यप्रकाश असताना सकाळी किंवा संध्याकाळी करावी; वाऱ्याच्या विरुद्ध दिशेने फवारणी करू नका.\n");
            } else if (symptoms.contains("Wilting") || symptoms.contains("कोमेजत") || symptoms.contains("मर")) {
                riskScore += 3;
                risks.append("• झाडे कोमेजत आहेत (मर रोग / Wilt): मुळांना बुरशीची लागण झाल्याचे गंभीर लक्षण असू शकते.\n");
                actions.append("• बाधित झाडांच्या मुळांशी कॉपर ऑक्सिक्लोराईड (३ ग्रॅम/लिटर) किंवा ट्रायकोडर्मा जैविक बुरशीनाशकाचे ड्रेचिंग (आळवणी) करा.\n");
            } else if (symptoms.contains("Borer") || symptoms.contains("पोखरणारी")) {
                riskScore += 2;
                risks.append("• खोड किंवा फळ पोखरणारी अळी: थेट उत्पादन घटवणारी कीड आहे.\n");
                actions.append("• कामगंध सापळे (Pheromone Traps) हेक्टरी ५ ते ८ लावा; प्रादुर्भाव वाढल्यास शिफारशीत कीटकनाशकाची फवारणी करा.\n");
            }
        } else {
            supporting.append("• पिकावर सध्या कोणत्याही गंभीर किडीची किंवा रोगाची लक्षणे दिसून येत नाहीत.\n");
            actions.append("• सध्याची नियमित मशागत, पाणी आणि खत व्यवस्थापन सुरू ठेवावे.\n");
        }

        // 4. Growth Stage Guidance
        if (stage != null && (stage.contains("Flowering") || stage.contains("फुलधारणा"))) {
            precautions.append("• फुलधारणेच्या संवेदनशील काळात जास्त तीव्र कीटकनाशकांची फवारणी टाळावी, जेणेकरून परागीभवन करणाऱ्या मधमाश्यांचे रक्षण होईल.\n");
        }

        // Determine Final Category
        String category;
        if (riskScore == 0) {
            category = "GOOD";
            if (actions.length() == 0) actions.append("• नियमित निरीक्षण ठेवा आणि वेळोवेळी तणनियंत्रण करा.\n");
            precautions.append("• हवामान बदलांवर लक्ष ठेवा आणि पाण्याचा अपव्यय टाळा.\n");
        } else if (riskScore <= 2) {
            category = "ATTENTION";
        } else {
            category = "HIGH_RISK";
        }

        return new CropAssessment(
                0,
                userId,
                crop,
                stage,
                irrigation,
                interval,
                soil,
                waterlogging,
                symptoms,
                category,
                supporting.toString().trim(),
                risks.toString().trim(),
                actions.toString().trim(),
                precautions.toString().trim(),
                today
        );
    }
}
