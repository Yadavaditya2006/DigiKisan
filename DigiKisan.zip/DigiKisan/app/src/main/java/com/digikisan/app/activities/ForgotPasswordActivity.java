package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.utils.InputValidator;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * ForgotPasswordActivity — local password reset for demonstration / offline use.
 *
 * Architecture: This app uses a local SQLite-only store with no external authentication
 * service, SMS OTP gateway, or email verification. Accordingly, this screen implements
 * an identity verification approach appropriate to a local prototype:
 *
 *   1. The user must supply the exact registered mobile number (10 digits).
 *   2. The system checks whether the account actually exists.
 *   3. If the account is found, the user may set a new salted-hashed password directly.
 *   4. The old password is immediately invalidated because a new salt and hash are stored.
 *
 * NOTE for production: In a live application, step 3 would require OTP verification
 * via SMS (e.g., Firebase Phone Auth or a similar gateway) before allowing the password
 * change. That mechanism requires backend configuration outside the scope of this
 * offline prototype.
 */
public class ForgotPasswordActivity extends AppCompatActivity {

    private TextInputEditText etRecoveryMobile, etNewPassword, etConfirmNewPassword;
    private MaterialButton btnResetPassword;
    private TextView tvBackToLogin;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        dbHelper = DatabaseHelper.getInstance(this);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etRecoveryMobile = findViewById(R.id.etRecoveryMobile);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmNewPassword = findViewById(R.id.etConfirmNewPassword);
        btnResetPassword = findViewById(R.id.btnResetPassword);
        tvBackToLogin = findViewById(R.id.tvBackToLogin);
    }

    private void setupListeners() {
        tvBackToLogin.setOnClickListener(v -> finish());

        btnResetPassword.setOnClickListener(v -> performPasswordReset());
    }

    private void performPasswordReset() {
        String mobile = (etRecoveryMobile.getText() != null) ? etRecoveryMobile.getText().toString().trim() : "";
        String newPassword = (etNewPassword.getText() != null) ? etNewPassword.getText().toString().trim() : "";
        String confirmPassword = (etConfirmNewPassword.getText() != null) ? etConfirmNewPassword.getText().toString().trim() : "";

        // --- Validation ---
        if (mobile.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, R.string.err_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!InputValidator.isValidMobile(mobile)) {
            Toast.makeText(this, R.string.err_invalid_mobile, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!InputValidator.isValidPassword(newPassword)) {
            Toast.makeText(this, R.string.err_password_short, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            Toast.makeText(this, R.string.err_new_password_mismatch, Toast.LENGTH_SHORT).show();
            return;
        }

        String cleanMobile = InputValidator.cleanMobileNumber(mobile);

        // --- Step 1: Verify account exists ---
        if (!dbHelper.userExistsByMobile(cleanMobile)) {
            Toast.makeText(this, R.string.err_no_account, Toast.LENGTH_LONG).show();
            return;
        }

        // --- Step 2: Reset password ---
        boolean success = dbHelper.resetUserPassword(cleanMobile, newPassword);

        if (success) {
            Toast.makeText(this, R.string.reset_success, Toast.LENGTH_LONG).show();
            // Navigate back to Login so the user can sign in with the new password
            Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, R.string.reset_failed, Toast.LENGTH_SHORT).show();
        }
    }
}
