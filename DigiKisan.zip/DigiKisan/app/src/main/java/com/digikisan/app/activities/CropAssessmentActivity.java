package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.CropAssessment;
import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.services.CropAssessmentEngine;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

/**
 * CropAssessmentActivity collects farmer observations and coordinates diagnostic evaluation.
 */
public class CropAssessmentActivity extends AppCompatActivity {

    private ImageButton btnBackAssessment;
    private Spinner spinnerCropName, spinnerGrowthStage, spinnerIrrigationMethod;
    private Spinner spinnerWateringInterval, spinnerSoilType, spinnerSymptoms;
    private SwitchMaterial switchWaterlogging;
    private MaterialButton btnSubmitAssessment;

    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;

    private static final String[] CROPS = {
            "Soybean (सोयाबीन)", "Cotton (कापूस)", "Onion (कांदा)", "Sugarcane (ऊस)",
            "Gram / Chana (हरभरा)", "Wheat (गहू)", "Pomegranate (डाळिंब)", "Tomato (टोमॅटो)", "Grapes (द्राक्षे)"
    };

    private static final String[] STAGES = {
            "Sowing / Germination (उगवण / रोपवाटिका)",
            "Vegetative Growth (शाकीय वाढ)",
            "Flowering (फुलधारणा)",
            "Fruiting / Pod Formation (फळ / शेंगा लागवड)",
            "Maturity / Harvesting (परिपक्वता / काढणी)"
    };

    private static final String[] IRRIGATIONS = {
            "Drip Irrigation (ठिबक सिंचन)",
            "Sprinkler Irrigation (तुषार सिंचन)",
            "Flood / Furrow (पाट पाणी / मोकळे पाणी)",
            "Rainfed (जिरायती / फक्त पावसावर)"
    };

    private static final String[] INTERVALS = {
            "Daily (रोज)",
            "Every 2-3 Days (२-३ दिवसांनी)",
            "Weekly (आठवड्यातून एकदा)",
            "Every 10-15 Days (१०-१५ दिवसांनी)",
            "Rainfed Only (केवळ पावसावर)"
    };

    private static final String[] SOILS = {
            "Heavy Black Cotton Soil (काळी कसदार जमीन)",
            "Medium Red / Laterite Soil (मध्यम तांबडी जमीन)",
            "Loamy / Alluvial Soil (गाळाची हलकी जमीन)"
    };

    private static final String[] SYMPTOMS = {
            "Normal, Healthy Appearance (पीक निरोगी दिसत आहे)",
            "Leaf Yellowing / Chlorosis (पाने पिवळी पडत आहेत)",
            "Leaf Spots / Fungal Blight (पानांवर ठिपके / करपा)",
            "Plant Wilting / Drooping (झाडे कोमेजत आहेत / मर रोग)",
            "Stem / Pod Borer Holes (खोड किंवा फळ पोखरणारी अळी)"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_assessment);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupSpinners();
        prefillFromFarmProfile();
        setupListeners();
    }

    private void initViews() {
        btnBackAssessment = findViewById(R.id.btnBackAssessment);
        spinnerCropName = findViewById(R.id.spinnerCropName);
        spinnerGrowthStage = findViewById(R.id.spinnerGrowthStage);
        spinnerIrrigationMethod = findViewById(R.id.spinnerIrrigationMethod);
        spinnerWateringInterval = findViewById(R.id.spinnerWateringInterval);
        spinnerSoilType = findViewById(R.id.spinnerSoilType);
        spinnerSymptoms = findViewById(R.id.spinnerSymptoms);
        switchWaterlogging = findViewById(R.id.switchWaterlogging);
        btnSubmitAssessment = findViewById(R.id.btnSubmitAssessment);
    }

    private void setupSpinners() {
        setCustomSpinnerAdapter(spinnerCropName, CROPS);
        setCustomSpinnerAdapter(spinnerGrowthStage, STAGES);
        setCustomSpinnerAdapter(spinnerIrrigationMethod, IRRIGATIONS);
        setCustomSpinnerAdapter(spinnerWateringInterval, INTERVALS);
        setCustomSpinnerAdapter(spinnerSoilType, SOILS);
        setCustomSpinnerAdapter(spinnerSymptoms, SYMPTOMS);
    }

    private void setCustomSpinnerAdapter(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner_selected, items);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinner.setAdapter(adapter);
    }

    private void prefillFromFarmProfile() {
        FarmProfile fp = dbHelper.getFarmProfile(sessionManager.getUserId());
        if (fp != null && fp.getPrimaryCrop() != null) {
            for (int i = 0; i < CROPS.length; i++) {
                if (CROPS[i].contains(fp.getPrimaryCrop())) {
                    spinnerCropName.setSelection(i);
                    break;
                }
            }
        }
    }

    private void setupListeners() {
        btnBackAssessment.setOnClickListener(v -> finish());
        btnSubmitAssessment.setOnClickListener(v -> evaluateCropCondition());
    }

    private void evaluateCropCondition() {
        String crop = spinnerCropName.getSelectedItem().toString();
        String stage = spinnerGrowthStage.getSelectedItem().toString();
        String irrigation = spinnerIrrigationMethod.getSelectedItem().toString();
        String interval = spinnerWateringInterval.getSelectedItem().toString();
        String soil = spinnerSoilType.getSelectedItem().toString();
        boolean waterlogging = switchWaterlogging.isChecked();
        String symptoms = spinnerSymptoms.getSelectedItem().toString();

        long userId = sessionManager.getUserId();

        CropAssessment assessment = CropAssessmentEngine.evaluate(
                userId, crop, stage, irrigation, interval, soil, waterlogging, symptoms
        );

        // Save to SQLite
        long assessmentId = dbHelper.insertCropAssessment(assessment);
        assessment.setId(assessmentId);

        // Open Result Activity
        Intent intent = new Intent(CropAssessmentActivity.this, AssessmentResultActivity.class);
        intent.putExtra("extra_assessment", assessment);
        startActivity(intent);
        finish();
    }
}
