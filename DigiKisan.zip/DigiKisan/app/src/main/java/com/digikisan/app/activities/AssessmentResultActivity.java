package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.digikisan.app.R;
import com.digikisan.app.models.CropAssessment;

/**
 * AssessmentResultActivity displays the explainable diagnostic evaluation
 * with positive factors, concerns, suggested actions, and precautions.
 */
public class AssessmentResultActivity extends AppCompatActivity {

    private ImageButton btnBackResult;
    private TextView tvResultCropTitle, tvResultCategoryBadge, tvResultDate;
    private TextView tvSupportingFactors, tvRiskFactors, tvSuggestedActions, tvPrecautions;

    private CropAssessment assessment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_result);

        initViews();
        loadDataFromIntent();
        setupListeners();
    }

    private void initViews() {
        btnBackResult = findViewById(R.id.btnBackResult);
        tvResultCropTitle = findViewById(R.id.tvResultCropTitle);
        tvResultCategoryBadge = findViewById(R.id.tvResultCategoryBadge);
        tvResultDate = findViewById(R.id.tvResultDate);
        tvSupportingFactors = findViewById(R.id.tvSupportingFactors);
        tvRiskFactors = findViewById(R.id.tvRiskFactors);
        tvSuggestedActions = findViewById(R.id.tvSuggestedActions);
        tvPrecautions = findViewById(R.id.tvPrecautions);
    }

    private void loadDataFromIntent() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("extra_assessment")) {
            assessment = (CropAssessment) intent.getSerializableExtra("extra_assessment");
        }

        if (assessment != null) {
            bindData();
        }
    }

    private void bindData() {
        tvResultCropTitle.setText(assessment.getCropName() + " — " + assessment.getGrowthStage());
        tvResultDate.setText("मूल्यांकन दिनांक: " + assessment.getAssessmentDate());

        // Category Badge
        String category = assessment.getAssessmentCategory();
        if ("GOOD".equalsIgnoreCase(category)) {
            tvResultCategoryBadge.setText(R.string.res_good);
            tvResultCategoryBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_good));
            tvResultCategoryBadge.setTextColor(ContextCompat.getColor(this, R.color.status_good));
        } else if ("HIGH_RISK".equalsIgnoreCase(category)) {
            tvResultCategoryBadge.setText(R.string.res_high_risk);
            tvResultCategoryBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_risk));
            tvResultCategoryBadge.setTextColor(ContextCompat.getColor(this, R.color.status_high_risk));
        } else {
            tvResultCategoryBadge.setText(R.string.res_attention);
            tvResultCategoryBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_attention));
            tvResultCategoryBadge.setTextColor(ContextCompat.getColor(this, R.color.status_attention));
        }

        tvSupportingFactors.setText(assessment.getSupportingFactors().isEmpty() ? "• कोणतीही विशेष अनुकूल नोंद नाही." : assessment.getSupportingFactors());
        tvRiskFactors.setText(assessment.getRiskFactors().isEmpty() ? "• कोणतीही गंभीर चिंता किंवा धोका आढळला नाही." : assessment.getRiskFactors());
        tvSuggestedActions.setText(assessment.getSuggestedActions());
        tvPrecautions.setText(assessment.getPrecautions());
    }

    private void setupListeners() {
        btnBackResult.setOnClickListener(v -> finish());
    }
}
