package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.adapters.SchemeAdapter;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.models.Scheme;
import com.digikisan.app.models.User;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * SchemeListActivity allows farmers to browse and filter Maharashtra and Central government schemes.
 */
public class SchemeListActivity extends AppCompatActivity implements SchemeAdapter.OnSchemeClickListener {

    private ImageButton btnBackSchemes;
    private ChipGroup chipGroupSchemes;
    private RecyclerView rvSchemes;

    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;
    private SchemeAdapter schemeAdapter;
    private List<Scheme> currentSchemes = new ArrayList<>();
    private User currentUser;
    private FarmProfile farmProfile;
    private String selectedCategory = "ALL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheme_list);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        currentUser = dbHelper.getUserById(sessionManager.getUserId());
        farmProfile = dbHelper.getFarmProfile(sessionManager.getUserId());

        initViews();
        setupRecyclerView();
        setupListeners();
        loadSchemes("ALL");
    }

    private void initViews() {
        btnBackSchemes = findViewById(R.id.btnBackSchemes);
        chipGroupSchemes = findViewById(R.id.chipGroupSchemes);
        rvSchemes = findViewById(R.id.rvSchemes);
    }

    private void setupRecyclerView() {
        rvSchemes.setLayoutManager(new LinearLayoutManager(this));
        schemeAdapter = new SchemeAdapter(this, currentSchemes, currentUser, farmProfile, this);
        rvSchemes.setAdapter(schemeAdapter);
    }

    private void setupListeners() {
        btnBackSchemes.setOnClickListener(v -> finish());

        chipGroupSchemes.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.chipIncome) {
                selectedCategory = "INCOME_SUPPORT";
            } else if (checkedId == R.id.chipInsurance) {
                selectedCategory = "INSURANCE";
            } else if (checkedId == R.id.chipIrrigation) {
                selectedCategory = "IRRIGATION";
            } else if (checkedId == R.id.chipMachinery) {
                selectedCategory = "MACHINERY";
            } else {
                selectedCategory = "ALL";
            }
            loadSchemes(selectedCategory);
        });
    }

    private void loadSchemes(String category) {
        currentSchemes = dbHelper.getSchemesByCategory(sessionManager.getUserId(), category);
        schemeAdapter.updateList(currentSchemes);
    }

    @Override
    public void onSchemeClick(Scheme scheme) {
        Intent intent = new Intent(SchemeListActivity.this, SchemeDetailActivity.class);
        intent.putExtra("extra_scheme", scheme);
        startActivity(intent);
    }

    @Override
    public void onSaveToggle(Scheme scheme, int position) {
        boolean saved = dbHelper.toggleSaveScheme(sessionManager.getUserId(), scheme.getId());
        scheme.setSavedByFarmer(saved);
        schemeAdapter.notifyItemChanged(position);

        if (saved) {
            Toast.makeText(this, R.string.saved_scheme_success, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "योजना यादीतून हटवली आहे", Toast.LENGTH_SHORT).show();
        }
    }
}
