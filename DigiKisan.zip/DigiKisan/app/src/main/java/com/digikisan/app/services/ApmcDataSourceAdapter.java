package com.digikisan.app.services;

import android.content.Context;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.ApmcPrice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Adapter and domain intelligence service for Maharashtra APMC markets.
 * Maintains complete official administrative hierarchy (Division -> District -> APMC Market -> Commodity -> Prices)
 * and price trend analytics.
 */
public class ApmcDataSourceAdapter {

    // All 6 Administrative Revenue Divisions in Maharashtra
    public static final String[] DIVISIONS = {
            "All Divisions (सर्व विभाग)",
            "Pune (पुणे विभाग)",
            "Nashik (नाशिक विभाग)",
            "Chhatrapati Sambhajinagar (छ. संभाजीनगर विभाग)",
            "Amravati (अमरावती विभाग)",
            "Nagpur (नागपूर विभाग)",
            "Konkan (कोकण विभाग)"
    };

    // All 36 Official Maharashtra Districts
    public static final String[] DISTRICTS = {
            "All Districts (सर्व जिल्हे)",
            "Ahmednagar (अहमदनगर)", "Akola (अकोला)", "Amravati (अमरावती)", "Beed (बीड)",
            "Bhandara (भंडारा)", "Buldhana (बुलढाणा)", "Chandrapur (चंद्रपूर)",
            "Chhatrapati Sambhajinagar (छत्रपती संभाजीनगर)", "Dhule (धुळे)", "Gadchiroli (गडचिरोली)",
            "Gondia (गोंदिया)", "Hingoli (हिंगोली)", "Jalgaon (जळगाव)", "Jalna (जालना)",
            "Kolhapur (कोल्हापूर)", "Latur (लातूर)", "Mumbai City (मुंबई शहर)",
            "Mumbai Suburban (मुंबई उपनगर)", "Nagpur (नागपूर)", "Nanded (नांदेड)",
            "Nandurbar (नंदुरबार)", "Nashik (नाशिक)", "Dharashiv (धाराशीव)", "Palghar (पालघर)",
            "Parbhani (परभणी)", "Pune (पुणे)", "Raigad (रायगड)", "Ratnagiri (रत्नागिरी)",
            "Sangli (सांगली)", "Satara (सातारा)", "Sindhudurg (सिंधुदुर्ग)",
            "Solapur (सोलापूर)", "Thane (ठाणे)", "Wardha (वर्धा)", "Washim (वाशीम)",
            "Yavatmal (यवतमाळ)"
    };

    // Key Agricultural Commodities Traded in Maharashtra APMCs
    public static final String[] COMMODITIES = {
            "All Commodities (सर्व शेतमाल)",
            "Onion (कांदा)",
            "Cotton (कापूस)",
            "Soybean (सोयाबीन)",
            "Gram / Chana (हरभरा)",
            "Tur / Arhar (तूर)",
            "Wheat (गहू)",
            "Jowar (ज्वारी)",
            "Bajra (बाजरी)",
            "Sugarcane (ऊस)",
            "Pomegranate (डाळिंब)",
            "Grapes (द्राक्षे)",
            "Orange (संत्रा)",
            "Mango (आंबा)",
            "Tomato (टोमॅटो)"
    };

    // Division to Districts Mapping
    private static final Map<String, List<String>> DIVISION_DISTRICTS_MAP = new LinkedHashMap<>();

    // District to APMC Markets Mapping
    private static final Map<String, List<String>> DISTRICT_MARKETS_MAP = new LinkedHashMap<>();

    static {
        // 1. Pune Division
        DIVISION_DISTRICTS_MAP.put("Pune", Arrays.asList("Pune", "Satara", "Solapur", "Kolhapur", "Sangli"));
        
        // 2. Nashik Division
        DIVISION_DISTRICTS_MAP.put("Nashik", Arrays.asList("Nashik", "Ahmednagar", "Dhule", "Jalgaon", "Nandurbar"));
        
        // 3. Chhatrapati Sambhajinagar Division
        DIVISION_DISTRICTS_MAP.put("Chhatrapati Sambhajinagar", Arrays.asList(
                "Chhatrapati Sambhajinagar", "Jalna", "Beed", "Latur", "Dharashiv", "Nanded", "Parbhani", "Hingoli"
        ));
        
        // 4. Amravati Division
        DIVISION_DISTRICTS_MAP.put("Amravati", Arrays.asList("Amravati", "Akola", "Buldhana", "Yavatmal", "Washim"));
        
        // 5. Nagpur Division
        DIVISION_DISTRICTS_MAP.put("Nagpur", Arrays.asList("Nagpur", "Wardha", "Bhandara", "Gondia", "Chandrapur", "Gadchiroli"));
        
        // 6. Konkan Division
        DIVISION_DISTRICTS_MAP.put("Konkan", Arrays.asList(
                "Mumbai City", "Mumbai Suburban", "Thane", "Palghar", "Raigad", "Ratnagiri", "Sindhudurg"
        ));

        // District -> APMCs
        // Pune
        DISTRICT_MARKETS_MAP.put("Pune", Arrays.asList("Pune (Gultekdi)", "Baramati", "Manchar", "Shirur", "Junnar", "Indapur"));
        DISTRICT_MARKETS_MAP.put("Satara", Arrays.asList("Karad", "Satara Yard", "Phaltan", "Wai", "Koregaon"));
        DISTRICT_MARKETS_MAP.put("Solapur", Arrays.asList("Solapur Yard", "Barshi", "Pandharpur", "Karmala", "Akkalkot"));
        DISTRICT_MARKETS_MAP.put("Kolhapur", Arrays.asList("Kolhapur Yard", "Gadhinglaj", "Jaisingpur", "Vadgaon"));
        DISTRICT_MARKETS_MAP.put("Sangli", Arrays.asList("Sangli Yard", "Tasgaon", "Islampur", "Vita", "Atpadi"));

        // Nashik
        DISTRICT_MARKETS_MAP.put("Nashik", Arrays.asList("Lasalgaon", "Pimpalgaon Baswant", "Nashik Yard", "Malegaon", "Yeola", "Kalwan", "Sinnar"));
        DISTRICT_MARKETS_MAP.put("Ahmednagar", Arrays.asList("Rahata", "Kopargaon", "Ahmednagar Yard", "Sangamner", "Newasa", "Shrirampur"));
        DISTRICT_MARKETS_MAP.put("Dhule", Arrays.asList("Dhule Yard", "Dondaicha", "Shirpur", "Sakri"));
        DISTRICT_MARKETS_MAP.put("Jalgaon", Arrays.asList("Jalgaon Yard", "Bhusawal", "Chalisgaon", "Chopda", "Raver", "Amalner"));
        DISTRICT_MARKETS_MAP.put("Nandurbar", Arrays.asList("Nandurbar Yard", "Shahada", "Navapur", "Taloda"));

        // Chhatrapati Sambhajinagar (Aurangabad)
        DISTRICT_MARKETS_MAP.put("Chhatrapati Sambhajinagar", Arrays.asList("Chhatrapati Sambhajinagar Yard", "Vaijapur", "Paithan", "Kannad", "Gangapur"));
        DISTRICT_MARKETS_MAP.put("Jalna", Arrays.asList("Jalna Yard", "Partur", "Ambad", "Bhokardan", "Jafrabad"));
        DISTRICT_MARKETS_MAP.put("Beed", Arrays.asList("Beed Yard", "Majalgaon", "Georai", "Parli Vaijnath", "Ashti"));
        DISTRICT_MARKETS_MAP.put("Latur", Arrays.asList("Latur Yard", "Udgir", "Ahmedpur", "Nilanga", "Ausa"));
        DISTRICT_MARKETS_MAP.put("Dharashiv", Arrays.asList("Dharashiv Yard", "Tuljapur", "Umarga", "Kalamb", "Paranda"));
        DISTRICT_MARKETS_MAP.put("Nanded", Arrays.asList("Nanded Yard", "Loha", "Degloor", "Kinwat", "Bhokar"));
        DISTRICT_MARKETS_MAP.put("Parbhani", Arrays.asList("Parbhani Yard", "Gangakhed", "Jintur", "Sailu", "Pathri"));
        DISTRICT_MARKETS_MAP.put("Hingoli", Arrays.asList("Hingoli Yard", "Basmath", "Kalamnuri", "Sengon"));

        // Amravati
        DISTRICT_MARKETS_MAP.put("Amravati", Arrays.asList("Amravati Yard", "Morshi", "Warud", "Achalpur", "Daryapur", "Chandur Railway"));
        DISTRICT_MARKETS_MAP.put("Akola", Arrays.asList("Akola Yard", "Akot", "Balapur", "Murtizapur", "Telhara"));
        DISTRICT_MARKETS_MAP.put("Buldhana", Arrays.asList("Khamgaon Yard", "Malkapur", "Mehkar", "Chikhli", "Jalgaon Jamod"));
        DISTRICT_MARKETS_MAP.put("Yavatmal", Arrays.asList("Yavatmal Yard", "Pusad", "Wani", "Umarkhed", "Darwha", "Pandharkawada"));
        DISTRICT_MARKETS_MAP.put("Washim", Arrays.asList("Washim Yard", "Karanja Lad", "Risod", "Malegaon (Washim)", "Mangrulpir"));

        // Nagpur
        DISTRICT_MARKETS_MAP.put("Nagpur", Arrays.asList("Nagpur (Kalamna Yard)", "Katol", "Saoner", "Ramtek", "Umred", "Kalameshwar"));
        DISTRICT_MARKETS_MAP.put("Wardha", Arrays.asList("Wardha Yard", "Hinganghat", "Arvi", "Pulgaon", "Deoli"));
        DISTRICT_MARKETS_MAP.put("Bhandara", Arrays.asList("Bhandara Yard", "Tumsar", "Pauni", "Sakoli", "Lakhandur"));
        DISTRICT_MARKETS_MAP.put("Gondia", Arrays.asList("Gondia Yard", "Tirora", "Arjuni Morgaon", "Goregaon"));
        DISTRICT_MARKETS_MAP.put("Chandrapur", Arrays.asList("Chandrapur Yard", "Warora", "Rajura", "Bhadrawati", "Mul"));
        DISTRICT_MARKETS_MAP.put("Gadchiroli", Arrays.asList("Gadchiroli Yard", "Chamorshi", "Aheri", "Armori", "Kurkheda"));

        // Konkan
        DISTRICT_MARKETS_MAP.put("Mumbai City", Arrays.asList("Vashi (APMC Navi Mumbai)", "Byculla Market"));
        DISTRICT_MARKETS_MAP.put("Mumbai Suburban", Arrays.asList("Vashi (APMC Navi Mumbai)", "Dadar Wholesale"));
        DISTRICT_MARKETS_MAP.put("Thane", Arrays.asList("Kalyan Yard", "Ulhasnagar", "Murbad", "Shahapur"));
        DISTRICT_MARKETS_MAP.put("Palghar", Arrays.asList("Palghar Yard", "Dahanu", "Wada", "Jawhar"));
        DISTRICT_MARKETS_MAP.put("Raigad", Arrays.asList("Panvel Yard", "Pen", "Roha", "Mangaon", "Karjat"));
        DISTRICT_MARKETS_MAP.put("Ratnagiri", Arrays.asList("Ratnagiri Yard", "Chiplun", "Khed", "Guhagar", "Rajapur"));
        DISTRICT_MARKETS_MAP.put("Sindhudurg", Arrays.asList("Kudal Yard", "Sawantwadi", "Kankavli", "Malvan", "Vengurla"));
    }

    private final DatabaseHelper dbHelper;

    public ApmcDataSourceAdapter(Context context) {
        this.dbHelper = DatabaseHelper.getInstance(context);
    }

    /**
     * Get districts belonging to a specific administrative division.
     */
    public static List<String> getDistrictsForDivision(String division) {
        String cleanDiv = extractBaseName(division);
        if (cleanDiv.isEmpty() || cleanDiv.startsWith("All") || cleanDiv.startsWith("सर्व")) {
            // Return all districts
            List<String> allDistricts = new ArrayList<>();
            allDistricts.add("All Districts (सर्व जिल्हे)");
            for (int i = 1; i < DISTRICTS.length; i++) {
                allDistricts.add(DISTRICTS[i]);
            }
            return allDistricts;
        }

        List<String> list = new ArrayList<>();
        list.add("All Districts (सर्व जिल्हे)");
        for (Map.Entry<String, List<String>> entry : DIVISION_DISTRICTS_MAP.entrySet()) {
            if (entry.getKey().toLowerCase().contains(cleanDiv.toLowerCase()) ||
                cleanDiv.toLowerCase().contains(entry.getKey().toLowerCase())) {
                for (String dist : entry.getValue()) {
                    // Find matching formatted name from DISTRICTS array
                    String formatted = getFormattedDistrictName(dist);
                    list.add(formatted);
                }
                break;
            }
        }
        return list;
    }

    /**
     * Get APMC markets belonging to a specific district.
     */
    public static List<String> getMarketsForDistrict(String district) {
        String cleanDist = extractBaseName(district);
        List<String> markets = new ArrayList<>();
        markets.add("All Markets (सर्व बाजार समित्या)");

        if (cleanDist.isEmpty() || cleanDist.startsWith("All") || cleanDist.startsWith("सर्व")) {
            return markets;
        }

        for (Map.Entry<String, List<String>> entry : DISTRICT_MARKETS_MAP.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(cleanDist) ||
                cleanDist.toLowerCase().contains(entry.getKey().toLowerCase()) ||
                entry.getKey().toLowerCase().contains(cleanDist.toLowerCase())) {
                markets.addAll(entry.getValue());
                break;
            }
        }
        return markets;
    }

    /**
     * Retrieve market prices using the full 4-level administrative hierarchy:
     * Division -> District -> APMC Market -> Commodity.
     */
    public List<ApmcPrice> getMarketPrices(String division, String district, String market, String commodity) {
        String cleanDiv = extractBaseName(division);
        String cleanDist = extractBaseName(district);
        String cleanMarket = extractBaseName(market);
        String cleanComm = extractBaseName(commodity);

        return dbHelper.getApmcPricesByHierarchy(cleanDiv, cleanDist, cleanMarket, cleanComm);
    }

    public List<ApmcPrice> getMarketPrices(String district, String commodity) {
        return getMarketPrices("", district, "", commodity);
    }

    public List<ApmcPrice> getNeighbouringMarketComparisons(String commodity, long currentPriceId) {
        return dbHelper.getComparableMarketsForCommodity(commodity, currentPriceId);
    }

    /**
     * Algorithmic evaluation of price trend:
     * Rising (> +3%), Falling (< -3%), Relatively Stable (-3% to +3%), or Insufficient Data.
     */
    public static String calculateTrend(double currentModal, double previousModal) {
        if (previousModal <= 0 || currentModal <= 0) {
            return "INSUFFICIENT";
        }
        double percentage = ((currentModal - previousModal) / previousModal) * 100.0;
        if (percentage > 3.0) {
            return "RISING";
        } else if (percentage < -3.0) {
            return "FALLING";
        } else {
            return "STABLE";
        }
    }

    /**
     * Generates an objective, evidence-based market explanation.
     */
    public static String generateMarketExplanation(String commodity, double currentModal, 
                                                    double prevModal, int arrivals, String trend) {
        StringBuilder sb = new StringBuilder();

        if ("RISING".equalsIgnoreCase(trend)) {
            sb.append("• भावात वाढ (तेजी): ");
            if (arrivals < 5000) {
                sb.append("बाजार समितीत आवक मर्यादित (").append(arrivals).append(" क्विंटल) राहिल्यामुळे आणि खरेदीदारांची मागणी वाढल्याने सर्वसाधारण भावात सुधारणा झाली आहे.\n");
            } else {
                sb.append("बाजारात आवक भरपूर असूनही आंतरराज्यीय व प्रक्रिया उद्योगांकडून जोरदार मागणी असल्यामुळे दरात तेजी टिकून आहे.\n");
            }
            sb.append("• सल्ला: शेतकऱ्यांनी मालाची प्रतवारी (Grading) करून चांगल्या गुणवत्तेचा शेतमाल विक्रीस आणावा.");
        } else if ("FALLING".equalsIgnoreCase(trend)) {
            sb.append("• भावात घट (मंदी): ");
            if (arrivals > 10000) {
                sb.append("काढणी हंगामामुळे बाजारात एकाच वेळी मोठी आवक (").append(arrivals).append(" क्विंटल) झाल्याने व्यापाऱ्यांच्या बोलीत नरमाई दिसून येत आहे.\n");
            } else {
                sb.append("ग्राहक मागणीत तात्पुरती घट आणि बाहेरील बाजारातील दरांचा प्रभाव यामुळे बाजारभावात काहीशी घसरण झाली आहे.\n");
            }
            sb.append("• सल्ला: जर साठवणुकीची (Storage/Godown) सोय असेल तर भाव स्थिर होईपर्यंत काही माल रोखून ठेवण्याचा विचार करावा.");
        } else {
            sb.append("• भाव स्थिर: दैनिक आवक (").append(arrivals).append(" क्विंटल) आणि खरेदीदारांची मागणी यामध्ये समतोल असल्यामुळे सर्वसाधारण भाव स्थिर पातळीवर आहेत.");
        }

        return sb.toString();
    }

    public static String extractBaseName(String text) {
        if (text == null) return "";
        String s = text.trim();
        // If has parenthesis like "Pune (पुणे)" or "Onion (कांदा)", take the English part before parenthesis
        int idx = s.indexOf('(');
        if (idx > 0) {
            s = s.substring(0, idx).trim();
        }
        return s;
    }

    public static String getFormattedDistrictName(String baseDistrict) {
        for (String d : DISTRICTS) {
            if (extractBaseName(d).equalsIgnoreCase(baseDistrict)) {
                return d;
            }
        }
        return baseDistrict;
    }

    public static String normalizeDistrict(String input) {
        if (input == null) return "Pune";
        String s = input.trim().toLowerCase();
        if (s.contains("pune") || s.contains("पुणे") || s.contains("poona")) return "Pune";
        if (s.contains("nashik") || s.contains("नाशिक") || s.contains("nasik")) return "Nashik";
        if (s.contains("ahmednagar") || s.contains("अहमदनगर") || s.contains("nagar") || s.contains("ahilayanagar")) return "Ahmednagar";
        if (s.contains("latur") || s.contains("लातूर")) return "Latur";
        if (s.contains("solapur") || s.contains("सोलापूर") || s.contains("sholapur")) return "Solapur";
        if (s.contains("kolhapur") || s.contains("कोल्हापूर")) return "Kolhapur";
        if (s.contains("nagpur") || s.contains("नागपूर")) return "Nagpur";
        if (s.contains("amravati") || s.contains("अमरावती")) return "Amravati";
        if (s.contains("akola") || s.contains("अकोला")) return "Akola";
        if (s.contains("satara") || s.contains("सातारा")) return "Satara";
        if (s.contains("sangli") || s.contains("सांगली")) return "Sangli";
        if (s.contains("jalgaon") || s.contains("जळगाव")) return "Jalgaon";
        if (s.contains("dhule") || s.contains("धुळे")) return "Dhule";
        if (s.contains("jalna") || s.contains("जालना")) return "Jalna";
        if (s.contains("beed") || s.contains("बीड") || s.contains("bid")) return "Beed";
        if (s.contains("nanded") || s.contains("नांदेड")) return "Nanded";
        if (s.contains("buldhana") || s.contains("बुलढाणा") || s.contains("buldana")) return "Buldhana";
        if (s.contains("yavatmal") || s.contains("यवतमाळ")) return "Yavatmal";
        if (s.contains("washim") || s.contains("वाशीम")) return "Washim";
        if (s.contains("wardha") || s.contains("वर्धा")) return "Wardha";
        if (s.contains("chandrapur") || s.contains("चंद्रपूर")) return "Chandrapur";
        if (s.contains("parbhani") || s.contains("परभणी")) return "Parbhani";
        if (s.contains("hingoli") || s.contains("हिंगोली")) return "Hingoli";
        if (s.contains("dharashiv") || s.contains("धाराशीव") || s.contains("osmanabad") || s.contains("उस्मानाबाद")) return "Dharashiv";
        if (s.contains("sambhajinagar") || s.contains("संभाजीनगर") || s.contains("aurangabad") || s.contains("औरंगाबाद")) return "Chhatrapati Sambhajinagar";
        if (s.contains("ratnagiri") || s.contains("रत्नागिरी")) return "Ratnagiri";
        if (s.contains("sindhudurg") || s.contains("सिंधुदुर्ग")) return "Sindhudurg";
        if (s.contains("raigad") || s.contains("रायगड")) return "Raigad";
        if (s.contains("thane") || s.contains("ठाणे")) return "Thane";
        if (s.contains("palghar") || s.contains("पालघर")) return "Palghar";
        if (s.contains("bhandara") || s.contains("भंडारा")) return "Bhandara";
        if (s.contains("gondia") || s.contains("गोंदिया")) return "Gondia";
        if (s.contains("gadchiroli") || s.contains("गडचिरोली")) return "Gadchiroli";
        if (s.contains("nandurbar") || s.contains("नंदुरबार")) return "Nandurbar";
        if (s.contains("mumbai") || s.contains("मुंबई")) return "Mumbai City";

        return "Pune";
    }

    public static String normalizeCommodity(String input) {
        if (input == null) return "Onion (कांदा)";
        String s = input.trim().toLowerCase();
        if (s.contains("onion") || s.contains("कांदा") || s.contains("kanda") || s.contains("pyaz") || s.contains("kande")) return "Onion (कांदा)";
        if (s.contains("cotton") || s.contains("कापूस") || s.contains("kapas") || s.contains("kapus")) return "Cotton (कापूस)";
        if (s.contains("soybean") || s.contains("सोयाबीन") || s.contains("soyabean")) return "Soybean (सोयाबीन)";
        if (s.contains("chana") || s.contains("हरभरा") || s.contains("gram")) return "Gram / Chana (हरभरा)";
        if (s.contains("tur") || s.contains("तूर") || s.contains("arhar") || s.contains("toor")) return "Tur / Arhar (तूर)";
        if (s.contains("wheat") || s.contains("गहू") || s.contains("gehu") || s.contains("gahu")) return "Wheat (गहू)";
        if (s.contains("jowar") || s.contains("ज्वारी") || s.contains("jwari")) return "Jowar (ज्वारी)";
        if (s.contains("bajra") || s.contains("बाजरी") || s.contains("bajri")) return "Bajra (बाजरी)";
        if (s.contains("sugarcane") || s.contains("ऊस") || s.contains("us")) return "Sugarcane (ऊस)";
        if (s.contains("pomegranate") || s.contains("डाळिंब") || s.contains("dalimb") || s.contains("anar")) return "Pomegranate (डाळिंब)";
        if (s.contains("grapes") || s.contains("द्राक्षे") || s.contains("draksh") || s.contains("angoor")) return "Grapes (द्राक्षे)";
        if (s.contains("orange") || s.contains("संत्रा") || s.contains("santra")) return "Orange (संत्रा)";
        if (s.contains("mango") || s.contains("आंबा") || s.contains("amba") || s.contains("aam") || s.contains("alphonso") || s.contains("hapus")) return "Mango (आंबा)";
        if (s.contains("tomato") || s.contains("टोमॅटो") || s.contains("tamatar")) return "Tomato (टोमॅटो)";

        return "Onion (कांदा)";
    }
}
