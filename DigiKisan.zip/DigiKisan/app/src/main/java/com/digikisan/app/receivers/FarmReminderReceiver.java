package com.digikisan.app.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.digikisan.app.utils.NotificationHelper;

/**
 * BroadcastReceiver triggered by AlarmManager for farm reminders (irrigation, fertilizer, spraying).
 * Fulfills MAD Syllabus Unit 7 (Broadcast Receivers and Alarms).
 */
public class FarmReminderReceiver extends BroadcastReceiver {
    public static final String EXTRA_REMINDER_TITLE = "extra_reminder_title";
    public static final String EXTRA_REMINDER_MESSAGE = "extra_reminder_message";
    public static final String EXTRA_REMINDER_ID = "extra_reminder_id";

    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra(EXTRA_REMINDER_TITLE);
        String message = intent.getStringExtra(EXTRA_REMINDER_MESSAGE);
        int reminderId = intent.getIntExtra(EXTRA_REMINDER_ID, 1001);

        if (title == null) title = "आपला शेतकरी साथी — शेती स्मरणपत्र";
        if (message == null) message = "आज आपल्या शेतातील नियोजित काम पूर्ण करण्याची वेळ झाली आहे.";

        NotificationHelper.showNotification(context, title, message, reminderId);
    }
}
