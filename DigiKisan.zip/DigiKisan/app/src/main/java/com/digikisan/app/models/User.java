package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing a registered farmer user in Aapla Shetkari Saathi.
 */
public class User implements Serializable {
    private long id;
    private String fullName;
    private String mobileNumber;
    private String passwordHash;
    private String salt;
    private String district;
    private String taluka;
    private String preferredLanguage;
    private String createdAt;

    public User() {
    }

    public User(long id, String fullName, String mobileNumber, String passwordHash, 
                String salt, String district, String taluka, String preferredLanguage, String createdAt) {
        this.id = id;
        this.fullName = fullName;
        this.mobileNumber = mobileNumber;
        this.passwordHash = passwordHash;
        this.salt = salt;
        this.district = district;
        this.taluka = taluka;
        this.preferredLanguage = preferredLanguage;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getSalt() { return salt; }
    public void setSalt(String salt) { this.salt = salt; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getTaluka() { return taluka; }
    public void setTaluka(String taluka) { this.taluka = taluka; }

    public String getPreferredLanguage() { return preferredLanguage; }
    public void setPreferredLanguage(String preferredLanguage) { this.preferredLanguage = preferredLanguage; }

    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
}
