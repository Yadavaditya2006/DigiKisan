package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.services.ApmcDataSourceAdapter;
import com.digikisan.app.utils.InputValidator;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * RegisterActivity for new farmer account registration with Maharashtra district selection.
 */
public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etFullName, etRegisterMobile, etTaluka, etRegisterPassword, etConfirmPassword;
    private Spinner spinnerDistrict;
    private MaterialButton btnRegister;
    private TextView tvGoToLogin;
    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupDistrictSpinner();
        setupListeners();
    }

    private void initViews() {
        etFullName = findViewById(R.id.etFullName);
        etRegisterMobile = findViewById(R.id.etRegisterMobile);
        etTaluka = findViewById(R.id.etTaluka);
        etRegisterPassword = findViewById(R.id.etRegisterPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        spinnerDistrict = findViewById(R.id.spinnerDistrict);
        btnRegister = findViewById(R.id.btnRegister);
        tvGoToLogin = findViewById(R.id.tvGoToLogin);
    }

    private void setupDistrictSpinner() {
        // Populate all 36 Maharashtra Districts (excluding 'All Districts' index 0)
        List<String> districts = new ArrayList<>(Arrays.asList(ApmcDataSourceAdapter.DISTRICTS));
        if (!districts.isEmpty() && districts.get(0).startsWith("All")) {
            districts.remove(0);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner_selected, districts);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerDistrict.setAdapter(adapter);

        // Default selection to Pune
        for (int i = 0; i < districts.size(); i++) {
            if (ApmcDataSourceAdapter.extractBaseName(districts.get(i)).equalsIgnoreCase("Pune")) {
                spinnerDistrict.setSelection(i);
                break;
            }
        }
    }

    private void setupListeners() {
        btnRegister.setOnClickListener(v -> performRegistration());
        tvGoToLogin.setOnClickListener(v -> finish());
    }

    private void performRegistration() {
        String name = (etFullName.getText() != null) ? etFullName.getText().toString().trim() : "";
        String mobile = (etRegisterMobile.getText() != null) ? etRegisterMobile.getText().toString().trim() : "";
        String taluka = (etTaluka.getText() != null) ? etTaluka.getText().toString().trim() : "";
        String password = (etRegisterPassword.getText() != null) ? etRegisterPassword.getText().toString().trim() : "";
        String confirmPassword = (etConfirmPassword.getText() != null) ? etConfirmPassword.getText().toString().trim() : "";
        String rawDistrict = (spinnerDistrict.getSelectedItem() != null) ? spinnerDistrict.getSelectedItem().toString() : "Pune";
        String selectedDistrict = ApmcDataSourceAdapter.extractBaseName(rawDistrict);

        if (name.isEmpty() || mobile.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, R.string.err_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!InputValidator.isValidMobile(mobile)) {
            Toast.makeText(this, R.string.err_invalid_mobile, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!InputValidator.isValidPassword(password)) {
            Toast.makeText(this, R.string.err_password_short, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, R.string.err_password_mismatch, Toast.LENGTH_SHORT).show();
            return;
        }

        String cleanMobile = InputValidator.cleanMobileNumber(mobile);

        if (dbHelper.isMobileRegistered(cleanMobile)) {
            Toast.makeText(this, R.string.err_mobile_exists, Toast.LENGTH_LONG).show();
            return;
        }

        long userId = dbHelper.registerUser(name, cleanMobile, password, selectedDistrict, taluka);

        if (userId != -1) {
            sessionManager.createLoginSession(userId, name, cleanMobile, selectedDistrict);
            Toast.makeText(this, getString(R.string.greeting_farmer, name), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "नोंदणी अयशस्वी झाली, कृपया पुन्हा प्रयत्न करा.", Toast.LENGTH_SHORT).show();
        }
    }
}
