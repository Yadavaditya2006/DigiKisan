package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing a recorded crop assessment and rule-based diagnostic evaluation.
 */
public class CropAssessment implements Serializable {
    private long id;
    private long userId;
    private String cropName;
    private String growthStage;
    private String irrigationMethod;
    private String wateringInterval;
    private String soilType;
    private boolean waterloggingObserved;
    private String pestSymptoms;
    private String assessmentCategory; // "GOOD", "ATTENTION", "HIGH_RISK", "INSUFFICIENT"
    private String supportingFactors;
    private String riskFactors;
    private String suggestedActions;
    private String precautions;
    private String assessmentDate;

    public CropAssessment() {}

    public CropAssessment(long id, long userId, String cropName, String growthStage, 
                          String irrigationMethod, String wateringInterval, String soilType, 
                          boolean waterloggingObserved, String pestSymptoms, 
                          String assessmentCategory, String supportingFactors, 
                          String riskFactors, String suggestedActions, 
                          String precautions, String assessmentDate) {
        this.id = id;
        this.userId = userId;
        this.cropName = cropName;
        this.growthStage = growthStage;
        this.irrigationMethod = irrigationMethod;
        this.wateringInterval = wateringInterval;
        this.soilType = soilType;
        this.waterloggingObserved = waterloggingObserved;
        this.pestSymptoms = pestSymptoms;
        this.assessmentCategory = assessmentCategory;
        this.supportingFactors = supportingFactors;
        this.riskFactors = riskFactors;
        this.suggestedActions = suggestedActions;
        this.precautions = precautions;
        this.assessmentDate = assessmentDate;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public String getCropName() { return cropName; }
    public void setCropName(String cropName) { this.cropName = cropName; }

    public String getGrowthStage() { return growthStage; }
    public void setGrowthStage(String growthStage) { this.growthStage = growthStage; }

    public String getIrrigationMethod() { return irrigationMethod; }
    public void setIrrigationMethod(String irrigationMethod) { this.irrigationMethod = irrigationMethod; }

    public String getWateringInterval() { return wateringInterval; }
    public void setWateringInterval(String wateringInterval) { this.wateringInterval = wateringInterval; }

    public String getSoilType() { return soilType; }
    public void setSoilType(String soilType) { this.soilType = soilType; }

    public boolean isWaterloggingObserved() { return waterloggingObserved; }
    public void setWaterloggingObserved(boolean waterloggingObserved) { this.waterloggingObserved = waterloggingObserved; }

    public String getPestSymptoms() { return pestSymptoms; }
    public void setPestSymptoms(String pestSymptoms) { this.pestSymptoms = pestSymptoms; }

    public String getAssessmentCategory() { return assessmentCategory; }
    public void setAssessmentCategory(String assessmentCategory) { this.assessmentCategory = assessmentCategory; }

    public String getSupportingFactors() { return supportingFactors; }
    public void setSupportingFactors(String supportingFactors) { this.supportingFactors = supportingFactors; }

    public String getRiskFactors() { return riskFactors; }
    public void setRiskFactors(String riskFactors) { this.riskFactors = riskFactors; }

    public String getSuggestedActions() { return suggestedActions; }
    public void setSuggestedActions(String suggestedActions) { this.suggestedActions = suggestedActions; }

    public String getPrecautions() { return precautions; }
    public void setPrecautions(String precautions) { this.precautions = precautions; }

    public String getAssessmentDate() { return assessmentDate; }
    public void setAssessmentDate(String assessmentDate) { this.assessmentDate = assessmentDate; }
}
