package com.digikisan.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.models.DiaryEntry;
import java.util.List;

/**
 * RecyclerView Adapter for displaying Farm Diary entries.
 */
public class DiaryAdapter extends RecyclerView.Adapter<DiaryAdapter.ViewHolder> {

    public interface OnDeleteClickListener {
        void onDeleteClick(DiaryEntry entry, int position);
    }

    private final Context context;
    private List<DiaryEntry> diaryList;
    private final OnDeleteClickListener deleteListener;

    public DiaryAdapter(Context context, List<DiaryEntry> diaryList, OnDeleteClickListener deleteListener) {
        this.context = context;
        this.diaryList = diaryList;
        this.deleteListener = deleteListener;
    }

    public void updateList(List<DiaryEntry> newList) {
        this.diaryList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_diary_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DiaryEntry entry = diaryList.get(position);

        holder.tvDiaryActivityType.setText(entry.getActivityType());
        holder.tvDiaryDate.setText(entry.getEntryDate());
        holder.tvDiaryNotes.setText(entry.getNotes());
        holder.tvDiaryExpense.setText("Expense: ₹" + (int) entry.getExpenseAmount());
        holder.tvDiaryIncome.setText("Income: ₹" + (int) entry.getIncomeAmount());

        holder.btnDeleteDiary.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteClick(entry, holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return diaryList != null ? diaryList.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDiaryActivityType, tvDiaryDate, tvDiaryNotes, tvDiaryExpense, tvDiaryIncome;
        ImageButton btnDeleteDiary;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDiaryActivityType = itemView.findViewById(R.id.tvDiaryActivityType);
            tvDiaryDate = itemView.findViewById(R.id.tvDiaryDate);
            tvDiaryNotes = itemView.findViewById(R.id.tvDiaryNotes);
            tvDiaryExpense = itemView.findViewById(R.id.tvDiaryExpense);
            tvDiaryIncome = itemView.findViewById(R.id.tvDiaryIncome);
            btnDeleteDiary = itemView.findViewById(R.id.btnDeleteDiary);
        }
    }
}
