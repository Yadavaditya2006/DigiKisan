package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing a farmer's crop and land profile.
 */
public class FarmProfile implements Serializable {
    private long id;
    private long userId;
    private String primaryCrop;
    private String cropVariety;
    private String sowingDate;
    private double landAreaAcres;
    private String soilType;
    private String irrigationMethod;
    private String wateringSchedule;
    private String updatedAt;

    public FarmProfile() {}

    public FarmProfile(long id, long userId, String primaryCrop, String cropVariety, 
                       String sowingDate, double landAreaAcres, String soilType, 
                       String irrigationMethod, String wateringSchedule, String updatedAt) {
        this.id = id;
        this.userId = userId;
        this.primaryCrop = primaryCrop;
        this.cropVariety = cropVariety;
        this.sowingDate = sowingDate;
        this.landAreaAcres = landAreaAcres;
        this.soilType = soilType;
        this.irrigationMethod = irrigationMethod;
        this.wateringSchedule = wateringSchedule;
        this.updatedAt = updatedAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getUserId() { return userId; }
    public void setUserId(long userId) { this.userId = userId; }

    public String getPrimaryCrop() { return primaryCrop; }
    public void setPrimaryCrop(String primaryCrop) { this.primaryCrop = primaryCrop; }

    public String getCropVariety() { return cropVariety; }
    public void setCropVariety(String cropVariety) { this.cropVariety = cropVariety; }

    public String getSowingDate() { return sowingDate; }
    public void setSowingDate(String sowingDate) { this.sowingDate = sowingDate; }

    public double getLandAreaAcres() { return landAreaAcres; }
    public void setLandAreaAcres(double landAreaAcres) { this.landAreaAcres = landAreaAcres; }

    public String getSoilType() { return soilType; }
    public void setSoilType(String soilType) { this.soilType = soilType; }

    public String getIrrigationMethod() { return irrigationMethod; }
    public void setIrrigationMethod(String irrigationMethod) { this.irrigationMethod = irrigationMethod; }

    public String getWateringSchedule() { return wateringSchedule; }
    public void setWateringSchedule(String wateringSchedule) { this.wateringSchedule = wateringSchedule; }

    public String getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(String updatedAt) { this.updatedAt = updatedAt; }
}
