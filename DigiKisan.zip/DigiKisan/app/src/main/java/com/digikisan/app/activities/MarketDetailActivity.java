package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.adapters.ApmcPriceAdapter;
import com.digikisan.app.models.ApmcPrice;
import com.digikisan.app.services.ApmcDataSourceAdapter;

import java.util.List;

/**
 * Detailed view for an APMC market price record including price trend explanations
 * and side-by-side comparison with neighbouring Maharashtra markets.
 */
public class MarketDetailActivity extends AppCompatActivity {

    private ImageButton btnBackDetail;
    private TextView tvDetailCommodity, tvDetailMarket, tvDetailDistrict;
    private TextView tvDetailModalPrice, tvDetailTrendBadge, tvDetailPrevModal;
    private TextView tvDetailMinPrice, tvDetailMaxPrice, tvDetailArrivals, tvDetailVariety;
    private TextView tvDetailExplanation, tvDetailProvider;
    private RecyclerView rvComparableMarkets;

    private ApmcPrice apmcPrice;
    private ApmcDataSourceAdapter apmcAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market_detail);

        apmcAdapter = new ApmcDataSourceAdapter(this);

        initViews();
        loadDataFromIntent();
        setupListeners();
    }

    private void initViews() {
        btnBackDetail = findViewById(R.id.btnBackDetail);
        tvDetailCommodity = findViewById(R.id.tvDetailCommodity);
        tvDetailMarket = findViewById(R.id.tvDetailMarket);
        tvDetailDistrict = findViewById(R.id.tvDetailDistrict);
        tvDetailModalPrice = findViewById(R.id.tvDetailModalPrice);
        tvDetailTrendBadge = findViewById(R.id.tvDetailTrendBadge);
        tvDetailPrevModal = findViewById(R.id.tvDetailPrevModal);
        tvDetailMinPrice = findViewById(R.id.tvDetailMinPrice);
        tvDetailMaxPrice = findViewById(R.id.tvDetailMaxPrice);
        tvDetailArrivals = findViewById(R.id.tvDetailArrivals);
        tvDetailVariety = findViewById(R.id.tvDetailVariety);
        tvDetailExplanation = findViewById(R.id.tvDetailExplanation);
        tvDetailProvider = findViewById(R.id.tvDetailProvider);
        rvComparableMarkets = findViewById(R.id.rvComparableMarkets);
    }

    private void loadDataFromIntent() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("extra_apmc_price")) {
            apmcPrice = (ApmcPrice) intent.getSerializableExtra("extra_apmc_price");
        }

        if (apmcPrice != null) {
            bindData();
            loadComparableMarkets();
        }
    }

    private void bindData() {
        tvDetailCommodity.setText(apmcPrice.getCommodity());
        tvDetailMarket.setText(apmcPrice.getMarketName() + " APMC Market Yard");
        tvDetailDistrict.setText("District: " + apmcPrice.getDistrict() + " | Division: " + apmcPrice.getDivision());
        tvDetailModalPrice.setText("₹ " + (int) apmcPrice.getModalPrice());
        tvDetailMinPrice.setText("₹ " + (int) apmcPrice.getMinPrice() + " / क्विंटल");
        tvDetailMaxPrice.setText("₹ " + (int) apmcPrice.getMaxPrice() + " / क्विंटल");
        tvDetailArrivals.setText(apmcPrice.getArrivalsQuantity() + " क्विंटल");
        tvDetailVariety.setText(apmcPrice.getVariety());
        tvDetailPrevModal.setText("आधीचा भाव: ₹" + (int) apmcPrice.getPreviousModalPrice());

        // Trend Badge
        String trend = apmcPrice.getPriceTrend();
        if ("RISING".equalsIgnoreCase(trend)) {
            tvDetailTrendBadge.setText("RISING ▲ (+ " + String.format("%.1f", apmcPrice.getPercentageChange()) + "%)");
            tvDetailTrendBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_good));
            tvDetailTrendBadge.setTextColor(ContextCompat.getColor(this, R.color.status_good));
        } else if ("FALLING".equalsIgnoreCase(trend)) {
            tvDetailTrendBadge.setText("FALLING ▼ (" + String.format("%.1f", apmcPrice.getPercentageChange()) + "%)");
            tvDetailTrendBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_risk));
            tvDetailTrendBadge.setTextColor(ContextCompat.getColor(this, R.color.status_high_risk));
        } else {
            tvDetailTrendBadge.setText("STABLE ━");
            tvDetailTrendBadge.setBackground(ContextCompat.getDrawable(this, R.drawable.bg_badge_attention));
            tvDetailTrendBadge.setTextColor(ContextCompat.getColor(this, R.color.status_attention));
        }

        // Generate Market Explanation
        String explanation = apmcPrice.getPriceExplanation();
        if (explanation == null || explanation.isEmpty()) {
            explanation = ApmcDataSourceAdapter.generateMarketExplanation(
                    apmcPrice.getCommodity(),
                    apmcPrice.getModalPrice(),
                    apmcPrice.getPreviousModalPrice(),
                    apmcPrice.getArrivalsQuantity(),
                    apmcPrice.getPriceTrend()
            );
        }
        tvDetailExplanation.setText(explanation);

        tvDetailProvider.setText("माहिती स्रोत: " + apmcPrice.getDataProvider() + " | नोंद तारीख: " + apmcPrice.getObservationDate());
    }

    private void loadComparableMarkets() {
        List<ApmcPrice> comparables = apmcAdapter.getNeighbouringMarketComparisons(apmcPrice.getCommodity(), apmcPrice.getId());
        rvComparableMarkets.setLayoutManager(new LinearLayoutManager(this));
        ApmcPriceAdapter adapter = new ApmcPriceAdapter(this, comparables, clickedPrice -> {
            Intent intent = new Intent(MarketDetailActivity.this, MarketDetailActivity.class);
            intent.putExtra("extra_apmc_price", clickedPrice);
            startActivity(intent);
            finish();
        });
        rvComparableMarkets.setAdapter(adapter);
    }

    private void setupListeners() {
        btnBackDetail.setOnClickListener(v -> finish());
    }
}
