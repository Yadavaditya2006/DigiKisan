package com.digikisan.app.models;

import java.io.Serializable;

/**
 * Model representing an official Maharashtra APMC market price observation.
 */
public class ApmcPrice implements Serializable {
    private long id;
    private String division;
    private String district;
    private String marketName;
    private String commodity;
    private String variety;
    private double minPrice;
    private double maxPrice;
    private double modalPrice;
    private double previousModalPrice;
    private String priceUnit; // e.g. "Rs / Quintal"
    private int arrivalsQuantity; // Quintals
    private String observationDate;
    private String priceTrend; // "RISING", "FALLING", "STABLE", "INSUFFICIENT"
    private String priceExplanation;
    private String dataProvider; // e.g. "MSAMB / AGMARKNET"

    public ApmcPrice() {}

    public ApmcPrice(long id, String division, String district, String marketName, 
                     String commodity, String variety, double minPrice, double maxPrice, 
                     double modalPrice, double previousModalPrice, String priceUnit, 
                     int arrivalsQuantity, String observationDate, String priceTrend, 
                     String priceExplanation, String dataProvider) {
        this.id = id;
        this.division = division;
        this.district = district;
        this.marketName = marketName;
        this.commodity = commodity;
        this.variety = variety;
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.modalPrice = modalPrice;
        this.previousModalPrice = previousModalPrice;
        this.priceUnit = priceUnit;
        this.arrivalsQuantity = arrivalsQuantity;
        this.observationDate = observationDate;
        this.priceTrend = priceTrend;
        this.priceExplanation = priceExplanation;
        this.dataProvider = dataProvider;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getDivision() { return division; }
    public void setDivision(String division) { this.division = division; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getMarketName() { return marketName; }
    public void setMarketName(String marketName) { this.marketName = marketName; }

    public String getCommodity() { return commodity; }
    public void setCommodity(String commodity) { this.commodity = commodity; }

    public String getVariety() { return variety; }
    public void setVariety(String variety) { this.variety = variety; }

    public double getMinPrice() { return minPrice; }
    public void setMinPrice(double minPrice) { this.minPrice = minPrice; }

    public double getMaxPrice() { return maxPrice; }
    public void setMaxPrice(double maxPrice) { this.maxPrice = maxPrice; }

    public double getModalPrice() { return modalPrice; }
    public void setModalPrice(double modalPrice) { this.modalPrice = modalPrice; }

    public double getPreviousModalPrice() { return previousModalPrice; }
    public double getPrevModalPrice() { return previousModalPrice; }
    public void setPreviousModalPrice(double previousModalPrice) { this.previousModalPrice = previousModalPrice; }

    public String getPriceUnit() { return priceUnit; }
    public void setPriceUnit(String priceUnit) { this.priceUnit = priceUnit; }

    public int getArrivalsQuantity() { return arrivalsQuantity; }
    public void setArrivalsQuantity(int arrivalsQuantity) { this.arrivalsQuantity = arrivalsQuantity; }

    public String getObservationDate() { return observationDate; }
    public void setObservationDate(String observationDate) { this.observationDate = observationDate; }

    public String getPriceTrend() { return priceTrend; }
    public void setPriceTrend(String priceTrend) { this.priceTrend = priceTrend; }

    public String getPriceExplanation() { return priceExplanation; }
    public void setPriceExplanation(String priceExplanation) { this.priceExplanation = priceExplanation; }

    public String getDataProvider() { return dataProvider; }
    public void setDataProvider(String dataProvider) { this.dataProvider = dataProvider; }

    public double getPercentageChange() {
        if (previousModalPrice <= 0) return 0.0;
        return ((modalPrice - previousModalPrice) / previousModalPrice) * 100.0;
    }
}
