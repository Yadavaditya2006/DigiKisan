package com.digikisan.app.services;

import com.digikisan.app.models.FarmProfile;
import com.digikisan.app.models.Scheme;
import com.digikisan.app.models.User;

/**
 * Service that evaluates farmer profile against official scheme criteria.
 * Explicitly states that this is an informational recommendation, not a government guarantee.
 */
public class SchemeEligibilityEngine {

    public static String evaluateEligibility(Scheme scheme, User user, FarmProfile profile) {
        if (scheme == null) return "MORE_INFO_NEEDED";

        String category = scheme.getCategory();

        // 1. PM-Kisan & Namo Shetkari
        if ("INCOME_SUPPORT".equalsIgnoreCase(category)) {
            if (profile != null && profile.getLandAreaAcres() > 0 && profile.getLandAreaAcres() <= 50) {
                return "POTENTIALLY_ELIGIBLE";
            }
            return "MORE_INFO_NEEDED";
        }

        // 2. Crop Insurance (PMFBY)
        if ("INSURANCE".equalsIgnoreCase(category)) {
            if (profile != null && profile.getPrimaryCrop() != null && !profile.getPrimaryCrop().isEmpty()) {
                return "POTENTIALLY_ELIGIBLE";
            }
            return "MORE_INFO_NEEDED";
        }

        // 3. Irrigation Subsidy (Drip / Sprinkler)
        if ("IRRIGATION".equalsIgnoreCase(category)) {
            if (profile != null && profile.getLandAreaAcres() > 0) {
                // Highly eligible if current irrigation is rainfed or flood
                return "POTENTIALLY_ELIGIBLE";
            }
            return "MORE_INFO_NEEDED";
        }

        // 4. Agricultural Mechanization
        if ("MACHINERY".equalsIgnoreCase(category)) {
            if (profile != null && profile.getLandAreaAcres() >= 1.0) {
                return "POTENTIALLY_ELIGIBLE";
            }
            return "MORE_INFO_NEEDED";
        }

        return "POTENTIALLY_ELIGIBLE";
    }
}
