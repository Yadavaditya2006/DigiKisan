package com.digikisan.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.digikisan.app.R;
import com.digikisan.app.adapters.DiaryAdapter;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.DiaryEntry;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

/**
 * FarmDiaryActivity manages farmer activity logs, costs, and returns using SQLite.
 */
public class FarmDiaryActivity extends AppCompatActivity implements DiaryAdapter.OnDeleteClickListener {

    private ImageButton btnBackDiary;
    private TextView tvTotalExpense, tvTotalIncome, tvNetProfit, tvEmptyDiaryState;
    private MaterialButton btnGoToAddDiary;
    private RecyclerView rvDiaryEntries;

    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;
    private DiaryAdapter diaryAdapter;
    private List<DiaryEntry> diaryList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm_diary);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDiaryData();
    }

    private void initViews() {
        btnBackDiary = findViewById(R.id.btnBackDiary);
        tvTotalExpense = findViewById(R.id.tvTotalExpense);
        tvTotalIncome = findViewById(R.id.tvTotalIncome);
        tvNetProfit = findViewById(R.id.tvNetProfit);
        tvEmptyDiaryState = findViewById(R.id.tvEmptyDiaryState);
        btnGoToAddDiary = findViewById(R.id.btnGoToAddDiary);
        rvDiaryEntries = findViewById(R.id.rvDiaryEntries);
    }

    private void setupRecyclerView() {
        rvDiaryEntries.setLayoutManager(new LinearLayoutManager(this));
        diaryAdapter = new DiaryAdapter(this, diaryList, this);
        rvDiaryEntries.setAdapter(diaryAdapter);
    }

    private void setupListeners() {
        btnBackDiary.setOnClickListener(v -> finish());

        btnGoToAddDiary.setOnClickListener(v -> {
            Intent intent = new Intent(FarmDiaryActivity.this, AddDiaryEntryActivity.class);
            startActivity(intent);
        });
    }

    private void loadDiaryData() {
        long userId = sessionManager.getUserId();
        diaryList = dbHelper.getDiaryEntries(userId);
        diaryAdapter.updateList(diaryList);

        double[] totals = dbHelper.getDiaryTotals(userId);
        tvTotalExpense.setText("₹ " + (int) totals[0]);
        tvTotalIncome.setText("₹ " + (int) totals[1]);
        tvNetProfit.setText("₹ " + (int) totals[2]);

        if (diaryList.isEmpty()) {
            tvEmptyDiaryState.setVisibility(View.VISIBLE);
            rvDiaryEntries.setVisibility(View.GONE);
        } else {
            tvEmptyDiaryState.setVisibility(View.GONE);
            rvDiaryEntries.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDeleteClick(DiaryEntry entry, int position) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_entry)
                .setMessage(R.string.confirm_delete_entry)
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    boolean deleted = dbHelper.deleteDiaryEntry(entry.getId(), sessionManager.getUserId());
                    if (deleted) {
                        Toast.makeText(this, "नोंद हटवली आहे", Toast.LENGTH_SHORT).show();
                        loadDiaryData();
                    }
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }
}
