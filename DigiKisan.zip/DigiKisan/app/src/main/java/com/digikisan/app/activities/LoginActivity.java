package com.digikisan.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.digikisan.app.R;
import com.digikisan.app.database.DatabaseHelper;
import com.digikisan.app.models.User;
import com.digikisan.app.utils.InputValidator;
import com.digikisan.app.utils.UserSessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * LoginActivity for farmer authentication using mobile number and password against SQLite.
 * Distinguishes "no account" from "wrong password" to guide users correctly.
 */
public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etMobile, etPassword;
    private MaterialButton btnLogin;
    private TextView tvGoToRegister, tvForgotPassword, tvHelplineHelp;
    private DatabaseHelper dbHelper;
    private UserSessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = DatabaseHelper.getInstance(this);
        sessionManager = new UserSessionManager(this);

        initViews();
        setupListeners();
    }

    private void initViews() {
        etMobile = findViewById(R.id.etMobile);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvGoToRegister = findViewById(R.id.tvGoToRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvHelplineHelp = findViewById(R.id.tvHelplineHelp);
    }

    private void setupListeners() {
        btnLogin.setOnClickListener(v -> performLogin());

        tvGoToRegister.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        tvForgotPassword.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
            startActivity(intent);
        });

        tvHelplineHelp.setOnClickListener(v -> {
            Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:18001801551"));
            startActivity(dialIntent);
        });
    }

    private void performLogin() {
        String mobile = (etMobile.getText() != null) ? etMobile.getText().toString().trim() : "";
        String password = (etPassword.getText() != null) ? etPassword.getText().toString().trim() : "";

        if (mobile.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, R.string.err_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!InputValidator.isValidMobile(mobile)) {
            Toast.makeText(this, R.string.err_invalid_mobile, Toast.LENGTH_SHORT).show();
            return;
        }

        String cleanMobile = InputValidator.cleanMobileNumber(mobile);

        // Step 1: Check if account actually exists — distinguish "no account" from "wrong password"
        boolean accountExists = dbHelper.userExistsByMobile(cleanMobile);
        if (!accountExists) {
            Toast.makeText(this, R.string.err_no_account, Toast.LENGTH_LONG).show();
            return;
        }

        // Step 2: Attempt authentication (account exists, verify password)
        User user = dbHelper.authenticateUser(cleanMobile, password);

        if (user != null) {
            sessionManager.createLoginSession(user.getId(), user.getFullName(), user.getMobileNumber(), user.getDistrict());
            Toast.makeText(this, getString(R.string.greeting_farmer, user.getFullName()), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else {
            // Account exists but password did not match
            Toast.makeText(this, R.string.err_wrong_password, Toast.LENGTH_LONG).show();
        }
    }
}
