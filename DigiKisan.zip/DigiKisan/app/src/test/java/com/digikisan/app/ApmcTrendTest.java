package com.digikisan.app;

import com.digikisan.app.services.ApmcDataSourceAdapter;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for APMC market price trend calculation.
 */
public class ApmcTrendTest {

    @Test
    public void testPriceTrendRising() {
        // Price rose from 2000 to 2400 (+20%)
        String trend = ApmcDataSourceAdapter.calculateTrend(2400, 2000);
        assertEquals("RISING", trend);
    }

    @Test
    public void testPriceTrendFalling() {
        // Price fell from 2500 to 2200 (-12%)
        String trend = ApmcDataSourceAdapter.calculateTrend(2200, 2500);
        assertEquals("FALLING", trend);
    }

    @Test
    public void testPriceTrendStable() {
        // Price moved from 3000 to 3020 (+0.67%)
        String trend = ApmcDataSourceAdapter.calculateTrend(3020, 3000);
        assertEquals("STABLE", trend);
    }

    @Test
    public void testInsufficientData() {
        String trendZero = ApmcDataSourceAdapter.calculateTrend(2500, 0);
        assertEquals("INSUFFICIENT", trendZero);

        String trendNegative = ApmcDataSourceAdapter.calculateTrend(-100, 2000);
        assertEquals("INSUFFICIENT", trendNegative);
    }
}
