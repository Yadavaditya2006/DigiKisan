package com.digikisan.app;

import com.digikisan.app.utils.SecurityUtils;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for cryptographic operations (SHA-256 with salt password hashing).
 */
public class SecurityUtilsTest {

    @Test
    public void testSaltGeneration() {
        String salt1 = SecurityUtils.generateSalt();
        String salt2 = SecurityUtils.generateSalt();

        assertNotNull(salt1);
        assertNotNull(salt2);
        assertEquals(32, salt1.length()); // 16 bytes = 32 hex chars
        assertNotEquals(salt1, salt2);     // Randomness test
    }

    @Test
    public void testHashPasswordAndVerification() {
        String password = "ShetkariSecurePassword99";
        String salt = SecurityUtils.generateSalt();

        String hash = SecurityUtils.hashPassword(password, salt);
        assertNotNull(hash);
        assertEquals(64, hash.length()); // SHA-256 = 64 hex characters

        // Correct password matches
        assertTrue(SecurityUtils.verifyPassword(password, salt, hash));

        // Space tolerance (e.g., keyboard auto-space)
        assertTrue(SecurityUtils.verifyPassword(" " + password + " ", salt, hash));

        // Incorrect password fails
        assertFalse(SecurityUtils.verifyPassword("WrongPassword", salt, hash));
        assertFalse(SecurityUtils.verifyPassword("", salt, hash));
        assertFalse(SecurityUtils.verifyPassword(null, salt, hash));
    }

    @Test
    public void testLegacyAndPlainPasswordFallbacks() {
        String plain = "kisan123";

        // Plain text fallback match
        assertTrue(SecurityUtils.verifyPassword(plain, null, plain));
        assertTrue(SecurityUtils.verifyPassword(" " + plain + " ", null, plain));

        // Unsalted hash fallback match
        String unsaltedHash = SecurityUtils.hashPassword(plain, "");
        assertTrue(SecurityUtils.verifyPassword(plain, "", unsaltedHash));
        assertTrue(SecurityUtils.verifyPassword(" " + plain + " ", null, unsaltedHash));

        // Mismatched plain fails
        assertFalse(SecurityUtils.verifyPassword("otherpass", null, plain));
    }
}
