package com.digikisan.app;

import com.digikisan.app.utils.InputValidator;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for input validation (Indian mobile numbers, passwords, numeric amounts).
 */
public class InputValidatorTest {

    @Test
    public void testValidIndianMobileNumbers() {
        assertTrue(InputValidator.isValidMobile("9876543210"));
        assertTrue(InputValidator.isValidMobile("8123456789"));
        assertTrue(InputValidator.isValidMobile("7000112233"));
        assertTrue(InputValidator.isValidMobile("6999887766"));
        assertTrue(InputValidator.isValidMobile("+91 9876543210"));
        assertTrue(InputValidator.isValidMobile("09876543210"));
    }

    @Test
    public void testInvalidIndianMobileNumbers() {
        assertFalse(InputValidator.isValidMobile("1234567890")); // Does not start with 6-9
        assertFalse(InputValidator.isValidMobile("98765"));      // Too short
        assertFalse(InputValidator.isValidMobile("9876543210123")); // Too long
        assertFalse(InputValidator.isValidMobile("abcdefghij")); // Non-numeric
        assertFalse(InputValidator.isValidMobile(""));           // Empty
        assertFalse(InputValidator.isValidMobile(null));         // Null
    }

    @Test
    public void testCleanMobileNumber() {
        assertEquals("9876543210", InputValidator.cleanMobileNumber("+91 9876543210"));
        assertEquals("9876543210", InputValidator.cleanMobileNumber("09876543210"));
        assertEquals("9876543210", InputValidator.cleanMobileNumber("98765-43210"));
    }

    @Test
    public void testPasswordValidation() {
        assertTrue(InputValidator.isValidPassword("shetkari123"));
        assertTrue(InputValidator.isValidPassword("pass12"));
        assertFalse(InputValidator.isValidPassword("12345")); // Less than 6 characters
        assertFalse(InputValidator.isValidPassword(""));
        assertFalse(InputValidator.isValidPassword(null));
    }

    @Test
    public void testPositiveNumberValidation() {
        assertTrue(InputValidator.isValidPositiveNumber("2.5"));
        assertTrue(InputValidator.isValidPositiveNumber("0"));
        assertTrue(InputValidator.isValidPositiveNumber("5000"));
        assertFalse(InputValidator.isValidPositiveNumber("-10"));
        assertFalse(InputValidator.isValidPositiveNumber("abc"));
        assertFalse(InputValidator.isValidPositiveNumber(""));
    }
}
