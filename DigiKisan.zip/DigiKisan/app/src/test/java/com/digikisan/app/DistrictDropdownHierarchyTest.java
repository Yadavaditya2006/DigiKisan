package com.digikisan.app;

import com.digikisan.app.services.ApmcDataSourceAdapter;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

/**
 * Unit tests validating the Maharashtra geographical and administrative hierarchy,
 * dependent dropdown cascading, and string normalization.
 */
public class DistrictDropdownHierarchyTest {

    @Test
    public void testAllDivisionsCovered() {
        assertEquals("Must have 7 division entries (All + 6 official)", 7, ApmcDataSourceAdapter.DIVISIONS.length);
        assertTrue(ApmcDataSourceAdapter.DIVISIONS[1].contains("Pune"));
        assertTrue(ApmcDataSourceAdapter.DIVISIONS[2].contains("Nashik"));
        assertTrue(ApmcDataSourceAdapter.DIVISIONS[3].contains("Chhatrapati Sambhajinagar"));
        assertTrue(ApmcDataSourceAdapter.DIVISIONS[4].contains("Amravati"));
        assertTrue(ApmcDataSourceAdapter.DIVISIONS[5].contains("Nagpur"));
        assertTrue(ApmcDataSourceAdapter.DIVISIONS[6].contains("Konkan"));
    }

    @Test
    public void testAll36DistrictsCovered() {
        // Index 0 is 'All Districts', followed by all 36 Maharashtra districts
        assertEquals("Must cover exactly 36 districts + 1 All option", 37, ApmcDataSourceAdapter.DISTRICTS.length);
    }

    @Test
    public void testDivisionToDistrictsCascading() {
        List<String> puneDistricts = ApmcDataSourceAdapter.getDistrictsForDivision("Pune");
        assertNotNull(puneDistricts);
        assertTrue("Pune division must have at least 5 districts", puneDistricts.size() >= 5);

        boolean hasPune = false;
        boolean hasKolhapur = false;
        boolean hasSolapur = false;
        for (String d : puneDistricts) {
            if (d.contains("Pune")) hasPune = true;
            if (d.contains("Kolhapur")) hasKolhapur = true;
            if (d.contains("Solapur")) hasSolapur = true;
        }
        assertTrue(hasPune && hasKolhapur && hasSolapur);

        List<String> nashikDistricts = ApmcDataSourceAdapter.getDistrictsForDivision("Nashik");
        boolean hasNashik = false;
        boolean hasAhmednagar = false;
        for (String d : nashikDistricts) {
            if (d.contains("Nashik")) hasNashik = true;
            if (d.contains("Ahmednagar")) hasAhmednagar = true;
        }
        assertTrue(hasNashik && hasAhmednagar);
    }

    @Test
    public void testDistrictToApmcMarketsCascading() {
        List<String> nashikMarkets = ApmcDataSourceAdapter.getMarketsForDistrict("Nashik");
        assertTrue(nashikMarkets.contains("Lasalgaon"));
        assertTrue(nashikMarkets.contains("Pimpalgaon Baswant"));

        List<String> puneMarkets = ApmcDataSourceAdapter.getMarketsForDistrict("Pune");
        assertTrue(puneMarkets.contains("Pune (Gultekdi)"));
        assertTrue(puneMarkets.contains("Baramati"));

        // Changing to invalid or all district yields default
        List<String> emptyMarkets = ApmcDataSourceAdapter.getMarketsForDistrict("");
        assertEquals(1, emptyMarkets.size());
        assertTrue(emptyMarkets.get(0).startsWith("All Markets"));
    }

    @Test
    public void testExtractBaseName() {
        assertEquals("Pune", ApmcDataSourceAdapter.extractBaseName("Pune (पुणे)"));
        assertEquals("Onion", ApmcDataSourceAdapter.extractBaseName("Onion (कांदा)"));
        assertEquals("All Districts", ApmcDataSourceAdapter.extractBaseName("All Districts (सर्व जिल्हे)"));
        assertEquals("Kolhapur", ApmcDataSourceAdapter.extractBaseName("Kolhapur"));
        assertEquals("", ApmcDataSourceAdapter.extractBaseName(null));
    }

    @Test
    public void testNormalization() {
        assertEquals("Pune", ApmcDataSourceAdapter.normalizeDistrict("Poona"));
        assertEquals("Nashik", ApmcDataSourceAdapter.normalizeDistrict("nashik"));
        assertEquals("Ahmednagar", ApmcDataSourceAdapter.normalizeDistrict("अहमदनगर"));
        assertEquals("Onion (कांदा)", ApmcDataSourceAdapter.normalizeCommodity("kanda"));
        assertEquals("Soybean (सोयाबीन)", ApmcDataSourceAdapter.normalizeCommodity("soyabean"));
        assertEquals("Cotton (कापूस)", ApmcDataSourceAdapter.normalizeCommodity("kapas"));
    }
}
