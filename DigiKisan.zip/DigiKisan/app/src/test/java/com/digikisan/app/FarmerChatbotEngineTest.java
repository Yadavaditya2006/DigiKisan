package com.digikisan.app;

import com.digikisan.app.services.FarmerChatbotEngine;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests validating the Shetkari Mitra multilingual conversational chatbot engine:
 * Language detection across Devanagari Marathi, Romanized Marathi, Hinglish, and English.
 */
public class FarmerChatbotEngineTest {

    @Test
    public void testDevanagariMarathiDetection() {
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_DEVANAGARI,
                FarmerChatbotEngine.detectLanguage("माझ्या कांद्याला सध्या काय भाव आहे?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_DEVANAGARI,
                FarmerChatbotEngine.detectLanguage("आज पाऊस पडणार आहे का?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_DEVANAGARI,
                FarmerChatbotEngine.detectLanguage("ठिबक सिंचन अनुदान योजना माहिती सांगा"));
    }

    @Test
    public void testRomanizedMarathiDetection() {
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Mala onion cha aajcha bhav sang."));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Majhya jilhyat soybean cha rate kay aahe?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Pune district madhle APMC rates dakhav."));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Majhya shetat pani kiti vela dyaycha?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Paus padnar aahe ka?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("PM Kisan sathi konti documents lagtat?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("District select kasa karaycha?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Kal peksha vadhla ka?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Mag kami ka zala?"));
    }

    @Test
    public void testHinglishDetection() {
        assertEquals(FarmerChatbotEngine.LanguageType.HINGLISH,
                FarmerChatbotEngine.detectLanguage("Mere soybean ke rate kam kyu ho rahe hain?"));
        assertEquals(FarmerChatbotEngine.LanguageType.HINGLISH,
                FarmerChatbotEngine.detectLanguage("Mujhe kisan yojana ke baare me batao."));
    }

    @Test
    public void testEnglishDetection() {
        assertEquals(FarmerChatbotEngine.LanguageType.ENGLISH,
                FarmerChatbotEngine.detectLanguage("Why is onion price going down?"));
        assertEquals(FarmerChatbotEngine.LanguageType.ENGLISH,
                FarmerChatbotEngine.detectLanguage("What is the weather forecast for today?"));
        assertEquals(FarmerChatbotEngine.LanguageType.ENGLISH,
                FarmerChatbotEngine.detectLanguage("How to select district in APMC screen?"));
    }

    @Test
    public void testNaturalFarmerPhrases() {
        // Natural farmer phrases from requirements specification
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Mala onion cha aajcha bhav sang."));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Majhya jilh\u094d\u092f\u093e\u0924 soybean cha rate kay aahe?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Pune district madhle APMC rates dakhav."));
        assertEquals(FarmerChatbotEngine.LanguageType.ENGLISH,
                FarmerChatbotEngine.detectLanguage("Why is onion price going down?"));
        assertEquals(FarmerChatbotEngine.LanguageType.HINGLISH,
                FarmerChatbotEngine.detectLanguage("Mere soybean ke rate kam kyu ho rahe hain?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Majhya shetat pani kiti vela dyaycha?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Paus padnar aahe ka?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("Mala konti yojana milu shakte?"));
        assertEquals(FarmerChatbotEngine.LanguageType.MARATHI_ROMANIZED,
                FarmerChatbotEngine.detectLanguage("District select kasa karaycha?"));
    }
}
