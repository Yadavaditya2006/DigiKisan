package com.digikisan.app;

import com.digikisan.app.models.CropAssessment;
import com.digikisan.app.services.CropAssessmentEngine;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for rule-based crop condition evaluation engine.
 */
public class CropAssessmentEngineTest {

    @Test
    public void testGoodConditionScenario() {
        CropAssessment result = CropAssessmentEngine.evaluate(
                1L, "Soybean", "Vegetative Growth", "Drip Irrigation", "Weekly",
                "Medium Red Soil", false, "Normal, Healthy Appearance"
        );

        assertNotNull(result);
        assertEquals("GOOD", result.getAssessmentCategory());
        assertTrue(result.getSupportingFactors().contains("निचरा चांगला"));
        assertFalse(result.isWaterloggingObserved());
    }

    @Test
    public void testHighRiskWaterloggingAndWiltingScenario() {
        CropAssessment result = CropAssessmentEngine.evaluate(
                1L, "Cotton", "Flowering", "Flood / Furrow", "Daily",
                "Heavy Black Cotton Soil", true, "Plant Wilting / Drooping"
        );

        assertNotNull(result);
        assertEquals("HIGH_RISK", result.getAssessmentCategory());
        assertTrue(result.isWaterloggingObserved());
        assertTrue(result.getRiskFactors().contains("पाणी साचले"));
        assertTrue(result.getSuggestedActions().contains("चर"));
    }

    @Test
    public void testAttentionScenarioWithChlorosis() {
        CropAssessment result = CropAssessmentEngine.evaluate(
                1L, "Onion", "Vegetative Growth", "Drip Irrigation", "Every 2-3 Days",
                "Medium Red Soil", false, "Leaf Yellowing / Chlorosis"
        );

        assertNotNull(result);
        assertEquals("ATTENTION", result.getAssessmentCategory());
        assertTrue(result.getRiskFactors().contains("पिवळी"));
        assertTrue(result.getSuggestedActions().contains("१९:१९:१९"));
    }
}
